// import { AllShedule } from '../../interface/forms/order-management/all-shedule';
import cDate from '../../utilities/date';

export const createJointInvestigationTroubleTicketModal = {
  ticketDetails : {
    OpCoIncidentID : '',
    incidentID : '',
    incidentType :'',
    orderRequestIdentifier : '',
    schedule : '',
    classification : 'Joint Investigation',
    urgency : '4-Low',
    // impact : '',
    // serviceUnavailability : 'Yes',
    // numberOfServicesImpacted : '',
    // ticketSummary : '',
    // ticketDescription : ''
  },
  serviceOrderDetails : {
    firstName : "Dipti",
    lastName : "Mehendale",
    contactNumber : "9999888889",
    emailAddress : "dipti@singtel.com",
    blockHouseNumber: "304",
    buildingName : "OLEANDER BREEZE",
    streetName: "YISHUN STREET 51",
    unitNumber: "1870",
    postalCode: "560302",
    buildingType: "HDB",
    coverageStatus: "Home Reached",
    copifType : "High Rise", 
    schedule : "Residential End-User Connection"
  },
  primaryContact : {
    firstName : "Dipti",
    lastName : "Mehendale",
    contactNumber : "9999888889",
    emailAddress : "dipti@netlink.com"
  },
  secondaryContact : {
    firstName : "",
    lastName : "",
    contactNumber : "",
    emailAddress : ""
  },
  endUserDetails : {
    firstName : "",
    lastName : "",
    contactNumber : "",
    emailAddress : ""
  },
  // ticketItem : {
  //   itemType : "Attachment" ,
  //   summary : '',
  //   notes : '',
  //   reservationID : '',
  //   appointmentOwner : '',
  //   appointmentStatus : '',
  //   appointmentDate : "",
  //   appointmentTime : '',
  //   attachment : ''  

  // }


}
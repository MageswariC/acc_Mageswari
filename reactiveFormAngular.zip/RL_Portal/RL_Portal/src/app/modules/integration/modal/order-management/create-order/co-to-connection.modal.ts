
import cDate from '../../../utilities/date';

export const coToCoConnectionModal = {
            orderDetails: {
                appRefIdentifier: "",
                segmentFromCO: "",
                segmentToCO : "",
                redundancyService: "No",
                redundancyServiceOptions: "",
                rejectIfredundancyService: "",
                contractTerm : "12 Months",
                promoCode : ""
            },
            activationDetails: {
                dateOfActivation : cDate.formatDate(new Date()),
            },
            priceDetails: {
                installationCharge : "$30",
                serviceActivationCharge : "$0",
                monthlyRecurringCharge: "$0"
            },
            addInformation: {
                addInformation:''
            }
            
}
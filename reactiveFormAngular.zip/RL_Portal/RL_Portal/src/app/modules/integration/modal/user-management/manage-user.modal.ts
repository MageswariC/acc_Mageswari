import { CreateUser } from "../../interface/forms/user-management/create-user";

export const manageUser: CreateUser = {
    userInfo: {
        billingId: "01",
        company: "Singtel",
        userId: "rluser1",
        emailId: "",
        principalName: "",
        designation: "",
        contactNo: "66664456",
        faxNo: "64333566",
        expiryDate: "30-07-2023",
        priorityCircuit: "yes"
    },
    role: ""
}
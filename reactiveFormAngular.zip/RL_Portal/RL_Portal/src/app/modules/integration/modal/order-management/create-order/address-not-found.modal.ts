
export const AddressNotFoundModal  = {
    feasibilityCheck: {
        postalCode : "",
        unitNumber: "",
    },
    installationAddress: {
        blockHouseNumber: "304",
         buildingName : "OLEANDER BREEZE",
         streetName: "YISHUN STREET 51",
         unitNumber: "307987",
         postalCode: "504302",
         buildingType: "HDB",
         coverageStatus: "Home Reached",
         copifType : "High Rise", 
    },
    orderDetails: {
        appRefIdentifier: "",
        technology: "GPON",
        splitRatio : "1:24",
        redundancyService: "No",
        rejectIfredundancyService: "",
        contractTerm : "12 Months",
        promoCode : ""
    },
   
    endUserDetails: {
        salutation: "Mr",
        userName : "test",
        phoneNumber : "1234567890",
        faxNumber:"12345678",
        emailAddress: "abc@gmail.com",
        userType: "Normal"
    },
    addInformation: {
        addInformation:'addtional information'
    }
}
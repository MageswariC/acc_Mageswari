
import cDate from '../../../utilities/date';
export const coTobuildingMdfConnectionModal  = {
            installationAddress: {
                 blockHouseNumber: "304",
                //postalCode: "560302",
                 buildingName : "OLEANDER BREEZE",
                 streetName: "YISHUN STREET 51",
                // unitNumber: "#01-01",
                buildingType : "HDR",
                coverageStatus : "Unit Reached"
                 
            },
            orderDetails: {
                appRefIdentifier: "",
                rLProvideOwnPatchCable:"",
                rLFDFIdentificationNumber:"",
                redundancyService: "No",
                redundancyServiceOptions: "",
                rejectIfredundancyService: "",
                contractTerm : "12 Months",
                promoCode : ""
            },
            activationDetails: {
                dateOfActivation : cDate.formatDate(new Date()),
            },
          
            priceDetails: {
                installationCharge : "$30",
                serviceActivationCharge : "$0",
                monthlyRecurringCharge: "$0"
            },
            addInformation: {
                addInformation:''
            }
            
}
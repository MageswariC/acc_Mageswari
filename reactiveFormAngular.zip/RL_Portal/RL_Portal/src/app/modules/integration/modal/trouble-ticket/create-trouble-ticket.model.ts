// import { AllShedule } from '../../interface/forms/order-management/all-shedule';
// import cDate from '../../utilities/date';

export const createTroubleTicketModal = {
  ticketDetails : {
    OpCoIncidentID : 'abcdefgh',
    incidentID : '123456789',
    orderRequestIdentifier : '',
    classification : 'Incident',
    urgency : '4-Low',
    serviceUnavailability : 'Yes',
    numberOfServicesImpacted : '1',
    ticketDescription : ''
  },
  serviceOrderDetails : {
    firstName : "DiptiA",
    lastName : "Mehendale",
    contactNumber : "9999888889",
    emailAddress : "dipti@singtel.com"
  },
  secondaryContact : {
    firstName : "",
    lastName : "",
    contactNumber : "",
    emailAddress : ""
  },
  endUserDetails : {
    firstName : "",
    lastName : "",
    contactNumber : "",
    emailAddress : ""
  },
  // ticketItem : {
  //   itemType : "Attachment" ,
  //   summary : '',
  //   notes : '',
  //   reservationID : '',
  //   appointmentOwner : '',
  //   appointmentStatus : '',
  //   appointmentDate : "",
  //   appointmentTime : '',
  //   attachment : ''  

  // }


}
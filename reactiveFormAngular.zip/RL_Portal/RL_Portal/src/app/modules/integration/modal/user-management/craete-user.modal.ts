import { CreateUser } from "../../interface/forms/user-management/create-user";

export const createUser: CreateUser = {
    userInfo: {
        billingId: "02",
        userId: "",
        company: "Singtel",
        emailId: "",
        password: "",
        confirmPassword: "",
        principalName: "",
        designation: "",
        contactNo: "",
        faxNo: "",
        expiryDate: ""
    },
    role: ""
}
import { ServiceOrderDetail } from "../../../interface/forms/common/service-order-detail-interface";

export const createOrder  = {
    feasibilityDetails: {
        postalCode : "",
        unitNumber: "",
    },
    installationDetails: {
        blockHouseNo: "",
         buildingName : "",
         streetName: "",
         buildingType: "",
         coverageStatus: "",
         copifType : "", 
    },
    orderDetails: {
        arnNo: "",
        technology: "",
        splitRatio : "",
        redundancyService: "",
        rejectRedundancyService: "",
        contractTerm : "",
        promoCode : ""
    },
   
    endUserDetails: {
        salutation: "",
        endUsername : "",
        endUserContactNo : "",
        endUserfax:"",
        endUserEmailId: "",
        userType: ""
    },
    additionalInfo: {
        addInformation:'addtional information'
    }
}
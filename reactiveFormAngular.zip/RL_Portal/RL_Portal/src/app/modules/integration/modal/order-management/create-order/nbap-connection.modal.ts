//import { AllShedule } from '../../../interface/forms/order-management/all-shedule';
import cDate from '../../../utilities/date';

export const nbapConnectionModel = {
            installationAddress: {
                 coordinateSystem:"",
                 gpsXcoordinates : "31842.260",
                 gpsYcoordinates : "34123.037",
                 postalCode:""
            },
            orderDetails: {
                appRefIdentifier: "",
                installationType: "NLT to Install",
                technology: "GPON",
                splitRatio : "1:16",
                redundancyService: "No",
                rejectIfredundancyService: "",
                contractTerm : "12 Months",
                promoCode : "",
            },
            siteSurveyDetails: {
                preferredSiteSurveyDate : cDate.formatDate(new Date()),
                preferredSiteSurveySlot:"AM"
            },
            authorizedEndUserDetails: {
                salutation: "Mr",
                userName : "",
                phoneNumber : "",
                alternatePhone:"",
                faxNumber: "",
                emailAddress: "",
                userType: "Normal"
            },
            
            addInformation: {
                addInformation:''
            }
}
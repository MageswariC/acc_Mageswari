
export const installationAddress={
    blockHouseNumber: "4A",

    "postalCode": "567363",

    "dataCenter": "DC1",
    "coverageStatus": "Unit Reached",

    "unitNumber": "#10-309",
    "tpName":"TPname",
    "buildingType":"HDR", 
    "feasibilityNote":"Home Reached",
    "feasibilityCode":"HomeReached",
   "streetName":"YISHUN STREET 6", 
    "buildingName":"OLEANDER BREEZE", 
    "buildingHouseNo":"302",
    "feasibilityStatus":"sample text",
     "firstPassIndicator":"", 
     "tpInstallation":"", 
     "copifType":"COPIF 2008", 
     "physicalCo":"Phy001", 
     "logicalCo":"Logicl001"   
}

export const  siteAdressDetails={
    buildingNumber:304,
    buildingName:"OLEANDER BREEZE",
    streetName:"Tampines Street",
    unitNumber:"#11-22",
    postalCode:"600123",
    landmark:"Central Park",
    buildingType: "HDB",
    coverageStatus:"Unit Reached",
    "copifType":"COPIF 2008", 
    "physicalCo":"Phy001", 
    "logicalCo":"Logicl001" ,
    coordinateSystem: "SVY21",
    gpsXcoordinates:"31956.75598245192",
    gpsYcoordinates:"33128.60972081525",
    dataCenter: "DC1"
    
}

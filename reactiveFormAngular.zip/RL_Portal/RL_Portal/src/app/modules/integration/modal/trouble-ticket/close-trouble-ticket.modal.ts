
import cDate from '../../utilities/date';

export const closeTroubleTicketModal = {
    ticketDetails : {
      OpCoIncidentID : 'OP11118858855',
      incidentID : 'ON798787387389',
      ticketStatus :'Pending',
      CODetails : 'Tampines',
      incidentType: 'CO-LOC Fault',
      orderRequestIdentifier :'01-01-23118765-85301-A',
      schedule:'Residential End-User Connection',
      serviceUnavailability :'Yes',
      numberOfServicesImpacted :'1',
      ticketSummary:'Injection Fault',
      classification : 'Incident',
      urgency : 'Low',
      impact : 'Extensive/Wide Spread',
      ticketDescription : 'Some Description of ticket',
      causeOfFault: 'Denial Access by End User'
    }
}
// import { AllShedule } from '../../interface/forms/order-management/all-shedule';
import cDate from '../../utilities/date';

export const reopenTroubleTicketModal = {
  ticketDetails : {

    incidentID : 'ON2206100314297',
     status: 'Pending'
  
  },


}
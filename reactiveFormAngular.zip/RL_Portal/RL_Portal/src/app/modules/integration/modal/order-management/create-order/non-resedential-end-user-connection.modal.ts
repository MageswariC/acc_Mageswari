import { AllShedule } from '../../../interface/forms/order-management/all-shedule';
import cDate from '../../../utilities/date';

export const nonResidentialEndUserModal : AllShedule = {
            installationAddress: {
                blockHouseNumber: "304",
                buildingName : "OLEANDER BREEZE",
                streetName: "YISHUN STREET 51",
                unitNumber: "#01-01",
                 postalCode: "560302",
                 buildingType: "HDB",
                 coverageStatus: "Home Reached",
                 copifType:"Pre-Copif",
                 dataCenter:""
            },
            orderDetails: {
                appRefIdentifier: "",
                installationType:"NLT to Install",
                technology: "GPON",
                splitRatio : "1:16",
                redundancyService: "No",
                rejectIfredundancyService: "",
                contractTerm : "12 Months",
                promoCode : ""
            },
            activationDetails: {
                timeSlotOption : "Normal",
                dateOfActivation : cDate.formatDate(new Date()),
                installationTime: "12PM"
            },
           
            authorizedEndUserDetails: {
                salutation: "Mr",
                userName : "",
                phoneNumber : "",
                emailAddress: "",
                alternatePhone:"",
                faxNumber:"",
                userType: "Normal"
            },
            priceDetails: {
                installationCharge : "$30",
                serviceActivationCharge : "$0",
                monthlyRecurringCharge: "$0"
            },
            addInformation: {
                addInformation:''
            }
}
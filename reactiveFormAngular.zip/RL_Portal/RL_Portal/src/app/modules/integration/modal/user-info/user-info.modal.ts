

export const userInfo = {
    requestingLicensee: {
        rlName: "RL User",
        companyName: "Singtel",
        designation: "System Engineer",
        contactInfo: "63297537",
        faxNo: "63297537",
        emailId: "rluser@singtel.com",
    },

}
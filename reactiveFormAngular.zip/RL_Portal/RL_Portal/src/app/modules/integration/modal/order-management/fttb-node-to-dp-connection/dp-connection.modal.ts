
import cDate from '../../../utilities/date';


export const dpConnectionModal  = {
            feasibilityCheck: {
                postalCode : "",
                unitNumber: "",
                fttbId : "",
            },
            installationAddress: {
                blockHouseNumber : "304",
                 buildingName : "OLEANDER BREEZE",
                 streetName: "YISHUN STREET 51",
                 unitNumber: "#01-01",
                 postalCode: "560302",
                 coverageStatus: "Home Reached",
                 buildingType : "HDR",
                 copifType:"Pre-Copif",
            },
            orderDetails: {
                appRefIdentifier: "",
                technology: "GPON",
                splitRatio : "1:24",
                redundancyService: "No",
                rejectIfredundancyService: "",
                contractTerm : "12 Months",
                promoCode : ""
            },
            activationDetails: {
                dateOfActivation: cDate.formatDate(new Date()),
            },
            priceDetails: {
                installationCharge : "$30",
                serviceActivationCharge : "$0",
                monthlyRecurringCharge: "$0"
            },
            addInformation: {
                addInformation  : ""
            }
}
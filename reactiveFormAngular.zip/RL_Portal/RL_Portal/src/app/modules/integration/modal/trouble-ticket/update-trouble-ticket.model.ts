// import { AllShedule } from '../../interface/forms/order-management/all-shedule';
import cDate from '../../utilities/date';

export const updateTroubleTicketModal = {
  ticketDetails : {
    OpCoIncidentID : 'OP11118858855',
    incidentID : 'ON798787387389',
    ticketStatus :'Pending',
    CODetails : 'AM',
    COLocation:'Room 1',
    serviceType :'RL-RL Service',
    incidentType: 'CO-LOC Fault',
    orderRequestIdentifier :'01-01-23118765-85301-A',
    schedule:'Residential End-User Connection',
    serviceUnavailability :'Yes',
    numberOfServicesImpacted :'1',
    ticketSummary:'TP No Signal',
    classification : 'Incident',
    urgency : '4-Low',
    impact : '1-Extensive/Widespread',
    ticketDescription : 'Some Description of ticket',
    causeOfFault: 'Denial Access by End User',
    jointInvestigationFault :'Serving Cabinet'
  },
  serviceOrderDetails : {
    firstName : "RL",
    lastName : "User",
    contactNumber : "9999888889",
    emailAddress : "rlUser@singtel.com",
    blockHouseNumber: "304",
    buildingName : "OLEANDER BREEZE",
    streetName: "YISHUN STREET 51",
    unitNumber: "1870",
    postalCode: "560302",
    buildingType: "HDB",
    coverageStatus: "Home Reached",
    copifType : "High Rise", 
    schedule : "Residential End-User Connection"
  },
  primaryContact : {
    firstName : "RL",
    lastName : "User1",
    contactNumber : "9999888889",
    emailAddress : "rlUser1@netlink.com"
  },
  secondaryContact : {
    firstName : "Sreenidhi",
    lastName : "W",
    contactNumber : "9888777288",
    emailAddress : "sreew@gmail.com"
  },
  endUserDetails : {
    firstName : "RL",
    lastName : "User",
    contactNumber : "9888777288",
    emailAddress : "rlUser@gmail.com",
    blockHouseNumber: "304",
    buildingName : "OLEANDER BREEZE",
    streetName: "YISHUN STREET 51",
    unitNumber: "#01-01",
    postalCode: "560302",
  },
  // ticketItem : {
  //   itemType : "Attachment" ,
  //   summary : '',
  //   notes : '',
  //   reservationID : '',
  //   appointmentOwner : '',
  //   appointmentStatus : '',
  //   appointmentDate : "",
  //   appointmentTime : '',
  //   attachment : ''  

  // }


}
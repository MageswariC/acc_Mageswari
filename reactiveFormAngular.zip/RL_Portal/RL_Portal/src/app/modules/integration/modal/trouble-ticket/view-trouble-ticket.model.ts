
import cDate from '../../utilities/date';

export const viewTroubleTicketModal = {
  ticketDetails : {
    OpCoIncidentID : 'OP11118858855',
    incidentID : 'ON798787387389',
    ticketStatus :'Pending',
    CODetails : 'Tampines',
    incidentType: 'CO-LOC Fault',
    orderRequestIdentifier :'01-01-23118765-85301-A',
    schedule:'Residential End-User Connection',
    serviceUnavailability :'Yes',
    numberOfServicesImpacted :'1',
    ticketSummary:'Injection Fault',
    classification : 'Incident',
    urgency : 'Low',
    impact : 'Extensive/Wide Spread',
    ticketDescription : 'Some Description of ticket',
    causeOfFault: 'Denial Access by End User'
  },
  serviceOrderDetails : {
    firstName : "RL",
    lastName : "User1",
    contactNumber : "9999888889",
    emailAddress : "rlUser1@singtel.com",
    blockHouseNumber: "304",
    buildingName : "OLEANDER BREEZE",
    streetName: "YISHUN STREET 51",
    unitNumber: "1870",
    postalCode: "560302",
    buildingType: "HDB",
    coverageStatus: "Home Reached",
    copifType : "High Rise", 
    schedule : "Residential End-User Connection"
  },
  primaryContact : {
    firstName : "RL",
    lastName : "User1",
    contactNumber : "9999888889",
    emailAddress : "rlUser1@nlt.com"
  },
  secondaryContact : {
    firstName : "Sreenidhi",
    lastName : "W",
    contactNumber : "9988776655",
    emailAddress : "sreew@gmail.com"
  },
  endUserDetails : {
    firstName : "RL",
    lastName : "User1",
    contactNumber : "9888777288",
    emailAddress : "rlUser1@gmail.com",
    blockHouseNumber: "304",
    buildingName : "OLEANDER BREEZE",
    streetName: "YISHUN STREET 51",
    unitNumber: "#01-01",
    postalCode: "560302",
  },
  // ticketItem : {
  //   itemType : "Attachment" ,
  //   summary : '',
  //   notes : '',
  //   reservationID : '',
  //   appointmentOwner : '',
  //   appointmentStatus : '',
  //   appointmentDate : "",
  //   appointmentTime : '',
  //   attachment : ''  

  // }


}
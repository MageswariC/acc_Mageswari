import { InstallationAddress } from "./installation-address-interface";

export interface AvialableSlots {
    dateFrom: String;
    dateTo: String;
    taskId: String;
}

export interface ActivationDetail {
    timeSlotOption?: String;
    dateOfActivation?: String;
    installationTime?: String;
    taskId?: String;
    dateFrom?: String;
    dateTo?: String;
    timeSlotsList?: TimeSlotsLists
    dateOfApplication?: String;
    tentativeProvisioningDate?: String;
    rejectionReasion?: String;
}

export interface TimeSlotsLists {
    slotsList?: any;
    recommended?: string;
    employee?: string
    timeZone?: string
}

export interface SoftReserveAppointment {
    dateFrom: String;
    taskId: String;
    dateTo: String;
    profileName: String; //NLT
    sourceType: String; //SWP
    timeZone: String; //CTT
}

export interface ReserveAppointment {
    bookDate: String;
    startDate: String;
    typeCode?: String;
    centerCode: String; // SO/SA
    taskId: String;
    clientLog: String; // SWP
    systemCode: String; //HLX /SOM
    priority: String; //50
    sourceType: String; //SWP
    installationAddress?: InstallationAddress;
    taskType: String;
    openDate: String;
    requiredDateFrom: String;
    requiredDateTo: String;
    slotType: String;
}

export interface GetAppointmentSlot {
    centerCode: String; // SO/SA
    installationAddress?: InstallationAddress;
    fromDate: String;
    durationInMinutes: String;
    sourceType: String; //SWP
    slotType: String;
    taskType: String;
    taskId?: String;
}

export interface SiteSurveyDetails {
    surveyDate?: String;
    surveyTime?: String;
    estDateOfActivation?: String;
    //surveySlot?: String;
    siteSurveyPOCName?: String;
    contactNumber?: String;
    attachment?: String;
    additionalInfo?: String;
}
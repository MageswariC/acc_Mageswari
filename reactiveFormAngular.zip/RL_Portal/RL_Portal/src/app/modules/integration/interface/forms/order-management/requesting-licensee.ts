export interface RequestingLicensee{
    readonly name?: String;
    readonly qpId?: String;
    readonly companyName?: String;
    readonly designation?: String;
    readonly companyPhoneNumber?: String;
    readonly companyFaxNumber? : String;
    readonly companyEmail?: String;
    

}
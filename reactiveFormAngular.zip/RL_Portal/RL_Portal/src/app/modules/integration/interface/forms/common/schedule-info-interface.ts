export interface ScheduleInfo {
    scheduleId: String;
    scheduleCode: String;
    scheduleName: String;
    serviceType: String;
}
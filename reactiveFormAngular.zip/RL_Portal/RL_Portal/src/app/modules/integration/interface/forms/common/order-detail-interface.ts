export interface Orderdetail{
    arnNo?: String;
    technology?: String;
    splitRatio?: String;
    redundancyService?: String;
    rejectRedundancyService?: String;
    contractTerm?: String;
    noOfConnectionRequired?: String;
    installationType?: String;
    noOfCable?: String;
    promoCode?: String;
    cableType?: String;
    cableSize?: String;
    cablePair?: String;
    cableDiameter?: String;
    segmentFromCO?: String;
    segmentToCO?: String;
    expectedDistance?: String;
    expectedDBLoss?: String;
    fibreRoutingMap?: String;
    attachment?: String;
}

















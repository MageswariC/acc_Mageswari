export interface Summary {
    applicationDetails?:String;
    coLoConnectionDetails?:String;
    summary?:string;
    connectionDetails?:String;
    additionalInfo?:String;
    oneTimeInstallationCharge?:string;
    mrc?:String;
}
export interface PriceDetails {
    readonly installationCharge? : String;
    readonly serviceActivationCharge? : String;
    readonly monthlyRecurringCharge?: String;
    noteMessage?: String;
}
export interface PricingDetail {
    bunldleName: String;
    productName: String;
    productDescription: String;
    mrcAmt: String;
    otcAmt: String;
    installationCharge?:String;
    serviceActivationCharge?:String;
    monthlyRecurringCharge?:String;
    redundancyinstallationCharge?:String;
    redundancyserviceActivationCharge?:String;
    redundancymonthlyRecurringCharge?:String;


}
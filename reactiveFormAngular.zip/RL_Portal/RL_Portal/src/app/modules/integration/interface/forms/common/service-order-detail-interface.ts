import { FeasibilityCheck } from "../order-management/feasibility-check";
import { ActivationDetail } from "./appointment-interface";
import { SOContactDetails } from "./endUserDetail-interface";
import { InstallationAddress } from "./installation-address-interface";
import { Orderdetail } from "./order-detail-interface";
import { PricingDetail } from "./pricing-interface";
import { ScheduleInfo } from "./schedule-info-interface";

export interface ServiceOrder {
    installationDetails?: InstallationAddress;
    orderDetails?: Orderdetail;
    activationDetails: ActivationDetail;
    endUserDetails?: SOContactDetails;
    pricingInfo?: PricingDetail;
    additionalInfo?: AdditionalInfo;
    otherInfo?: OtherInfo;
}
export interface AdditionalInfo {
    addInformation?:string
}
export interface OtherInfo {
    ori?: String;
    orderSource?: String;
    orderType?: String;
    revision?: String;
    reclasification?: String;
    scheduleId?: string;
    serviceType?:string;
    submissionDate?:any
}
export interface FeasibilityInfo {
  postalCode?: String;
  unitNumber?: String;
  addressOption?: String;
  coordinateSystem?: String;
  longitude?: String;
  latitude?: String;
  coID?: String;
  servingCabinet ?: String;
  fttbId  ?: String;
  orderOption?: String;
  ori?: String;
  coloRoomNo?: String;
  qtyOfDevice?: String;
  roomId?: String;
  qtyOfAc1Phase?: String;
  qtyOfAc3Phase?: String;
  qtyOfDcBreaker?: String;
  rackTable?: String;
  rackId?: String;
  weightOfDevice?: String;
  rackSize?: String;
  oriPortA?: String;
  oriPortB?: String;
  manHoleId?: String;
  typeOfLease?: String;


}

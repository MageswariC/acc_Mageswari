import { AppointmentDetails } from "../common/appointment-interface";
import { AttachmentDetail } from "../common/attachment-interface";
import { SAContactDetails, RlInfo } from "../common/endUserDetail-interface";
import { ScheduleInfo } from "../common/schedule-info-interface";
import { ServiceOrderDetail } from "../common/service-order-detail-interface";

export interface TroubleTicket {
 rlInfo:RlInfo,
 ticketCreationDetails: TicketCreationDetails,
 serviceOrderDetail: ServiceOrderDetail
 ticketDetails: TicketDetails,
 endUserContactDetails: SAContactDetails,
 secondaryRlDetails: SAContactDetails,
 engineerContactDetails: SAContactDetails,
 attachmentDetail: AttachmentDetail,
 appointmentDetail:AppointmentDetails
}

export interface TicketCreationDetails {
    opCoIncidentId: String;
    incidentInfo: IncidentInfo;
    coloServiceDetail?: ScheduleInfo;
    jointInvestigationLocation?: String;
    coDetail: String;
    coLocationRoom?: String;
}

export interface TicketDetails {
    ticketSummary: String;
    ticketDescription: String;
    serviceUnavailability:String;
    submissionType:String;
}

export interface IncidentInfo {
    incidentType: String;
    incidentTypeCode: String;
}
export interface InstallationAddress {
    postalCode?:string,
    unitNumber?:string,
    buildingType?: String;
    streetName?: String;
    town?: String;//Singapore
    county?:String;//SGP
    zone?: String;//SNG
    buildingName?: String;
    buildingHouseNo?: String;
    copifType?:String;
    coverageStatus?: String;
    firstPassIndicator?: String;
    physicalCo?: String;
    logicalCo?: String;
    firstTp?: String;
    coDetail?:String;
    feasibilityNote?:String;
    feasibilityStatus?:String;
    dataCenter?:String;
    dpName?:String;
    landmark?:String;
    addressOption?:String;
    coordinateSystem?:String;
    gpsXcoordinates?:String;
    gpsYcoordinates?:String;
    address?:String;
    cbdType?:String;
    coAddress?:String;
    height?:String;
    addressAEnd?:String;
    addressBEnd?:String;
    rackId?:String;
    descriptionOfAddress?:String;

}














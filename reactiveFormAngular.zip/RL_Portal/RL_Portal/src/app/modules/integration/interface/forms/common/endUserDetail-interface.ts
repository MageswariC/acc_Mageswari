export interface RlInfo {
    rlName: String;
    qpId: String;
    rlId:String;
    companyName: String;
    designation:String;
    faxNo: String;
    emailId:String;
    contactNo: String;
}

export interface SAContactDetails {
    firstName: String;
    lastName: String;
    contactNumber: String;
    emailAddress: String;
}

export interface SOContactDetails {
    salutation?: String;
    endUsername?: String;
    endUserContactNo?: String;
    endUserfax?: String
    endUserEmailId?: String;
    userType?: String;
}
export interface EndUSerContactDetails {
    salutation: String;
    endUsername: String;
    endUserContactNo: String;
    endUserfax?: String
    endUserEmailId: String;
    countryCode?:string;
    alternateContactNo?:String
}
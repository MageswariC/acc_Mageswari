
export interface ActivationDetails {
    timeSlotOption? : string;
    dateOfActivation? : any;
    installationTime?: string;
    installationType?:String;
    siteSurveyPOCName?:String;
    contactNumber?:String;
    email?:String;
    fileUpload?:String;
    additionalInfo?:String;
    promoCode?:String;
}
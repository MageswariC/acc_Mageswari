export interface EndUserDetails {
    applicationReferenceNo?:String;
    salutation?: String;
    userName? : String;
    phoneNumber? : String;
    alternatePhone? : String;
    faxNumber?: String;
    emailAddress: String;
    userType?: String;
    contractPeriod?:String;

}
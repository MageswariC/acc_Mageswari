export interface AttachmentDetail{
    fileName: String;
    fileType: String;
    fileSize: String;
    fileURL: String;
}

import { messages } from "src/app/components/utilities/error-message";
import validation from "src/app/components/utilities/validation";
const onSiteSurveyFcForm = {
    isORICheck:true,
 
    controls: [
        {
        isFcBtnrequired:true,
        heading: "ORI Check",
        id: "oriCheck",
        key: "oriCheck",
        options: {
            children: [
             
                {
                    key: "primaryCircuitORI",
                    type: "text",
                    value: "",
                    required: true,
                    visible: true,
                    label: "Primary Circuit ORI",
                    errorMsg: {"required":"Primary Circuit ORI is required"},
                    handler: () => {  },
                    validators: (validator: any) => [
                        validator.required,
                    ],
                  
                }              
            ]
        }
    }
    ]
}
export default  onSiteSurveyFcForm; 
    
import { messages } from '../../../utilities/error-message';
import validation from '../../../utilities/validation';
const ticketCreation = {
  onehrActivation: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              defaultValue: 'sfdgfdh',
              label: 'OpCo Indident ID',
              errorMsg: {},
              handler: () => {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: 'Fibre provisioning',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              defaultValue: '123456',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
            pattern: "Invalid ORI pattern eg...." },
              handler: () => {},
              validators: (validator: any) => [
                validator.required,
                validation.oneHourActivationORI(),
              ],
            },
          ],
        },
      },
    ],
  },
  fibreProvisioning: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              defaultValue: 'sfdgfdh',
              label: 'OpCo Indident ID',
              errorMsg: {},
              handler: () => {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: 'Fibre provisioning',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              defaultValue: '123456',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
            pattern: "Invalid ORI pattern eg...." },
              handler: () => {},
              validators: (validator: any) => [
                validator.required,
                validation.fibreProvisioningORI(),
              ],
            },
          ],
        },
      },
    ],
  },
  fibreMaintainence: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              defaultValue: 'sfdgfdh',
              label: 'OpCo Indident ID',
              errorMsg: {},
              handler: () => {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: 'Fibre provisioning',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              defaultValue: '123456',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
              pattern: "Invalid ORI pattern eg...." },
              handler: () => {},
              validators: (validator: any) => [
                validator.required,
                validation.fibreMaintainenceORI(),
              ],
            },
          ],
        },
      },
    ],
  },
 
  //         controls: [{
  //             heading: "Ticket Creation Details",
  //             id: "onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault",
  //             key: "ticketCreationDetails",
  //             options: {
  //                 children: [
  //                     {
  //                         key: "opCoIndidentId",
  //                         type: "text",
  //                         value: "",
  //                         defaultValue:"sfdgfdh",
  //                         label: "OpCo Indident ID",
  //                         errorMsg: {},
  //                         handler: () => { },
  //                         validators: (validator: any) => [

  //                         ]
  //                     },
  //                     {
  //                         key: "incidentType",
  //                         type: "select",
  //                         value: "",
  //                         defaultValue:"Fibre provisioning",
  //                         required: true,
  //                         label: "Incident Type",
  //                         option:['1 hour activation', 'Fibre provisioning', 'Joint investigation', 'Fibre maintenance', 'Fibre monitoring', 'CO-LOC Fault', 'OSS/BSS Fault'],
  //                         errorMsg: {},
  //                         handler: ({ component, ...rest }: any) => { component.changeIncidentType(rest) },
  //                         validators: (validator: any) => [
  //                             validator.required,
  //                         ]
  //                     },
  //                     {
  //                         key: "ori",
  //                         type: "text",
  //                         value: "",
  //                         defaultValue:"123456",
  //                         required: true,
  //                         label: "Order Request Identifier",
  //                         errorMsg: {},
  //                         handler: () => { },
  //                         validators: (validator: any) => [
  //                             validator.required,
  //                             validation.oneHourActivationORI()
  //                         ]
  //                     },

  //                 ]
  //             }
  //         }
  //         ]},
  // ossBssFault:{
  //     controls: [{
  //         heading: "Ticket Creation Details",
  //         id: "onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault",
  //         key: "ticketCreationDetails",
  //         options: {
  //             children: [
  //                 {
  //                     key: "opCoIndidentId",
  //                     type: "text",
  //                     value: "",
  //                     defaultValue:"sfdgfdh",
  //                     label: "OpCo Indident ID",
  //                     errorMsg: {},
  //                     handler: () => { },
  //                     validators: (validator: any) => [

  //                     ]
  //                 },
  //                 {
  //                     key: "incidentType",
  //                     type: "select",
  //                     value: "",
  //                     defaultValue:"Fibre provisioning",
  //                     required: true,
  //                     label: "Incident Type",
  //                     option:['1 hour activation', 'Fibre provisioning', 'Joint investigation', 'Fibre maintenance', 'Fibre monitoring', 'CO-LOC Fault', 'OSS/BSS Fault'],
  //                     errorMsg: {},
  //                     handler: ({ component, ...rest }: any) => { component.changeIncidentType(rest) },
  //                     validators: (validator: any) => [
  //                         validator.required,
  //                     ]
  //                 },
  //                 {
  //                     key: "ori",
  //                     type: "text",
  //                     value: "",
  //                     defaultValue:"123456",
  //                     required: true,
  //                     label: "Order Request Identifier",
  //                     errorMsg: {},
  //                     handler: () => { },
  //                     validators: (validator: any) => [
  //                         validator.required,
  //                         validation.oneHourActivationORI()
  //                     ]
  //                 },

  //             ]
  //         }
  //     }
  //     ]},
  jointInvestigation: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'jointInvestigation',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              label: 'OpCo Indident ID',
              errorMsg: {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: '',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'jointInvestigationLocation',
              type: 'select',
              value: '',
              label: 'Joint Investigation Location',
              required: true,
              option: ['CO-LOC', 'Serving-Cabinet', 'End-User Premises'],
              errorMsg: { required: 'Joint Investigation Locationis required' },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
              pattern: "Invalid ORI pattern eg...." },
              validators: (validator: any) => [
                validator.required,
                validation.jointInvestigationORI(),
              ],
            },
          ],
        },
      },
    ],
  },
  CO_LOC_Fault: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'CO_LOC_Fault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              label: 'OpCo Indident ID',
              errorMsg: {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: '',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },

            {
              key: 'cOLoDetails',
              type: 'text',
              value: '',
              label: 'Co Details',
              required: true,
              errorMsg: { required: 'Co Details is required' },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'cOLocationRoom',
              type: 'text',
              value: '',
              label: 'CO-Location Room',
              required: true,
              errorMsg: { required: 'CO-Location Room is required' },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'cOLocationServiceType',
              type: 'select',
              value: '',
              label: 'CO-Location Service Type',
              required: true,
              option: ['CO-LOC Fault', 'RL-RL Fault'],
              errorMsg: { required: 'CO-Location Service Type is required' },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
            pattern: "Invalid ORI pattern eg...." },
              validators: (validator: any) => [
                validator.required,
                validation.coLocORI(),
              ],
            },
          ],
        },
      },
    ],
  },
  fibreMonitoring: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'fibreMonitor_ossBssFault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              defaultValue: '1 hour activation',
              label: 'OpCo Indident ID',
              errorMsg: {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: '1 hour activation',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              required: true,
              label: 'Order Request Identifier',
              errorMsg: { required: 'Order Request Identifier is required',
            pattern: "Invalid ORI pattern eg...." },
              validators: (validator: any) => [
                validator.required,
                validation.fiberMonitoringORI(),
              ],
            },
          ],
        },
      },
    ],
  },
  ossBssFault: {
    controls: [
      {
        heading: 'Ticket Creation Details',
        id: 'fibreMonitor_ossBssFault',
        key: 'ticketCreationDetails',
        options: {
          children: [
            {
              key: 'opCoIndidentId',
              type: 'text',
              value: '',
              defaultValue: '1 hour activation',
              label: 'OpCo Indident ID',
              errorMsg: {},
              validators: (validator: any) => [],
            },
            {
              key: 'incidentType',
              type: 'select',
              value: '',
              defaultValue: '1 hour activation',
              required: true,
              label: 'Incident Type',
              option: [
                '1 hour activation',
                'Fibre provisioning',
                'Joint investigation',
                'Fibre maintenance',
                'Fibre monitoring',
                'CO-LOC Fault',
                'OSS/BSS Fault',
              ],
              errorMsg: { required: 'Incident Type is required' },
              handler: ({ component, ...rest }: any) => {
                component.changeIncidentType(rest);
              },
              validators: (validator: any) => [validator.required],
            },
            {
              key: 'ori',
              type: 'text',
              value: '',
              label: 'Order Request Identifier',
              errorMsg: { 
              pattern: "Invalid ORI pattern eg...." },
              validators: (validator: any) => [
                validation.fiberMonitoringORI(),
              ],
            },
          ],
        },
      },
    ],
  },
};
export default ticketCreation;

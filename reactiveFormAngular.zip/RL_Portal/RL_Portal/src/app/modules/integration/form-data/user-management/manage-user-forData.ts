const manageUserFormData = {
    "controls": [
        {
            "heading": "User Detail",
            visible:true,
            "createOrder":true,
            "id": "userInfo",
            "key": "userInfo",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "userId",
                        "type": "text",
                        "value": "",
                        "label": "User Id",
                        "readOnly":true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "billingId",
                        "type": "multiSelect",
                        "value": "",
                        "required":true,
                        "visible": true,
                        "selectedOptions":['02'],
                        // "readOnly":true,
                        "label": "Billing ID",
                         "option": ["01","02","03","04"],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "company",
                        "type": "text",
                        "value": "",
                        "label": "Company",
                        "readOnly":true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "emailId",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Alternate Email Address",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    
                    {
                        "key": "principalName",
                        "type": "text",
                        "value": "",
                        required:true,
                        visible: true,
                        "label": "Principal Name",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "designation",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Designation",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "contactNo",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Contact No",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "faxNo",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Fax No",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "expiryDate",
                        "type": "date",
                        "label": "Expiry Date",
                        "value": "",
                        // "required": true,
                        visible:true,
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "priorityCircuit",
                        "type": "checkbox",
                        "label": "Priority Circuit",
                        "option": ["Yes"],
                        "value": "",
                        visible:true,
                        "validators": (validator: any) => [
                        ]
                    }
                ]
            }
        },
        {
            "heading": "User Role",
            visible:true,
            "createOrder":true,
            "id": "role",
            "key": "role",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "availableRoles",
                        "type": "multiSelect",
                        "value": "",
                       // "required":true,
                        "visible": true,
                    
                        // "readOnly":true,
                        "label": "Available Roles",
                         "option": ["RL Admin","RL User","Finance User","Trouble Ticket User"],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "assignedRoles",
                        "type": "multiSelect",
                        "value": "",
                       // "required":true,
                        "visible": true,
                       // "selectedOptions":[''],
                        // "readOnly":true,
                        "label": "Assigned Roles",
                         "option": ["RL Admin","RL User","Finance User","Trouble Ticket User"],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                
                ]
            }
        }
    ]
}
export default manageUserFormData;
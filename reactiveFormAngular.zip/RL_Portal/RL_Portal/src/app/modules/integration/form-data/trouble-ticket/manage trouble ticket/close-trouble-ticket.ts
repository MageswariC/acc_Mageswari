import { Validators } from "@angular/forms";
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";
const closeTroubleTicket = {
    "controls": [
        {      cancelOrder:true,
            "heading": "Ticket Details",
            visible:true,
            "createOrder":true,
            "id": "ticketDetails",
            "key": "ticketDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "incidentID",
                        "type": "text",
                        "value": "",
                        "required": true,
                        "readOnly":true,
                        "label": " Incident Ticket ID",
                         visible:true,
                        "errorMsg":  {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "reason",
                        "type": "textarea",
                        "value": "",
                        "required": true,
                        visible:true,
                        "label": "Reason",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                  
                       ]
            }
        },
    
         
    ]
}
export default closeTroubleTicket;
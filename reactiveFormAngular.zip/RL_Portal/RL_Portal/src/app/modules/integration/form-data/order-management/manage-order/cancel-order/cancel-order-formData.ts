import { messages } from 'src/app/components/utilities/error-message';
import validation from '../../../../../../components/utilities/validation';
const cancelOrder = {
  controls: [
    {
      "heading": "Cancel Application Details",
      visible:true,
      "createOrder":true,
      "id": "cancelOrderDetails",
      "key": "cancelOrderDetails",
      "type": "group",
      options: {
        children: [
          {
            key: 'arnNo',
            type: 'text',
            value: '',
            visible: true,
            readOnly: true,
            label: 'Application Reference Number',
            errorMsg: { required: 'Application Reference Number is required' },
            validators: (validator: any) => [],
          },
          {
            key: 'ori',
            type: 'text',
            value: '',
            visible: true,
            readOnly: true,
            label: 'Order Request Identifier',
            errorMsg: { required: 'Order Request Identifier is required' },
            validators: (validator: any) => [],
          },
          {
            key: 'additionalInfo',
            type: 'textarea',
            value: '',
            visible: true,
            label: 'Additional Info',
            errorMsg: messages.get('additionalInformation'),
            validators: (validator: any) => [validator.maxLength(254)],
          },
          {
            key: 'terminationCharges',
            type: 'textarea',
            value: '',
            visible: true,
            label: 'Early Termination Charges',
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
  ],
};
export default cancelOrder;

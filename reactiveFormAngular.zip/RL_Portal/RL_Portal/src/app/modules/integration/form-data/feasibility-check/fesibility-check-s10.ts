
import { messages } from "../../utilities/error-message";
import validation from "../../utilities/validation";
const fesibilityFormS5 = {
//     postalCode:{
//     controls: [{
//         isFcBtnrequired:true,
//         heading: "Feasibility Check",
//         id: "feasibilityCheck",
//         key: "feasibilityCheck",
//         options: {
//             children: [
//                 {
//                     "key": "technology",
//                     "type": "radio",
//                     "label": "Address Options",
//                     "value": "",
//                     "required": true,
//                     visible:true,
//                     "option": [{
//                         "value": "Postal Code",
//                         "checked": true,
//                         "disable": false
//                     },
//                     {
//                         "value": "Coordinate System",
//                         "checked": false,
//                         "disable": false
//                     }],
//                     "handler": ({ component, ...rest }: any) => { component.changeTechnology(rest) },
//                     "errorMsg": messages.get('technology'),
//                     "validators": (validator: any) => [
//                         validator.required,
//                     ]
//                 },
//                 {
//                     key: "postalCode",
//                     type: "text",
//                     value: "",
//                     required: true,
//                     visible: true,
//                     label: "Postal Code",
//                     errorMsg: messages.get('postalCode'),
//                     validators: (validator: any) => [
//                         validator.required,
//                         validation.postalCode()
//                     ]
//                 },
//                 {
//                     key: "coordinateSystem",
//                     type: "select",
//                     value: "SVY21",
//                     required: true,
//                     visible: true,
//                     label: "Coordinate System",
//                     option: ['SVY21', 'WGS84'],
//                     errorMsg: {
//                         required: "Coordinate System is required",
//                     },
//                     handler: ({ component, ...rest }: any) => { component.changeCoordinateSystem(rest) },
//                     validators: (validator: any) => [
//                         validator.required,

//                     ]
//                 },
//                 {
//                     key: "gpsXcoordinates",
//                     type: "text",
//                     value: "",
//                     required: true,
//                     visible: true,
//                     label: "GPS X co-ordinates",
//                     errorMsg: messages.get('GPSXcoOordinates'),
//                     validators: (validator: any) => [
//                         validator.required,
//                         validation.fraction3Dec()
//                     ]
//                 },
//                 {
//                     key: "gpsYcoordinates",
//                     type: "text",
//                     value: "",
//                     label: "GPS Y co-ordinates",
//                     required: true,
//                     visible: true,
//                     errorMsg: messages.get('GPSYcoOordinates'),
//                     validators: (validator: any) => [
//                         validator.required,
//                         validation.fraction3Dec()
//                     ]
//                 },
                
//             ]
//         }
//     }
//     ]
// }
postalCode:{ 
    controls: [{
      isFcBtnrequired:true,
      heading: 'Feasibility Check',
      id: 'feasibilityCheck',
      key: 'feasibilityCheck',
      hide:false,
      options: {
        children: [
            {
                key: "addressOptions",
                type: "radio",
                label: "Address Options",
                value: "",
                required: true,
                visible:true,
                defaultValue: "Postal Code",
                option: [{
                    value: "Postal Code",
                    checked: true,
                    disable: false
                },
                {
                    value: "Coordinate System",
                    checked: false,
                    disable: false
                }],
                handler: ({ component, ...rest }: any) => { component.changePostalToGps(rest) },
                errorMsg: messages.get('technology'),
                validators: (validator: any) => [
                    validator.required,
                ]
            },
            {
                key: "postalCode",
                type: "text",
                value: "",
                required: true,
                visible: true,
                label: "Postal Code",
                errorMsg: messages.get('postalCode'),
                validators: (validator: any) => [
                    validator.required,
                    validation.postalCode()
                ]
            },
        ],
      },
    },
]},
coOrdinateSystem: {
    controls: [{
        isFcBtnrequired:true,
        heading: 'Feasibility Check',
        id: 'feasibilityCheck',
        key: 'feasibilityCheck',
        hide:false,
        options: {
          children: [
              {
                  key: "addressOptions",
                  type: "radio",
                  label: "Address Options",
                  value: "",
                  required: true,
                  visible:true,
                  defaultValue: "Coordinate System",
                  option: [{
                      value: "Postal Code",
                      checked: false,
                      disable: false
                  },
                  {
                      value: "Coordinate System",
                      checked: true,
                      disable: false
                  }],
                  handler: ({ component, ...rest }: any) => { component.changePostalToGps(rest) },
                  errorMsg: messages.get('technology'),
                  validators: (validator: any) => [
                      validator.required,
                  ]
              },
              {
                  key: "coordinateSystem",
                  type: "select",
                  value: "SVY21",
                  required: true,
                  visible: true,
                  label: "Coordinate System",
                  option: ['SVY21', 'WGS84'],
                  errorMsg: {
                      required: "Coordinate System is required",
                  },
                  handler: ({ component, ...rest }: any) => { },
                  validators: (validator: any) => [
                      validator.required,
  
                  ]
              },
              {
                  key: "gpsXcoordinates",
                  type: "text",
                  value: "",
                  required: true,
                  visible: true,
                  label: "GPS X co-ordinates",
                  errorMsg: messages.get('GPSXcoOordinates'),
                  validators: (validator: any) => [
                      validator.required,
                      validation.fraction3Dec()
                  ]
              },
              {
                  key: "gpsYcoordinates",
                  type: "text",
                  value: "",
                  label: "GPS Y co-ordinates",
                  required: true,
                  visible: true,
                  errorMsg: messages.get('GPSYcoOordinates'),
                  validators: (validator: any) => [
                      validator.required,
                      validation.fraction3Dec()
                  ]
              },
          ],
        },
      }, 
]}
}
export default fesibilityFormS5;
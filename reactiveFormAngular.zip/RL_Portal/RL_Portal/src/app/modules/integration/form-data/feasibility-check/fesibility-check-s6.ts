
import { messages } from "../../utilities/error-message";
import validation from "../../utilities/validation";
const fesibilityFormS6 = {
    controls: [{
        isFcBtnrequired:true,
        heading: "Feasibility Check",
        id: "feasibilityCheck",
        key: "feasibilityCheck",
        options: {
            children: [

                {
                    key: "orderOption",
                    type: "radio",
                    value: " ",
                    required: true,
                    visible: true,
                    default : "Postal Code",
                    label: "Order Option",
                    errorMsg: messages.get('orderOption'),
                    "option": [{
                        "value": "Postal Code",
                        "checked": true,
                        "disable": false
                    },
                    {
                        "value": "FTTB ID",
                        "checked": false,
                        "disable": false
                    }],
                    handler: ({ component, ...rest }: any) => { component.changeOrderOption(rest) },
                    validators: (validator: any) => [
                        validator.required,
                    ]

                },
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    required: true,
                    visible: true,
                    label: "Postal Code",
                    errorMsg: messages.get('postalCode'),
                    validators: (validator: any) => [
                         validator.required,
                         validation.postalCode()
                    ]
                },
                {
                    key: "fttbid",
                    type: "text",
                    value: "",
                    required: false,
                    visible: false,
                    label: "FTTB ID",
                    errorMsg:{}, //messages.get('postalCode'),
                        validators: (validator: any) => [
                              //validator.required
                        ]
                },
                {
                    key: 'checkFeasibility',
                    type: 'button',
                    value: 'Check Feasibility',
                    label: '',
                    errorMsg: {},
                    handler: ({ component, ...rest }: any) => {
                      component.checkFeasibility(rest);
                    },
                    validators: (validator: any) => [validation.unitNumber()],
                  },
                
            ]
        }
    }
    ]
}
export default fesibilityFormS6;
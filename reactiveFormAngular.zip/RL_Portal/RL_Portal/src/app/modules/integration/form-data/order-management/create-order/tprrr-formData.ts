
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const TPRRRFormData = {
    "controls": [
        {
            "heading": "TP Details",
            visible:true,
            "createOrder":true,
            "id": "tpDetails",
            "key": "tpDetails",
            "type": "group",
            "options": {
                "children": [{
                    "key": "tpName",
                    "type": "text",
                    "value": "",
                    required:true,
                    visible: true,
                    "readOnly":true,
                    "label": "TP Name",
                    "errorMsg": {},
                    "validators": (validator: any) => [
                        // validator.required,
                    ]
                },
                    {
                        "key": "operation",
                        "type": "select",
                        "value": "",
                        required:true,
                        visible: true,
                        "label": "Operation to be Performed",
                        "option": ['TP Relocation','TP Repair/Replacement/Removal'],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    }
                ]
            }
        },
        {
            "heading": "Installation Address",
            visible:true,
            "createOrder":true,
            "id": "installationAddress",
            "key": "installationAddress",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "blockHouseNumber",
                        "type": "text",
                        "value": "",
                        visible: true,
                        required:true,
                        "readOnly": true, 
                        "label": "Block/House Number",
                        "option": ['4A','4B','4C'],
                        "errorMsg": messages.get('houseNo'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "buildingName",
                        "type": "text",
                        "value": "",
                        "label": "Building Name",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "streetName",
                        "type": "text",
                        "value": "",
                        "label": "Street Name",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "unitNumber",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "Unit Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "postalCode",
                        "type": "text",
                        "value": "",
                        "label": "Postal Code",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "",
                        "option": ["HDB"],
                        "readOnly": true, 
                        required:true,
                        visible: true,
                        "label": "Building Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "coverageStatus",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "Coverage Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "copifType",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "COPIF Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "tpName",
                        "type": "text",
                        "value": "",
                        visible: true,
                        readOnly:true,
                        "label": "TP Name",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                ]
            }
        },
        {
            "heading": "Application Details",
            visible:true,
            "id": "endUserDetails",
            "key": "endUserDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "name",
                        "type": "text",
                        "value": "",
                        "label": "Name",
                        "required": true,
                        visible:true,
                        "errorMsg": messages.get('name'),
                        "validators": (validator: any) => [
                            validator.required,
                            validation.name()
                        ]
                    },
                    {
                        "key": "contactNumber",
                        "type": "text",
                        "value": "",
                        "label": "Contact Number",
                        "required": true,
                        visible:true,
                        "errorMsg": messages.get('contactNumber'),
                        "validators": (validator: any) => [
                            validator.required,
                            validation.phoneNumber()
                        ]

                    },
                    {
                        "key": "faxNumber",
                        "type": "text",
                        "value": "",
                        "label": "Fax Number",
                        visible:true,
                        "errorMsg": messages.get('faxNumber'),
                        "validators": (validator: any) => [
                            validation.phoneNumber()
                        ]


                    },

                    {
                        "key": "emailAddress",
                        "type": "email",
                        "label": "Email Address",
                        "required": true,
                        visible:true,
                        "errorMsg": messages.get('emailAddress'),
                        "validators": (validator: any) => [
                            validator.required,
                            validation.emailAddress()
                        ]

                    },
            
                ]
            }
        },
        {
            "heading": "Activation Details",
            visible:true,
            "id": "activationDetails",
            "key": "activationDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "timeSlotOption",
                        "type": "radio",
                        "label": "Timeslot Option",
                        "value": "",
                        "required": true,
                        visible:true,
                        "option": [{
                            "value": "Normal",
                            "checked": true,
                            "disable": false
                        },
                        {
                            "value": "Seasonal",
                            "checked": false,
                            "disable": false
                        }],
                        "errorMsg": {
                        },
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "dateOfActivation",
                        "type": "date",
                        "label": "Date of Activation",
                        "value": "",
                        "required": true,
                        visible:true,
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "installationTime",
                        "type": "select",
                        "value": "",
                        "required": true,
                        visible:true,
                        "label": "Installation Time",
                        "option": ['12PM', '6PM'],
                        "errorMsg": messages.get('installationTime'),
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "reverseAppointment",
                        "type": "button",
                        "value": "Reserve Appointment",
                        "label": "",
                        visible:true,
                        "validators": (validator: any) => [
                        ]
                    },
                ]
            }
        },
        {
            "heading": "Additional Information",
            visible:true,
            "id": "additionalInformation",
            "key": "additionalInformation",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "addInformation",
                        "type": "textarea",
                        "label": "Additional Information",
                        visible:true,
                        "validators": (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


                ]
            }
        },
    ]
}
export default TPRRRFormData;
// import { AllShedule } from '../../../interface/forms/order-management/all-shedule';
// import cDate from '../../../utilities/date';
import cDate from '../../../../utilities/date';
export const residentialConnectionModal = {
  installationAddress: {
    buildingName: 'OLEANDER BREEZE',
    streetName: 'YISHUN STREET 51',
    unitNumber: '#01-01',
    postalCode: '504302',
    buildingType: 'HDB',
    coverageStatus: 'Home Reached',
    copifType: 'Pre-Copif',
    dataCenter: 'data',
    networkStatus: '1223',
    tpName: '123',
  },

  activationDetails: {
    timeSlotOption: 'Seasonal',
    // dateOfActivation: cDate.formatDate(new Date()),
    installationTime: '12PM',
  },

  tpName: {
    primarycircuitori: '123456',
  },
};

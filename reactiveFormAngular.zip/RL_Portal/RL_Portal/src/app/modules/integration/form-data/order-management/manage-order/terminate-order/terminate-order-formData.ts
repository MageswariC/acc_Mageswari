import { messages } from 'src/app/components/utilities/error-message';
const cancelOrder = {
  controls: [
    {
      title: 'Terminate Order',
      terminateOrder: true,
      heading: 'Terminate Application Details',
      visible: true,
      id: 'terminateAppDetails',
      key: 'terminateAppDetails',
      type:"group",
      
      options: {
        children: [
          {
            key: 'arnNo',
            type: 'text',
            value: '',
            readOnly: true,
            visible: true,
            label: 'Application Reference Number',
            errorMsg: { required: 'Application Reference Number is required' },
            validators: (validator: any) => [],
          },
          {
            key: 'ori',
            type: 'text',
            value: '',
            readOnly: true,
            visible: true,
            label: 'Order Request Identifier',
            errorMsg: { required: 'Order Request Identifier is required' },
            validators: (validator: any) => [],
          },
          {
            key: 'terminateDate',
            type: 'date',
            value: '',
            required: true,
            visible: true,
            label: 'Terminate Date',
            errorMsg: { required: 'Terminate Date is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'additionalInfo',
            type: 'textarea',
            value: '',
            visible: true,
            label: 'Additional Info',
            errorMsg: messages.get('additionalInformation'),
            validators: (validator: any) => [validator.maxLength(254)],
          },
          {
            key: 'terminationCharges',
            type: 'textarea',
            value: '',
            visible: true,
            label: 'Early Termination Charges',
            errorMsg: {},
            validators: (validator: any) => [validator.required],
          },
        ],
      },
    },
  ],
};
export default cancelOrder;

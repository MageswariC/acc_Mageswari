
import { messages } from "../../../../utilities/error-message";
import validation from "../../../../utilities/validation";

const siteRequestSelection = {
    "controls": [
        {
            heading: "Request Selection",
            visible:true,
            id: "requestSelection",
            key: "requestSelection",
            type: "group",
            options: {
                children: [
                    {
                        key: 'requestType',
                        type: 'radio',
                        label: 'Request Type',
                        defaultValue: '',
                        required: true,
                        visible: true,
                        option: [
                          {
                            value: 'Pre-Order Site Survey',
                            checked: true,
                            disable: false,
                          },
                          {
                            value: 'Onsite Visit',
                            checked: false,
                            disable: false,
                          },
                        ],
                        handler: ({ component, ...rest }: any) => {
                          component.onChangeRequestType(rest);
                        },
                        errorMsg: messages.get('requestType'),
                        validators: (validator: any) => [validator.required],
                      },            
                ]
            }
        },
        
      
      
    ]
}
export default siteRequestSelection;
import { messages } from '../../../../utilities/error-message';
import validation from '../../../../utilities/validation';

const residentialEndUserConnectionFormData = {
  controls: [
    {
      heading: 'Installation Address',
      createOrder: true,
      visible: true,
      id: 'installationAddress',
      key: 'installationAddress',
      type: 'group',
      options: {
        children: [
          {
            key: 'blockHouseNumber',
            type: 'text',
            value: '',
            visible: true,
            readOnly: true,
            label: 'Block/House Number',
            errorMsg: messages.get('houseNo'),

            validators: (validator: any) => [],
          },
          {
            key: 'buildingName',
            type: 'text',
            value: '',
            label: 'Building Name',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'streetName',
            type: 'text',
            value: '',
            label: 'Street Name',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'unitNumber',
            type: 'text',
            value: '',
            readOnly: true,
            visible: true,
            label: 'Unit Number',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'postalCode',
            type: 'text',
            value: '',
            label: 'Postal Code',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'buildingType',
            type: 'text',
            value: '',
            // "option": ["HDB"],
            readOnly: true,
            visible: true,
            label: 'Building Type',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'coverageStatus',
            type: 'text',
            value: '',
            readOnly: true,
            visible: true,
            label: 'Coverage Status',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'copifType',
            type: 'text',
            value: '',
            readOnly: true,
            visible: true,
            label: 'COPIF Type',
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Order Details',
      visible: true,
      id: 'orderDetails',
      key: 'orderDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'appRefIdentifier',
            type: 'text',
            value: '',
            required: true,
            visible: true,
            label: 'Application Reference Identifier',
            errorMsg: messages.get('applicationReferenceIdentifier'),
            validators: (validator: any) => [
              validator.required,
              validator.maxLength(50),
            ],
          },
          {
            key: 'technology',
            type: 'radio',
            label: 'Technology',
            value: '',
            readOnly: true,
            visible: true,
            option: [
              {
                value: 'GPON',
                checked: true,
                disable: true,
              },
              {
                value: 'OE',
                checked: false,
                disable: true,
              },
            ],
            handler: ({ component, ...rest }: any) => {
              component.changeTechnology(rest);
            },
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'splitRatio',
            type: 'radio',
            readOnly: true,
            visible: true,
            label: 'Split Ratio',
            value: '',

            option: [
              {
                value: '1:1',
                checked: true,
                disable: true,
              },
              {
                value: '1:24',
                checked: false,
                disable: true,
              },
              {
                value: '2:24',
                checked: false,
                disable: true,
              },
            ],
            errorMsg: {},

            validators: (validator: any) => [],
          },
          {
            key: 'redundancyService',
            type: 'radio',
            label: 'Redundancy Service',
            value: '',
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: [
              {
                value: 'Yes',
                checked: false,
                disable: true,
              },
              {
                value: 'No',
                checked: true,
                disable: true,
              },
            ],
            handler: ({ component, ...rest }: any) => {
              component.changeRedundancyService(rest);
            },
            validators: (validator: any) => [],
          },
          {
            key: 'rejectIfredundancyService',
            type: 'radio',
            label: 'Reject If Redundancy Service Unavailable',
            value: '',
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: [
              {
                value: 'Yes',
                checked: false,
                disable: true,
              },
              {
                value: 'No',
                checked: true,
                disable: true,
              },
            ],
            validators: (validator: any) => [],
          },
          {
            key: 'contractTerm',
            type: 'text',
            label: 'Contract Term',
            value: '',
            readOnly: true,
            visible: true,
            errorMsg: {},
            // "option": ['12 Months'],
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'promoCode',
            type: 'select',
            label: 'Promo Code',
            value: '',
            option: ['M1MOECODXXX', 'VQLGAXXXXXXX'],
            visible: true,
            readOnly:true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Activation Details',
      visible: true,
      id: 'activationDetails',
      key: 'activationDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'timeSlotOption',
            type: 'radio',
            label: 'Timeslot Option',
            defaultValue: 'Normal',
            required: true,
            visible: true,
            // readOnly: true,
            // disable:true,
            option: [
              {
                value: 'Normal',
                checked: true,
                disable: true,
              },
              {
                value: 'Seasonal',
                checked: false,
                disable: true,
              },
            ],
            errorMsg: {},
           
            handler: ({ component, ...rest }: any) => {
              component.timeSlotOptionChange(rest);
            },
            validators: (validator: any) => [],
          },

          {
            key: 'dateOfActivation',
            type: 'date',
            label: 'Date of Activation',
            defaultValue: '',
            required: true,
            visible: true,
            readOnly: true,
            dateFrom: [],
            dateTo: [],
            disableIcon: true,
            errorMsg: { required: 'Date of Activation is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'installationTime',
            type: 'select',
            defaultValue: '',
            required: true,
            visible: true,
            label: 'Installation Time',
            // option: ["1-3","3-5"],
            option: [],
            readOnly: true,
            handler: ({ component, ...rest }: any) => {
              component.installationTimeChange(rest);
            },
            errorMsg: { required: 'Installation Time is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'reverseAppointment',
            type: 'button',
            // showButtons:false,
            value: 'Reschedule Appointment',
            label: '',
            visible: true,
            readOnly: false,
            handler: ({ component, ...rest }: any) => {
              component.reverseAppointment(rest);
            },
            errorMsg: {},
            validators: (validator: any) => [],
          },
          // {
          //   key: 'reverseAppointment',
          //   type: 'button',
          //   // showButtons:false,
          //   value: 'Reserve Appointment',
          //   label: '',
          //   visible: true,
          //   readOnly: false,
          //   handler: ({ component, ...rest }: any) => {
          //     component.reverseAppointment1(rest);
          //   },
          //   errorMsg: {},
          //   validators: (validator: any) => [],
          // },
        ],
      },
    },
    {
      heading: 'End User Details',
      visible: true,
      id: 'endUserDetails',
      key: 'endUserDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'salutation',
            type: 'text',
            label: 'Salutation',
            readOnly: true,
            visible: true,
            errorMsg: {},
            //"option": ['Mr', 'Mrs', 'Miss'],
            validators: (validator: any) => [],
          },

          {
            key: 'userName',
            type: 'text',
            value: '',
            label: 'Name',
            readOnly: true,
            visible: true,
            errorMsg: messages.get('name'),
            validators: (validator: any) => [
              validator.required,
              validation.name(),
            ],
          },
          {
            key: 'phoneNumber',
            type: 'text',
            value: '',
            label: 'Contact Number',
            required: true,
            visible: true,
            errorMsg: messages.get('contactNumber'),
            validators: (validator: any) => [
              validator.required,
              validation.phoneNumber(),
            ],
          },
          {
            key: 'faxNumber',
            type: 'text',
            value: '',
            label: 'Fax Number',
            visible: true,
            readOnly: true,
            errorMsg: messages.get('faxNumber'),
            validators: (validator: any) => [validation.phoneNumber()],
          },

          {
            key: 'emailAddress',
            type: 'email',
            label: 'Email Address',
            required: true,
            visible: true,
            errorMsg: messages.get('emailAddress'),
            validators: (validator: any) => [
              validator.required,
              validation.emailAddress(),
            ],
          },
          
        ],
      },
    },
    {
      heading: 'Price Details',
      visible: true,
      id: 'priceDetails',
      key: 'priceDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'installationCharge',
            type: 'text',
            label: 'Installation Charge',
            readOnly: true,
            visible: true,
            value: '',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'serviceActivationCharge',
            type: 'text',
            value: '',
            label: 'Service Activation Charge',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'monthlyRecurringCharge',
            type: 'text',
            value: '',
            label: 'Monthly Recurring Charge',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'noteMessage',
            type: 'message',
            value: '',
            label:
              'Note: Pricing shown is indicative and actual price will be shown in the invoice.',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Additional Information',
      visible: true,
      id: 'additionalInformation',
      key: 'additionalInformation',
      type: 'group',
      options: {
        children: [
          {
            key: 'addInformation',
            type: 'textarea',
            label: 'Additional Information',
            visible: true,
            errorMsg: messages.get('additionalInformation'),
            validators: (validator: any) => [validator.maxLength(254)],
          },
        ],
      },
    },
  ],
  

};
export default residentialEndUserConnectionFormData;

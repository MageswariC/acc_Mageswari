
import { messages } from "src/app/components/utilities/error-message";
import validation from "src/app/components/utilities/validation";
import { masks } from "src/app/modules/integration/utilities/inputMasks";

const preOrderSiteSurveyForm = {
    "controls": [
        {
            "heading": " Residential Installation Address",
            visible: false,
            "createOrder": true,
            "id": "residentialInstallationAddress",
            "key": "residentialInstallationAddress",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "blockHouseNumber",
                        "type": "text",
                        "value": "",
                        visible: true,
                        required: true,
                        "readOnly": true,
                        "label": "Building Number",
                        "errorMsg": messages.get('houseNo'),
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingName",
                        "type": "text",
                        "value": "",
                        "label": "Building Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "streetName",
                        "type": "text",
                        "value": "",
                        "label": "Street Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "unitNumber",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "Unit Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "postalCode",
                        "type": "text",
                        "value": "",
                        "label": "Postal Code",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        required: true,
                        visible: true,
                        "label": "Building Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "coverageStatus",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "Coverage Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "copifType",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "COPIF Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },

                ]
            }
        },
        {
            "heading": "Non Residential Installation Address",
            visible: false,
            "createOrder": true,
            "id": "nonResidentialInstallationAddress",
            "key": "nonResidentialInstallationAddress",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "blockHouseNumber",
                        "type": "text",
                        "value": "",
                        visible: true,
                        required: true,
                        "readOnly": true,
                        "label": "Building Number",
                        "errorMsg": messages.get('houseNo'),
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingName",
                        "type": "text",
                        "value": "",
                        "label": "Building Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "streetName",
                        "type": "text",
                        "value": "",
                        "label": "Street Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "unitNumber",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "Unit Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "postalCode",
                        "type": "text",
                        "value": "",
                        "label": "Postal Code",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        required: true,
                        visible: true,
                        "label": "Building Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "coverageStatus",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "Coverage Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "copifType",
                        "type": "text",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "label": "COPIF Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "dataCenter",
                        "type": "text",
                        "value": "",
                        visible: true,
                        readOnly: true,
                        "label": "Data Center",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                ]
            }
        },
        {
            "heading": "Order Details",
            visible: true,
            "id": "orderDetails",
            "key": "orderDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "applicationReferenceIdentifier",
                        "type": "text",
                        "value": "",
                        "label": "Application Reference Identifier",
                        "required": true,
                        visible: true,
                        inputMask:masks.arn,
                        "errorMsg": messages.get('name'),
                        "validators": (validator: any) => [
                            validator.required,
    
                        ]
                    },

                ]
            }
        },
        {
            "heading": "Site Survey Details",
            visible: true,
            "id": "siteSurveyDetails",
            "key": "siteSurveyDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "timeSlotOption",
                        "type": "radio",
                        "label": "Timeslot Option",
                        "value": "",
                        "required": true,
                        visible: true,
                        "option": [{
                            "value": "Normal",
                            "checked": true,
                            "disable": false
                        },
                        {
                            "value": "Seasonal",
                            "checked": false,
                            "disable": false
                        }],
                        "errorMsg": {
                        },
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "dateOfActivation",
                        "type": "date",
                        "label": "Date of Activation",
                        "value": "",
                        "required": true,
                        visible: true,
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "installationTime",
                        "type": "select",
                        "value": "",
                        "required": true,
                        visible: true,
                        "label": "Installation Time",
                        "option": ['12PM', '6PM'],
                        "errorMsg": messages.get('installationTime'),
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "reverseAppointment",
                        "type": "button",
                        "value": "Reserve Appointment",
                        "label": "",
                        visible: true,
                        "validators": (validator: any) => [
                        ]
                    },
                ]
            }
        },
        {
            "heading": "End User Details",
            visible: true,
            "id": "endUserDetails",
            "key": "endUserDetails",
            "type": "group",
            "options": {
                "children": [{
                    key: "salutation",
                    type: "select",
                    label: "Salutation",
                    required: true,
                    visible: true,
                    errorMsg: messages.get('authSalutation'),
                    option: ['Mr', 'Mrs', 'Miss'],
                    validators: (validator: any) => [
                        validator.required,
                    ]
                },
                {
                    "key": "name",
                    "type": "text",
                    "value": "",
                    "label": "Name",
                    "required": true,
                    visible: true,
                    "errorMsg": messages.get('name'),
                    "validators": (validator: any) => [
                        validator.required,
                        validation.name()
                    ]
                },
                {
                    "key": "contactNumber",
                    "type": "text",
                    "value": "",
                    "label": "Contact Number",
                    "required": true,
                    visible: true,
                    "errorMsg": messages.get('contactNumber'),
                    "validators": (validator: any) => [
                        validator.required,
                        validation.phoneNumber()
                    ]

                },
                {
                    "key": "alternateContactNumer",
                    "type": "text",
                    "value": "",
                    "label": "Alternate Contact Number",
                    visible: true,
                    "errorMsg": messages.get('contactNumber'),
                    "validators": (validator: any) => [
                        validation.phoneNumber()
                    ]

                },

                {
                    "key": "emailAddress",
                    "type": "email",
                    "label": "Email Address",
                    "required": true,
                    visible: true,
                    "errorMsg": messages.get('emailAddress'),
                    "validators": (validator: any) => [
                        validator.required,
                        validation.emailAddress()
                    ]

                },

                ]
            }
        },

        {
            "heading": "Additional Information",
            visible: true,
            "id": "additionalInformation",
            "key": "additionalInformation",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "addInformation",
                        "type": "textarea",
                        "label": "Additional Information",
                        visible: true,
                        "validators": (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


                ]
            }
        },
    ]
}
export default preOrderSiteSurveyForm;

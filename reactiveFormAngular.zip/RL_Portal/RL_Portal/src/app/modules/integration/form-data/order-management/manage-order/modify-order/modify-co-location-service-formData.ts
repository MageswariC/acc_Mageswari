import { messages } from "../../../../utilities/error-message";
import validation from "../../../../utilities/validation"

export const modifyCoLocationServiceFormData = {
  controls: [
    {
      heading: "Colo Details",
      visible:true,
      id: "coloDetails",
      key: "coloDetails",
      type: "group",
      options: {
        children: [
          {
            key: "addressCoLoSpace",
            type: "select",
            value: "",
            label: "Address of Central Office",
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: ['AM', 'AR', 'BT'],
            validators: (validator: any) => [
              
            ]
          },
          {
            key: "coLocationRoom",
            type: "select",
            value: "",
            label: "Co-Location Room",
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: ['Room 1', 'Room 2', 'Room 3'],
            validators: (validator: any) => [
              
            ]
          },
          {
            key: "coLoRequestType",
            type: "select",
            value: "",
            label: "Co-Lo Request Type",
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: ['Co Location Space with Site Preparation', 'Site Preparation Only', 'Tie Fiber'],
            validators: (validator: any) => [
              
            ]
          }
        ]
      }
    },
    {
      "heading": "Contract Details",
      visible:false,
      "id": "contractDetails",
      "key": "contractDetails",
      "type": "group",
      "options": {
        "children": [
          {
            key: "contractPeriod",
            type: "select",
            value: "",
            label: "Contract Period",
            readOnly: true,
            visible: true,
            errorMsg: {},
            option: ['2 Years', '25 Years'],
            validators: (validator: any) => [
              
            ]
          },
        ]
      }
    },
    {
      "heading": "Tie Fiber Details",
      visible:false,
      "id": "tieFiberDetails",
      "key": "tieFiberDetails",
      "type": "group",
      "options": {
        "children": [
          {
            key: "connectionType",
            type: "select",
            value: "",
            label: "Connection Type",
            visible: true,
            readOnly:true,
            errorMsg: {},
            option: ['Co location Tie Fiber'],
            validators: (validator: any) => [
              
            ]
          },
          {
            key: "tieCableFiberCores",
            type: "formArray",
            value: "",
            label: "Tie Cable Fiber Cores",
            required: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [

            ],
            subformControls: [
              {

                key: "tieCableType",
                colSize: 3,
                type: "select",
                value: "",
                label: "Type",
                option: ['type 1', 'type 1'],
                required: true,
                visible: true,
                errorMsg: messages.get('tieCableType'),
                validators: (validator: any) => [
                  validator.required
                ],
              },
              {
                key: "quantity",
                colSize: 4,
                type: "text",
                value: "maji",
                label: "Quantity",
                required: true,
                visible: true,
                errorMsg: messages.get('tieCablequantity'),
                validators: (validator: any) => [
                  validator.required
                ],
              }
            ]
          },
          {
            key: "odcPortType",
            type: "formArray",
            value: "",
            label: "ODC Port Type",
            required: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [

            ],
            subformControls: [
              {
                key: "odcType",
                type: "select",
                label: "Type",
                value: "",
                visible: true,
                option: ['type 1', 'type 2'],
                required: true,
                errorMsg: messages.get('tieCableType'),
                validators: (validator: any) => [
                  validator.required
                ],
              },

              {
                key: "description",
                colSize: 4,
                type: "textarea",
                value: "",
                label: "Description",
                required: true,
                visible: true,
                errorMsg: messages.get('description'),
                validators: (validator: any) => [
                  validator.required
                ],
              }
            ]
          },
          {
            key: "startOfTermination",
            type: "formArray",
            value: "",
            label: "Start Of Termination",
            required: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [

            ],
            subformControls: [
              {
                key: "shelf",
                type: "text",
                value: "",
                label: "Shelf",
                required: true,
                visible: true,
                errorMsg: messages.get('shelf'),
                validators: (validator: any) => [
                  validator.required
                ],
              },
              {
                key: "port",
                type: "text",
                textAlign: true,
                value: "",
                label: "Port",
                required: true,
                visible: true,
                errorMsg: messages.get('port'),
                validators: (validator: any) => [
                  validator.required
                ],
              },
              {
                key: "fiberStand",
                type: "text",
                value: "",
                label: "Fiber Stand",
                required: true,
                visible: true,
                errorMsg: messages.get('fiberStand'),
                validators: (validator: any) => [
                  validator.required
                ],
              }
            ]
          },
          {
            key: "endOfTermination",
            type: "formArray",
            value: "",
            label: "End Of Termination",
            required: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [

            ],
            subformControls: [
              {
                key: "shelf",
                type: "text",
                value: "",
                label: "Shelf",
                required: false,
                visible: true,
                errorMsg: messages.get('shelf'),
                validators: (validator: any) => [
                  validator.required
                ],
              },
              {
                key: "port",
                type: "text",
                textAlign: true,
                value: "",
                label: "Port",
                required: true,
                visible: true,
                errorMsg: messages.get('port'),
                validators: (validator: any) => [
                  validator.required
                ],
              },
              {
                key: "fiberStand",
                type: "text",
                value: "",
                label: "Fiber Stand",
                required: true,
                visible: true,
                errorMsg: messages.get('fiberStand'),
                validators: (validator: any) => [
                  validator.required
                ],
              }
            ]
          }
        ]}},
   
    {
      heading: "Rack Details",
      visible:false,
      id: "rackDetails",
      key: "rackDetails",
      type: "group",
      options: {
        children: [
          {
            key: "racksList",
            type: "rack1212C",
            label: "",
            errorMsg: {},
            visible: true,
            validators: (validator: any) => [
            ]
          }
        ]
      }
    },
   
  {
      "heading": "Additional Information",
      visible:false,
      "id": "addInformation",
      "key": "addInformation",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "additionalInformation",
            "type": "textarea",
            "label": "Additional Information",
            "errorMsg": {},
            visible: true,
            "validators": (validator: any) => [
              validator.maxLength(254)
            ]
          },
          {
            key: "fileUpload",
            type: "file",
            value: "",
            visible: true,
            label: "Attachment",
            errorMsg: {},
            validators: (validator: any) => [

            ]
          }

        ]
      }
    }
  ]
}

export default modifyCoLocationServiceFormData;
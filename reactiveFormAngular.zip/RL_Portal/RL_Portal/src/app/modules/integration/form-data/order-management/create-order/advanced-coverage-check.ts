
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const advancedCoverageCheckFormData = {
    "controls": [
        {
            heading: "Search Result for Postal Code",
            visible:true,
            "createOrder":true,
            id: "coverageCheck",
            key: "coverageCheck",
            type: "group",
            options: {
                children: [
                    {
                        key: "servingCabinet",
                        type: "text",
                        value: "",
                        required: false,
                        readOnly:true,
                        visible: true,
                        label: "Serving Cabinet",
                        errorMsg: messages.get('servingCabinet'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "servingCabinetType",
                        type: "text",
                        value: "",
                        readOnly:true,
                        required: false,
                        visible: true,
                        label: "Serving Cabinet Type",
                        errorMsg: messages.get('servingCabinet'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "servingCO",
                        type: "text",
                        value: "",
                        required: false,
                        visible: true,
                        readOnly:true,
                        label: "Serving CO",
                        errorMsg: messages.get('servingCabinet'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    }

                ]
            }
        }
        
    ]
}
export default advancedCoverageCheckFormData;
import { messages } from '../../utilities/error-message';
import validation from '../../utilities/validation';
const checkOrderStatus = {
  controls: [
    {
      heading: 'Check Order Status',
      id: 'checkOrderStatus',
      key: 'checkOrderStatus',
      options: {
        children: [
          {
            key: 'orderReqIdentifier',
            type: 'text',
            value: '',
            visible: true,
            label: 'Order Request Identifier',
            errorMsg: { required: 'Order Request Identifier is required' },
            validators: (validator: any) => [validator.required],
          },

          {
            key: 'or',
            type: 'lable',
            value: 'OR',
            visible: true,
            label: '',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'incidentticketid',
            type: 'text',
            value: '',
            readOnly: true,
            // required: true,
            visible: true,
            label: 'Incident Ticket ID',
            errorMsg: { required: 'Indicent Ticket ID is required' },
            validators: (validator: any) => [
              // validator.required,
            ],
          },
        ],
      },
    },
  ],
};
export default checkOrderStatus;

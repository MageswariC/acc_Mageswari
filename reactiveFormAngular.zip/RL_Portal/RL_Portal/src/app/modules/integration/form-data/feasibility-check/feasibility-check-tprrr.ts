const fesibilityForm = {
    controls: [{
        isFcBtnrequired:true,
        heading: "Feasibility Check",
        id: "feasibilityCheck",
        key: "feasibilityCheck",
        "createOrder":true,
        options: {
            children: [
                {
                    key: "sheduleName",
                    type: "select",
                    value: "",
                    required: true,
                    visible: true,
                    option: ['Residential', 'Non Residential'],
                    label: "Schedule Name",
                    errorMsg: {"required":"TP Relocation"},
                    handler: () => {  },
                    validators: (validator: any) => [
                        validator.required,
                    ]
                },
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    required: true,
                    visible: true,
                    label: "Postal Code",
                    errorMsg: {"required":"Postal Code is required"},
                    handler: () => {  },
                    validators: (validator: any) => [
                        validator.required,
                    ],
                    inputMask:"000000"
                },
                {
                    key: "unitNumber",
                    type: "text",
                    value: "",
                    visible: true,
                    label: "Unit Number",
                    errorMsg: {},
                    handler: () => {  },
                    validators: (validator: any) => [
                       
                    ]
                },
           
              
              
            ]
        }
    }
    ]
}
export default fesibilityForm;
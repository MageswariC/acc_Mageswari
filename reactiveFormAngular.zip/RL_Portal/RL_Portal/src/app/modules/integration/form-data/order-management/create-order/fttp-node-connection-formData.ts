import { Validators } from "@angular/forms";
// import { alphanumeric } from "../utilities/validation";
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const fttbNodeConnectionFormData = {
    "controls": [
        {
            heading: "Installation Address",
            visible:true,
            id: "installationAddress",
            key: "installationAddress",
            type: "group",
            options: {
                children: [
                    // {
                    //     key: "postalCode",
                    //     type: "text",
                    //     value: "",
                    //     readOnly:true,
                    //     label: "Postal Code",
                    //     visible:true,
                    //     errorMsg: {},
                    //     validators: (validator: any) => [
                            
                    //     ]
                    // },
                    // {
                    //     key: "fttbid",
                    //     type: "text",
                    //     value: "",
                    //     visible: true,
                    //     readOnly:true,
                    //     label: "FTTB ID",
                    //     errorMsg:{}, //messages.get('postalCode'),
                    //     validators: (validator: any) => [
                    //         // validator.required
                    //     ]
                    // },
                    {
                        key: "blockHouseNumber",
                        type: "text",
                        value: "",
                        readOnly: true,
                        visible:true,
                        label: "Block/House Number",
                        //option : ['304'],
                        errorMsg: {},//messages.get('houseNo'),
                         "validators": (validator: any) => [
                        //     validator.required,
                        ]
                    },
                    {
                        key: "buildingName",
                        type: "text",
                        value: "",
                        label: "Building Name",
                        readOnly:true,
                        visible:true,
                        errorMsg: {},
                        validators: (validator: any) => [
                        ]
                      },
                    {
                        key: "streetName",
                        type: "text",
                        value: "",
                        readOnly:true,
                        label: "Street Name",
                        visible:true,
                        errorMsg: {},
                        validators: (validator: any) => [
                           
                        ]
                    },
                    // {
                    //     key: "unitNumber",
                    //     type: "text",
                    //     value: "",
                    //     readOnly:true,
                    //     visible:true,
                    //     label: "Unit Number",
                    //     errorMsg: {},
                    //     validators: (validator: any) => [
                           
                    //     ]
                    // },
                    
                    {
                        key: "buildingType",
                        type: "text",
                        value: "",
                        readOnly:true,
                        label: "Building Type",
                        visible:true,
                        errorMsg: {},
                        validators: (validator: any) => [
                            
                        ]
                    },
                    {
                        key: "coverageStatus",
                        type: "text",
                        value: "",
                        visible:true,
                        readOnly:true,
                        label: "Coverage Status",
                        errorMsg: {},
                        "validators": (validator: any) => [
                           
                        ]
                    }
                  
                ]
            }
        },
        {
            heading: "Order Details",
            id: "orderDetails",
            key: "orderDetails",
            type: "group",
            visible:true,
            options: {
                children: [
                    {
                        key: "appRefIdentifier",
                        type: "text",
                        value: "",
                        required: true,
                        visible:true,
                        label: "Application Reference Identifier",
                        errorMsg: messages.get('applicationReferenceIdentifier'),
                        validators: (validator: any) => [
                            validator.required,
                            validator.maxLength(50)
                        ]
                    },
                    {
                        key: "redundancyService",
                        type: "radio",
                        label: "Redundancy Service",
                        value: "",
                        required: true,
                        visible:true,
                        errorMsg: messages.get('redudencyRequired'),
                        option: [{
                            value: "Yes",
                            checked: false,
                            disable: false
                        },
                        {
                            value: "No",
                            checked: true,
                            disable: false
                        }],
                        handler: ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "redundancyServiceoptions",
                        type: "select",
                        label: "Redundancy Service Options",
                        value: "",
                        readOnly: true,
                        visible:true,
                        errorMsg: {
                            "required": "Redundancy Service Options required",
                        },
                        option: ['Wireline Diversity', 'Duct', 'Path'],
                        
                        validators: (validator: any) => [
                        ]
                    },
                    {
                        key: "rejectIfredundancyService",
                        type: "radio",
                        label: "Reject If Redundancy Service Unavailable",
                        value: "",
                        required: false,
                        visible:true,
                        errorMsg: messages.get('rejectRedudency'),
                        option: [{
                            "value": "Yes",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "No",
                            "checked": true,
                            "disable": true
                        }],
                        validators: (validator: any) => [
                        ]
                    },
                    {
                        key: "contractTerm",
                        type: "select",
                        label: "Contract Term",
                        value: "",
                        required: true,
                        visible:true,
                        errorMsg:  messages.get('contractTerm'),
                        option: ['12 Months'],
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "promoCode",
                        "type": "select",
                        "label": "Promo Code",
                        "value": "",
                        "option": ['M1MOECODXXX','VQLGAXXXXXXX'],
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                      }
                ]
            }
        },
        {
            heading: "Activation Details",
            id: "activationDetails",
            key: "activationDetails",
            visible:true,
            type: "group",
            options: {
                children: [
                 
                    {
                        key: "dateOfActivation",
                        type: "date",
                        label: "Date of Activation",
                        value: "",
                        required: true,
                        visible:true,
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                  
                    
                ]
            }
        },
        
        // {
        //     heading: "Price Details",
        //     id: "priceDetails",
        //     key: "priceDetails",
        //     visible:true,
        //     type: "group",
        //     options: {
        //         children: [

        //             {
        //                 key: "installationCharge",
        //                 type: "text",
        //                 label: "Installation Charge",
        //                 visible:true,
        //                 value: "",
        //                 readOnly:true,
        //                 errorMsg: {
        //                 },
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "serviceActivationCharge",
        //                 type: "text",
        //                 value: "",
        //                 label: "Service Activation Charge",
        //                 visible:true,
        //                 readOnly:true,
        //                 errorMsg: {},
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "monthlyRecurringCharge",
        //                 type: "text",
        //                 value: "",
        //                 label: "Monthly Recurring Charge",
        //                 visible:true,
        //                 readOnly:true,
        //                 errorMsg: {},
        //                 validators: (validator: any) => [
        //                 ]
        //             },
                   
        //             {
        //                 "key": "noteMessage",
        //                 "type": "message",
        //                 "value": "",
        //                 "label": "Note: Pricing shown is indicative and actual price will be shown in the invoice.",
        //                 visible: true,
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             }
        //         ]
        //     }
        // },
        {
            heading: "Additional Information",
            id: "additionalInformation",
            key: "additionalInformation",
            type: "group",
            visible:true,
            options: {
                children: [
                    {
                        key: "addInformation",
                        type: "textarea",
                        label: "Additional Information",
                        visible: true,
                        validators: (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


                ]
            }
        },
    ]
}
export default fttbNodeConnectionFormData;
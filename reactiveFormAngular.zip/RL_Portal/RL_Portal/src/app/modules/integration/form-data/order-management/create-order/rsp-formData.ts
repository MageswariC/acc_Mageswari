
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const rspFormData = {
    "controls": [
        {
            heading: "RSP Details",
            visible:true,
            id: "additionalInformation",
            key: "additionalInformation",
            type: "group",
            options: {
                children: [
                    {
                        key: "blockHouseNumber",
                        type: "select",
                        value: "",
                        required: true,
                        visible: true,
                        label: "RSP Name",
                        option: ['M1','singtel'],
                        errorMsg: messages.get('houseNo'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },


                ]
            }
        },
       
      
      
    ]
}
export default rspFormData;
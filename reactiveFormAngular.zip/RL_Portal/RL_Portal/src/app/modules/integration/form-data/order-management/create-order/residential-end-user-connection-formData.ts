import { messages } from '../../../../../components/utilities/error-message';
// import validation from '../../../../../components/utilities/validation';
import validation from '../../../utilities/validation';

const residentialEndUserConnectionFormData = {
  controls: [
    {
      heading: 'Installation Address',
      visible: true,
      createOrder: true,
      id: 'installationDetails',
      key: 'installationDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'buildingName',
            type: 'text',
            defaultValue: '',
            label: 'Building Name',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          // {
          //   key: 'buildingHouseNo',
          //   type: 'text',
          //   defaultValue: '',
          //   label: 'Building House No',
          //   readOnly: true,
          //   visible: true,
          //   errorMsg: {},
          //   validators: (validator: any) => [],
          // },
          {
            key: 'streetName',
            type: 'text',
            defaultValue: '',
            label: 'Street Name',
            readOnly: true,
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          // {
          //     "key": "unitNumber",
          //     "type": "text",
          //     "value": "",
          //     "readOnly": true,
          //     visible: true,
          //     "label": "Unit Number",
          //     "errorMsg": {},
          //     "validators": (validator: any) => [

          //     ]
          // },
          // {
          //     "key": "postalCode",
          //     "type": "text",
          //     "value": "",
          //     "label": "Postal Code",
          //     "readOnly": true,
          //     visible: true,
          //     "errorMsg": {},
          //     "validators": (validator: any) => [

          //     ]
          // },
          {
            key: 'buildingType',
            type: 'text',
            defaultValue: '',
            readOnly: true,
            visible: true,
            label: 'Building Type',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'feasibilityNote',
            type: 'text',
            defaultValue: '',
            readOnly: true,
            visible: true,
            label: 'Coverage Status',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'copifType',
            type: 'text',
            defaultValue: '',

            visible: true,
            label: 'COPIF Type',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'dataCenter',
            type: 'text',
            defaultValue: '',
            readOnly: true,
            visible: true,
            label: 'Data Center',
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Order Details',
      visible: true,
      id: 'orderDetails',
      key: 'orderDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'arnNo',
            type: 'text',
            value: '',
            required: true,
            visible: true,
            label: 'Application Reference Number',
            inputMask: 'UU/UU/00U/0000/000',
            placeholder: 'UU/UU/00A/9876/567',
            errorMsg: {
              required: 'Application Reference Number is required',
              mask: 'Invalid Application Reference Number eg:UU/UU/00A/9876/567',
            },
            validators: (validator: any) => [
              validator.required,
              validator.maxLength(14),
              // validation.applicationReferenceIdentifier(),
            ],
          },
          {
            key: 'arnNo',
            type: 'select',
            value: '',
            required: true,
            visible: true,
            label: 'Installation Type',
            option: ['NLT to Install'],

            validators: (validator: any) => [
              validator.required,
              // validator.maxlength(),
              // validation.applicationReferenceIdentifier(),
            ],
          },
          {
            key: 'technology',
            type: 'radio',
            label: 'Technology',
            defaultValue: 'GPON',
            required: true,
            visible: true,
            option: [
              {
                value: 'GPON',
                checked: true,
                disable: false,
              },
              {
                value: 'OE',
                checked: false,
                disable: false,
              },
            ],
            handler: ({ component, ...rest }: any) => {
              component.changeTechnology(rest);
            },
            errorMsg: messages.get('technology'),
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'splitRatio',
            type: 'radio',
            required: true,
            visible: true,
            label: 'Split Ratio',
            defaultValue: '1:24',

            option: [
              {
                value: '1:1',
                checked: true,
                disable: false,
              },
              {
                value: '1:24',
                checked: false,
                disable: false,
              },
              {
                value: '2:24',
                checked: false,
                disable: true,
              },
            ],
            errorMsg: messages.get('splitRatio'),
            handler: ({ component, ...rest }: any) => {
              component.spiltRatioChange(rest);
            },
            validators: (validator: any) => [],
          },
          {
            key: 'redundancyService',
            type: 'radio',
            label: 'Redundancy Service',
            defaultValue: 'No',
            required: true,
            visible: true,
            errorMsg: messages.get('redudencyRequired'),
            option: [
              {
                value: 'Yes',
                checked: false,
                disable: false,
              },
              {
                value: 'No',
                checked: true,
                disable: false,
              },
            ],
            handler: ({ component, ...rest }: any) => {
              component.changeRedundancyService(rest);
            },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'rejectRedundancyService',
            type: 'radio',
            label: 'Reject If Redundancy Service Unavailable',
            defaultValue: 'No',
            required: false,
            visible: true,
            errorMsg: messages.get('rejectRedudency'),
            option: [
              {
                value: 'Yes',
                checked: false,
                disable: false,
              },
              {
                value: 'No',
                checked: true,
                disable: false,
              },
            ],
            validators: (validator: any) => [],
          },

          {
            key: 'promoCode',
            type: 'select',
            label: 'Promo Code',
            defaultValue: '',
            
            option: [],
            visible: true,
            errorMsg: {},
           
            validators: (validator: any) => [],
          },
          {
            key: 'contractTerm',
            type: 'select',
            label: 'Contract Term',
            defaultValue: '',
            readonly: true,

            required: true,
            visible: true,
            errorMsg: { required: 'Contract Term is required' },
            option: ['12 Months'],
            validators: (validator: any) => [validator.required],
          },
        ],
      },
    },
    {
      heading: 'Activation Details',
      visible: true,
      id: 'activationDetails',
      key: 'activationDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'timeSlotOption',
            type: 'radio',
            label: 'Timeslot Option',
            defaultValue: 'Normal',
            required: true,
            visible: true,
            option: [
              {
                value: 'Normal',
                checked: true,
                disable: false,
              },
              {
                value: 'Seasonal',
                checked: false,
                disable: false,
              },
            ],
            errorMsg: {},
            readOnly: false,
            handler: ({ component, ...rest }: any) => {
              component.timeSlotOptionChange(rest);
            },
            validators: (validator: any) => [],
          },

          {
            key: 'dateOfActivation',
            type: 'date',
            label: 'Date of Activation',
            defaultValue: '',
            required: true,
            visible: true,
            readOnly: false,
            dateFrom: [],
            dateTo: [],
            errorMsg: { required: 'Date of Activation is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'installationTime',
            type: 'select',
            defaultValue: '',
            required: true,
            visible: true,
            label: 'Installation Time',
            option: [],
            handler: ({ component, ...rest }: any) => {
              component.installationTimeChange(rest);
            },
            errorMsg: { required: 'Installation Time is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'reverseAppointment',
            type: 'button',
            value: 'Reserve Appointment',
            label: '',
            visible: true,
            readOnly: true,
            handler: ({ component, ...rest }: any) => {
              component.reverseAppointment(rest);
            },
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Authorised End User Details',
      visible: true,
      id: 'endUserDetails',
      key: 'endUserDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'salutation',
            type: 'select',
            label: 'Salutation',
            defaultValue: 'Mr',
            required: true,
            visible: true,
            errorMsg: { required: 'Salutation is required' },
            option: ['Mr', 'Mrs', 'Miss'],
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'endUsername',
            type: 'text',
            defaultValue: '',
            label: 'Name',
            required: true,
            visible: true,
            errorMsg: { required: 'Name is required' },
            validators: (validator: any) => [
              validator.required,
              validation.name(),
            ],
          },
          {
            key: 'endUserContactNo',
            type: 'text',
            defaultValue: '',
            label: 'Contact Number',
            required: true,
            visible: true,
            errorMsg: { required: 'Contact Number  is required' },
            validators: (validator: any) => [
              validator.required,
              validation.phoneNumber(),
            ],
          },
          {
            key: 'endUserfax',
            type: 'text',
            defaultValue: '',
            label: 'Fax Number',
            visible: true,
            errorMsg: { required: 'Fax Numbe  is required' },
            validators: (validator: any) => [validation.phoneNumber()],
          },
          {
            key: 'endUserEmailId',
            type: 'email',
            label: 'Email Address',
            required: true,
            visible: true,
            defaultValue: '',
            errorMsg: { required: 'Email Address  is required' },
            validators: (validator: any) => [
              validator.required,
              validation.emailAddress(),
            ],
          },
        ],
      },
    },
    {
      heading: 'Price Details',
      visible: true,
      id: 'priceDetails',
      key: 'priceDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'installationCharge',
            type: 'text',
            label: 'Installation Charge',
            visible: true,
            defaultValue: '',
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'otcAmt',
            type: 'text',
            defaultValue: '',
            label: 'Service Activation Charge',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'mrcAmt',
            type: 'text',
            defaultValue: '',
            label: 'Monthly Recurring Charge',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'noteMessage',
            type: 'message',
            value: '',
            label:
              'Note: Pricing shown is indicative and actual price will be shown in the invoice.',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Additional Information',
      visible: true,
      id: 'additionalInfo',
      key: 'additionalInfo',
      type: 'group',
      options: {
        children: [
          {
            key: 'addInformation',
            type: 'textarea',
            label: 'Additional Information',
            visible: true,
            defaultValue: '',
            errorMsg: {},
            validators: (validator: any) => [validator.maxLength(254)],
          },
        ],
      },
    },
  ],
};
export default residentialEndUserConnectionFormData;

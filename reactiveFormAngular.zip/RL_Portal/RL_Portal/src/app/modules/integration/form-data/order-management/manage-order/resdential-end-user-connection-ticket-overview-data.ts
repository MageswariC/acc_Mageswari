export const tableColoumFormat1 = [
    {
      header: 'ORI',
      value: 'ori'
    },
    {
      header: 'Date of Applicationt',
      value: 'dateOfApplication'
    },
  
    {
      header: 'Order Status',
      value: 'orderStatus'
    },
    {
      header: 'Tentative Provisioing Date',
      value: 'tentativeProvisioning'
    },

    {
      header: 'Revised Provisioning Dated',
      value: 'revisedprovisioningDate'
    }
   
  ]

  const displayTableData1 = [
    {
      ori: "02-01-07012022-45671-A",
      dateOfApplication:"19-08-2022",
      orderStatus: "Active",
      tentativeProvisioning:"22-12-2022",
      revisedprovisioningDate: "22-12-2022"
    },
    
  ]

  const ticketDataApi = [
    {
      heading:"Payment Information",
      label:"payment_information",
      readOnly:true,
      tableColoumFormat:  tableColoumFormat1,
      tableRowData: displayTableData1
    }
  ]

  export default ticketDataApi;
  
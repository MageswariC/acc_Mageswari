import { messages } from "src/app/modules/integration/utilities/error-message";
import validation from "src/app/modules/integration/utilities/validation";
import { Validators } from "@angular/forms";
const searchTroubleTicket = {
    controls: [{
        heading: "Check Order Status",
        id: "checkOrderStatus",
        key: "checkOrderStatus",
        options: {
            children: [
                {
                    key: "incidentId",
                    type: "text",
                    value: "",
                    label: "Indident Ticket Id",
                    errorMsg: {},
                    handler: ({ component, ...rest }: any) => { component.getIndidentId(rest) },
                    validators: (validator: any) => [
                        
                    ]
                },
                {
                    key: "ori",
                    type: "text",
                    value: "",
                    required: true,
                    label: "Order Request Identifier",
                    errorMsg: {},
                    handler: ({ component, ...rest }: any) => { component.getOri(rest) },
                    validators: (validator: any) => [
                        validator.required,  
                    ]
                },
                
                {
                    key: "or",
                    type: "lable",
                    value: "OR",
                    visible: true,
                    label: "",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "opCoIncidentId",
                    type: "text",
                    value: "",
                    label: "OpCo Indident Id",
                    errorMsg: {},
                    handler: ({ component, ...rest }: any) => { component.getOpCoIndidentId(rest) },
                    validators: (validator: any) => [
                        
                    ]
                },
               
            ]
        }
    }
    ]
}
export default searchTroubleTicket;

import { messages } from "../../../../utilities/error-message";
import validation from 'src/app/components/utilities/validation';
const relocateService = {
    controls: [
        {
        relocateService:true,
        heading: "Application Details ",
        visible:true,
        id: "toReqDetails",
        key: "toReqDetails",
        type: 'group',
        options: {
            children: [
               
                {
                    key: "ori",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Order Request Identifier",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "arnNo",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Application Reference Number",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
           
              
              
            ]
        }
    },
    {
        heading: "Existing End User Address Details",
        id: "existEndUserAddrDetails",
        key: "existEndUserAddrDetails",
        visible:true,
        type: 'group',
        options: {
            children: [
                {
                    key: "buildingNumber",
                    type: "text",
                    value: "",
                    visible: true,
                    required: true,
                    readOnly: true, 
                    label: "Block/House Number",
                    errorMsg: {"required":"Block/House Number"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "buildingName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Building Name",
                    errorMsg: {"required":"Building Name is required"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "streetName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Street Name",
                    errorMsg: {"required":"Street Name is required"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "tPName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "TP Name",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Postal Code",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "unitNumber",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Unit Number",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "buildingType",
                    type: "text",
                    value: "",
                    readOnly: true, 
                    visible: true,
                    label: "Building Type",
                    errorMsg: {},
                    validators: (validator: any) => [

                    ]
                },
                {
                    key: "copifType",
                    type: "text",
                    value: "",
                    readOnly: true, 
                    visible: true,
                    label: "COPIF Type",
                    errorMsg: {},
                    validators: (validator: any) => [

                    ]
                },
                {
                    key: "firstName",
                    type: "text",
                    value: "",
                    visible: true,
                    required: true,
                    readOnly: true, 
                    label: "Name",
                    errorMsg: {},
                    validators: (validator: any) => [

                    ]
                },
                {
                    key: "userType",
                    type: "radio",
                    label: "VIP",
                    defaultValue: 'No',
                    visible:true,
                    readOnly: true, 
                    errorMsg: {},
                    option: [{
                        value: "Yes",
                        checked: false,
                        disable: true
                    },
                    {
                        value: "No",
                        checked: false,
                        disable: true
                    }],
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "contactNumber",
                    type: "text",
                    value: "",
                    label: "Contact Number",
                    readOnly: true, 
                    required: true,
                    visible:true,
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]

                },
                {
                    key: "emailAddress",
                    type: "email",
                    label: "Email Address",
                    visible:true,
                    readOnly: true, 
                    required: true,
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "contractTerm",
                    type: "text",
                    label: "Contract Term",
                    value: "",
                    readOnly: true, 
                    visible:true,
                    required: true,
                    errorMsg: {},
                    option: ['12 Months'],
                    validators: (validator: any) => [
                        validator.required,
                    ]
                },
              
            ]
        }
    },
    {
        heading: "Existing Connection Details",
        id: "existingConnectionDetails",
        key: "existingConnectionDetails",
        visible:true,
        type: "group",
        options: {
            children: [
                {
                    key: 'technology',
                    type: 'radio',
                    label: 'Technology',
                    required: true,
                    disable:true,
                    visible: true,
                    option: [
                      {
                        value: 'GPON',
                        checked: false,
                        disable: true,
                      },
                      {
                        value: 'OE',
                        checked: false,
                        disable: true,
                      },
                    ],
                    handler: ({ component, ...rest }: any) => {
                      component.changeTechnology(rest);
                    },
                    errorMsg: messages.get('technology'),
                    validators: (validator: any) => [validator.required],
                  },
                  {
                    key: 'splitRatio',
                    type: 'radio',
                    required: true,
                    visible: true,
                    label: 'Split Ratio',
                    option: [
                      {
                        value: '1:1',
                        checked: false,
                        disable: true,
                      },
                      {
                        value: '1:24',
                        checked: false,
                        disable: true,
                      },
                      {
                        value: '2:24',
                        checked: false,
                        disable: true,
                      },
                    ],
                    errorMsg: messages.get('splitRatio'),
                    handler: ({ component, ...rest }: any) => {
                      component.spiltRatioChange(rest);
                    },
                    validators: (validator: any) => [],
                  },
                  {
                    key: 'redundancyService',
                    type: 'radio',
                    label: 'Redundancy Service',
                    // defaultValue: 'Yes',
                    required: true,
                    visible: true,
                    errorMsg: messages.get('redudencyRequired'),
                    option: [
                      {
                        value: 'Yes',
                        checked: false,
                        disable: true,
                      },
                      {
                        value: 'No',
                        checked: true,
                        disable: true,
                      },
                    ],
                    handler: ({ component, ...rest }: any) => {
                      component.changeRedundancyService(rest);
                    },
                    validators: (validator: any) => [validator.required],
                  },
                  {
                    key: 'rejectIfRedundancyService',
                    type: 'radio',
                    label: 'Reject If Redundancy Service Unavailable',
                    // defaultValue: 'No',
                    required: false,
                    visible: true,
                    errorMsg: messages.get('rejectRedudency'),
                    option: [
                      {
                        value: 'Yes',
                        checked: false,
                        disable: true,
                      },
                      {
                        value: 'No',
                        checked: true,
                        disable: true,
                      },
                    ],
                    validators: (validator: any) => [],
                  },
                    
                    {
                        key: "preferredInstallationSession",
                        type: "radio",
                        label: "Preferred Installation Session",
                        value: "",
                        readOnly: true, 
                        visible:true,
                        required: true,
                        errorMsg: {},
                        option: [{
                            value: "Normal",
                            checked: false,
                            disable: true
                        },
                        {
                            value: "Sessonal",
                            checked: true,
                            disable: true
                        }],
                        validators: (validator: any) => [
                        ]
                    },
                    {
                        key: "addInformation",
                        type: "textarea",
                        label: "Additional Information",
                        visible:true,
                        readOnly: true, 
                        validators: (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


            ]
        }
    },
    {
        heading: "Relocation Application Details",
        id: "relocationAppDetails",
        key: "relocationAppDetails",
        visible:true,
        type: "group",
        options: {
            children: [
                {
                    key: "appRefNumber",
                    type: "text",
                    label: "Application Reference Number",
                    visible: true,
                    required:true,
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },


            ]
        }
    },
    {
        heading: "Please Check Feasibility",
        id: "feasiblityCheck",
        key: "feasiblityCheck",
        visible:true,
        type: "group",
        options: {
            children: [
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    label: "Postal Code",
                    visible:true,
                    required: true,
                    errorMsg: {},
                    validators: (validator: any) => [
                        
                    ]
                },
                {
                    key: "unitNumber",
                    type: "text",
                    value: "",
                    visible:true,
                    label: "Unit Number",
                    errorMsg: {},
                    validators: (validator: any) => [
                       
                    ]
                },
                {
                    key: 'feasiblityCheck',
                    type: 'button',
                    value: 'Check Feasablity',
                    label: '',
                    visible: true,
                    readOnly:false,
                    handler: ({ component, ...rest }: any) => {
                      component.feasabilityCheck(rest);
                        // component.reverse(rest);
                    },
                    errorMsg: {},
                    validators: (validator: any) => [],
                  },

            ]
        }
    },
    {
        heading: "Relocation Address Details",
        id: "relocationAddrDetails",
        key: "relocationAddrDetails",
        visible:false,
        type: 'group',
        options: {
            children: [
                {
                    key: "blockHouseNumber",
                    type: "select",
                    value: "",
                    visible: true,
                    required: true,
                    // readOnly: true, 
                    option: ["120"],
                    label: "Block/House Number",
                    errorMsg: {"required":"Block/House Number"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "buildingName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Building Name",
                    errorMsg: {"required":"Building Name is required"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "streetName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Street Name",
                    errorMsg: {"required":"Street Name is required"},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "tPName",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Network Status",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Postal Code",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "unitNumber",
                    type: "text",
                    value: "",
                    visible: true,
                    readOnly: true, 
                    label: "Unit Number",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "buildingType",
                    type: "select",
                    value: "",
                    option: ["HDB"],
                    readOnly: true, 
                    visible: true,
                    label: "Building Type",
                    errorMsg: {},
                    validators: (validator: any) => [

                    ]
                },
                {
                    key: "copifType",
                    type: "text",
                    value: "",
                    readOnly: true, 
                    visible: true,
                    label: "COPIF Type",
                    errorMsg: {},
                    validators: (validator: any) => [

                    ]
                },                          
            ]           
        }
    },
    {
        
        heading: "Appointment",
        id: "appointment",
        key: "appointment",
        type: 'group',
        visible:false,
        options: {
            children: [
                {
                    key: "preferredInstallSession",
                    type: "radio",
                    label: "Preferred Installation Session",
                    value: "",
                    required: true,
                    visible: true,
                    defaultValue: 'Normal',
                    errorMsg:{},
                    option: [{
                        "value": "Seasonal",
                        "checked": false,
                        "disable": true
                    },
                    {
                        "value": "Normal",
                        "checked": true,
                        "disable": true
                    }],
                    validators: (validator: any) => [
                        validator.required,
                    ]
                }, 
                {
                    key: "reqDateOfActivation",
                    type: "date",
                    value: "",
                    label: "Requested Date of Activation",
                    required: true,
                    visible: true,
                    disableCalender : true ,
                    dateFrom: [],
                    dateTo: [],
                    errorMsg: "{'required': 'Requested Date of Activation is required'}",
                    validators: (validator: any) => [
                      validator.required,
                    ]
                  },
                {
                    key: "timeSlotOption",
                    type: "text",
                    required: true,
                    visible: true,
                    readOnly: true,
                    option: [],
                    label: "Timeslot option",
                    errorMsg: {"required":"Choose any 1 option"},
                    handler: ({ component, ...rest }: any) => {
                        component.installationTimeChange(rest);
                      },
                    validators: (validator: any) => [
                        validator.required,
                    ]
                },
                {
                    key: "addtionalInfo",
                    type: "textarea",
                    value: "",
                    label: "Additional Information",
                    visible: true,
                    errorMsg: "{'required': 'Additional Information is required'}",
                    validators: (validator: any) => [
                    ]
                  },
                  {
                    key: 'reverseAppointment',
                    type: 'button',
                    value: 'Reschedule Appointment',
                    label: '',
                    visible: true,
                    readOnly:false,
                    handler: ({ component, ...rest }: any) => {
                      component.reverseAppointment(rest);
                        // component.reverse(rest);
                    },
                    errorMsg: {},
                    validators: (validator: any) => [],
                  },
                  
           
              
              
            ]
        }
    },
    {
        
        heading: "Summary",
        id: "summary",
        key: "summary",
        visible:false,
        type: 'group',
        options: {
            children: [
                {
                    key: "installationCharges",
                    type: "text",
                    value: "",
                    label: "Installation Charge",
                    visible: true,
                    
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                  },
            ]
        }
    }
   
    ]
}
export default relocateService;

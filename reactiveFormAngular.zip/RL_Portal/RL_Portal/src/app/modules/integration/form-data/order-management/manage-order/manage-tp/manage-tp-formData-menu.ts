import { messages } from '../../../../utilities/error-message';
const manageTP = {
  controls: [
    {
      heading: 'TP Request Details',
      visible: true,
      id: 'toReqDetails',
      key: 'toReqDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'operationToBePerformed',
            type: 'select',
            value: '',
            required: true,
            visible: true,
            option: ['TP Relocation', 'TP Repair/Replacement', 'Removal'],
            label: 'Operation to be Performed',
            errorMsg: { required: 'Choose any 1 option' },
            validators: (validator: any) => [validator.required],
          },
        ],
      },
    },
    {
      heading: 'Installation Address',
      visible: true,
      id: 'installationAddress',
      key: 'installationAddress',
      type: 'group',
      options: {
        children: [
          {
            key: 'blockHouseNumber',
            type: 'text',
            value: '',
            label: 'Block/House Number',
            required: true,
            readOnly: false,
            visible: true,
            errorMsg: messages.get('blockHouseNumber'),
            option: [],
            validators: (validator: any) => [validator.required],
          },

          {
            key: 'buildingName',
            type: 'text',
            value: '',
            label: 'Building Name',
            readOnly: true,
            errorMsg: { required: 'Building Name is required' },
            required: false,
            visible: true,
            validators: (validator: any) => [],
          },
          {
            key: 'streetName',
            type: 'text',
            label: 'Street Name',
            value: '',
            readOnly: true,
            required: false,
            errorMsg: { required: 'Street Name is required' },

            visible: true,
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'networkStatus',
            type: 'text',
            value: '',
            label: 'Network Status',
            readOnly: true,
            errorMsg: { required: 'Network Status is required' },
            required: false,
            visible: true,
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'postalCode',
            type: 'text',
            value: '',
            label: 'Postal Code',
            errorMsg: { required: 'Postal Code is required' },
            readOnly: true,
            required: false,
            visible: true,
            validators: (validator: any) => [],
          },
          {
            key: 'unitNumber',
            type: 'text',
            value: '',
            label: 'Unit Number',
            readOnly: true,
            errorMsg: { required: 'Unit Number is required' },
            required: false,
            visible: true,
            validators: (validator: any) => [validator.required],
          },

          {
            key: 'buildingType',
            type: 'select',
            label: 'Building Type',
            value: 'HDB',
            readOnly: true,
            errorMsg: { required: 'Building Type is required' },
            required: false,
            visible: true,
            option: ['HDB'],
            validators: (validator: any) => [validator.required],
          },

          {
            key: 'copifType',
            type: 'text',
            value: '',
            label: 'COPIF Type',
            errorMsg: {},
            readOnly: true,
            required: false,
            visible: true,
            validators: (validator: any) => [],
          },
          {
            key: 'tpName',
            type: 'text',
            value: '',
            label: 'TP Name',
            required: true,
            visible: true,
            readOnly: false,
            errorMsg: { required: 'TP Name is required' },
            validators: (validator: any) => [validator.required],
          },
        ],
      },
    },

    // {
    //   heading: 'Appointment',
    //   visible: true,
    //   id: 'appointment',
    //   key: 'appointment',
    //   type: 'group',
    //   options: {
    //     children: [
    //       {
    //         key: 'preferredInstallSession',
    //         type: 'radio',
    //         label: 'Preferred Installation Session',
    //         value: '',
    //         required: true,
    //         visible: true,
    //         errorMsg: {},
    //         option: [
    //           {
    //             value: 'Seasonal',
    //             checked: false,
    //             disable: false,
    //           },
    //           {
    //             value: 'Normal',
    //             checked: true,
    //             disable: false,
    //           },
    //         ],
    //         validators: (validator: any) => [validator.required],
    //       },
    //       {
    //         key: 'reqDateOfActivation',
    //         type: 'date',
    //         value: '',
    //         label: 'Requested Date of Activation',
    //         required: true,
    //         visible: true,
    //         errorMsg:
    //           "{'required': 'Requested Date of Activation is required'}",
    //         validators: (validator: any) => [validator.required],
    //       },
    //       {
    //         key: 'timeSlotOption',
    //         type: 'select',
    //         value: '',
    //         required: true,
    //         visible: true,
    //         option: ['option 1', 'option 2'],
    //         label: 'Timeslot option',
    //         errorMsg: { required: 'Choose any 1 option' },
    //         validators: (validator: any) => [validator.required],
    //       },
    //       {
    //         key: 'addtionalInfo',
    //         type: 'textarea',
    //         value: '',
    //         label: 'Additional Information',
    //         visible: true,
    //         errorMsg: "{'required': 'Additional Information is required'}",
    //         validators: (validator: any) => [],
    //       },
    //     ],
    //   },
    // },
    {
      heading: 'Activation Details',
      visible: true,
      id: 'activationDetails',
      key: 'activationDetails',
      type: 'group',
      options: {
        children: [
          {
            key: 'timeSlotOption',
            type: 'radio',
            label: 'Timeslot Option',
            defaultValue: 'Normal',
            required: true,
            visible: true,
            option: [
              {
                value: 'Normal',
                checked: true,
                disable: true,
              },
              {
                value: 'Seasonal',
                checked: false,
                disable: true,
              },
            ],
            errorMsg: {},
            readOnly: false,
            handler: ({ component, ...rest }: any) => {
              component.timeSlotOptionChange(rest);
            },
            validators: (validator: any) => [],
          },

          {
            key: 'dateOfActivation',
            type: 'date',
            label: 'Date of Activation',
            defaultValue: '',
            required: true,
            visible: true,
            // readOnly: true,
            disableCalender: true,
            dateFrom: [],
            dateTo: [],
            errorMsg: { required: 'Date of Activation is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'installationTime',

            type: 'text',

            required: true,
            readonly: true,
            visible: true,

            label: 'Installation Time',

            option: [],

            readOnly: true,
            handler: ({ component, ...rest }: any) => {
              component.installationTimeChange(rest);
            },
            errorMsg: { required: 'Installation Time is required' },
            validators: (validator: any) => [validator.required],
          },
          {
            key: 'reverseAppointment',
            type: 'button',
            value: 'Reschedule Appointment',
            label: '',
            visible: true,
            readOnly: false,
            handler: ({ component, ...rest }: any) => {
              component.reverseAppointment(rest);
            },
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
    {
      heading: 'Summary',
      visible: true,
      id: 'summary',
      key: 'summary',
      type: 'group',
      options: {
        children: [
          {
            key: 'installationCharges',
            type: 'text',
            value: '',
            label: 'Installation Charge',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },
        ],
      },
    },
  ],
};

export default manageTP;

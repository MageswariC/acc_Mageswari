import { messages } from '../../utilities/error-message';
import validation from '../../utilities/validation';
const fesibilityForm = {
  controls: [
    {
      isFcBtnrequired:true,
      heading: 'Feasibility Check',
      id: 'feasibilityCheck',
      key: 'feasibilityCheck',
      hide: false,
      options: {
        children: [
          {
            key: 'postalCode',
            type: 'text',
            value: '',
            required: true,
            visible: true,
            label: 'Postal Code',
            errorMsg: {
              required: 'Postal Code is required',
              pattern: 'Enter Valid Postal Code',
            },
            handler: () => {},
            validators: (validator: any) => [
              validator.required,
              validation.postalCode(),
            ],
          },
          {
            key: 'buildingNumber',
            type: 'select',
            visible: true,
            required: true,
            defaultValue: '4E',
            label: 'Building Number',
            errorMsg: { required: 'Building Block Number is required' },
            option: ['4E'],
            handler: () => {},
            validators: (validator: any) => [],
          },
          {
            key: 'unitNumber',
            type: 'text',
            defaultValue: '#01-01',
            visible: true,
            required: true,
            label: 'Unit Number',
            errorMsg: {
              required: 'Unit Number is required',
              pattern: 'Enter Valid Unit Number eg:#001',
            },
            handler: () => {},
            validators: (validator: any) => [
              // validation.unitNumber()
            ],
          },
        ],
      },
    },
  ],
};
export default fesibilityForm;

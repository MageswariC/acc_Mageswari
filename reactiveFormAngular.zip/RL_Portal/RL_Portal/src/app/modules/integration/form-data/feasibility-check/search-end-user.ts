import { messages } from "src/app/modules/integration/utilities/error-message";
import validation from "src/app/modules/integration/utilities/validation";
import { Validators } from "@angular/forms";
const searchEndUser = {
    controls: [{
        heading: "Check Order Status",
        id: "checkOrderStatus",
        key: "checkOrderStatus",
        options: {
            children: [
                
                {
                    key: "ori",
                    type: "text",
                    value: "",
                    required: true,
                    label: "Order Request Identifier",
                    errorMsg: {},
                    handler: ({ component, ...rest }: any) => { component.getOri(rest) },
                    validators: (validator: any) => [
                        validator.required,  
                    ]
                },
                
                {
                    key: "or",
                    type: "lable",
                    value: "OR",
                    visible: true,
                    label: "",
                    errorMsg: {},
                    validators: (validator: any) => [
                    ]
                },
                {
                    key: "appRefIdentifier",
                    type: "text",
                    value: "",
                    label: "Application Reference Identifier",
                    errorMsg: {},
                    //handler: ({ component, ...rest }: any) => { component.getOpCoIndidentId(rest) },
                    validators: (validator: any) => [
                        
                    ]
                },
               
            ]
        }
    }
    ]
}
export default searchEndUser;

import { messages } from "../../utilities/error-message";
import validation from "../../utilities/validation";
const fesibilityForm = {
    controls: [
        {
          isFcBtnrequired:false,
          heading: 'Feasibility Check',
          id: 'feasibilityCheck',
          key: 'feasibilityCheck',
          hide: false,
          options: {
            children: [
              {
                key: 'postalCode',
                type: 'text',
                value: '',
                required: true,
                visible: true,
                label: 'Postal Code',
                errorMsg: {
                  required: 'Postal Code is required',
                  pattern: 'Enter Valid Postal Code',
                },
                handler: ({ component, ...rest }: any) => {
                  component.postalCodeChange(rest);
                },
                validators: (validator: any) => [
                  validator.required,
                  validation.postalCode(),
                ],
              },
              // {
              //   key: 'unitNumber',
              //   type: 'typeahead',
              //   value: '',
              //   visible: true,
              //   label: 'Unit Number',
              //   option: [],
              //   selectedOptions:[],
              //   errorMsg: {"required": "Unit Number is required",
              //   "pattern": "Enter Valid Unit Number eg:#001"},
              //   handler: () => {  },
              //   validators: (validator: any) => [
              //     validation.unitNumber(),
              //   ],
              // },
    
              {
                key: "buildingNumber",
                type: "select",
                visible: false,
                label: "Building/House Number ",
                errorMsg: {"required": "Building Block Number is required"},
                option: [],
                handler: () => {},
                validators: (validator: any) => [],
              },
    
              {
                key: 'unitNumber',
                type: 'typeahead',
                value: '',
                visible: false,
                label: 'Unit Number',
                option: [],
                selectedOptions: [],
                errorMsg: {
                  required: 'Unit Number is required',
                  pattern: 'Enter Valid Unit Number eg:#001',
                },
                handler: () => {},
                validators: (validator: any) => [validation.unitNumber(),  validator.required,],
              },
    
              // {
              //   key: "buildingNumber",
              //   type: "select",
              //   visible: false,
              //   label: "Building Block Number",
              //   errorMsg: {"required": "Building Block Number is required"},
              //   option: [],
              //   handler: () => {},
              //   validators: (validator: any) => [],
              // },
             
            ],
          },
        },
      ],
}
export default fesibilityForm;

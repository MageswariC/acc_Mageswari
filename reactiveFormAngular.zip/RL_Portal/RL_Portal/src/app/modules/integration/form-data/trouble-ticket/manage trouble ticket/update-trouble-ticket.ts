import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";
const manage_ticket={
        // onehr_fibreProvision_fibreMain_main_manage : {
        "controls": [
            {
                "heading": "Ticket Details",
                visible:true,
                "createOrder":true,
                "id": "ticketDetails",
                "key": "ticketDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "ticketStatus",
                            "type": "text",
                            "value": "",
                            visible: true,
                            "label": "Ticket Status",
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                            
                            ]
                        },
                        {
                            "key": "incidentID",
                            "type": "text",
                            "value": "",
                            "label": "Incident ID",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                               
                            ]
    
                        },
                        {
                            "key": "incidentType",
                            "type": "text",
                            "value": "",
                            "required": true,
                            visible:true,
                            "label": "Incident Type",
                            "readOnly": true,
                            "errorMsg": {},
                            "handler": ({ component, ...rest }: any) => { component.changeIncidentType(rest) },
                            "validators": (validator: any) => [
                               
                            ]
                        },
                        {
                            "key": "OpCoIncidentID",
                            "type": "text",
                            "value": "",
                            "label": "OpCo Indident Id",
                            "readOnly": true,
                            "errorMsg": {},
                            "handler": ({ component, ...rest }: any) => { component.getOpCoIndidentId(rest) },
                            "validators": (validator: any) => [
                                
                            ]
                        },
                        {
                            "key": "ori",
                            "type": "text",
                            "value": "",
                            "required": true,
                            "readOnly": true,
                            "label": "Order Request Identifier",
                            "errorMsg": {},
                            "handler": ({ component, ...rest }: any) => { component.getOri(rest) },
                            "validators": (validator: any) => [
                               
                            ]
                        },
                        {
                            "key": "causeOfFault",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Cause Of Fault",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "schedule",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Schedule",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "ticketSummary",
                            "type": "text",
                            "value": "",
                            "required": true,
                            "readOnly": true,
                            visible:true,
                            "label": "Ticket Summary",
                            "validators": (validator: any) => [
                                
                            ]
                        },
                        {
                            "key": "ticketDescription",
                            "type": "text",
                            "value": "",
                            // "required": true,
                            visible:true,
                            "label": "Ticket Description",
                            "validators": (validator: any) => [
                                validator.required,
                                validator.maxLength(50)
                            ]
                        },
                    ]
                }
            },
            //Ticket Appointment
            {
                "heading": "Ticket Appointment",
                visible:true,
                "id": "ticketAppointment",
                "key": "ticketAppointment",
                "type": "group",
                "options": {
                    "children": [
                        {
                            key: "appointmentDate",
                            type: "date",
                            value: "",
                            visible: true,
                            required: true,
                            label: "Appointment Date",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            "key": "appointmentSlot",
                            "type": "select",
                            "value": "",
                            "required": true,
                            visible:true,
                            "label": "Appointment Slot",
                            "option": ['9:00-11:00', '11:00-13:00','14:00-16:00', '16:00-18:00'],
                            "errorMsg": messages.get('applicationReferenceIdentifier'),
                            "validators": (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            "key": "notes",
                            "type": "textarea",
                            "label": "Notes",
                            visible:true,
                            "validators": (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
                    ]
                }
            },
            // {
            //     "heading": "Ticket Appointment",
            //     visible:false,
            //     "id": "",
            //     "key": "ticketAppoin",
            //     "type": "group",
            //     "options": {
            //         "children": [
            //             // {
            //             //     "key": "AppointmentDate",
            //             //     "type": "text",
            //             //     "value": "",
            //             //     "label": "Appointment Date",
            //             //     "required": true,
            //             //     visible:true,
            //             //     "errorMsg": messages.get('name'),
            //             //     "validators": (validator: any) => [
            //             //         validator.required,
            //             //         validation.name()
            //             //     ]
            //             // },
            //             {
            //                 key: "AppointmentDate",
            //                 type: "calendar-ui",
            //                 value: "",
            //                 visible: true,
            //                 required: true,
            //                 // "readOnly": true,
            //                 label: "Appointment Date",
            //                 // option: ['#01-01', '#01-02','#01-03','#01-04','#01-05','#01-06','#01-07','#01-08','#01-09','#01-10'],
            //                 // errorMsg: messages.get('houseNo'),
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 "key": "AppointmentSlot",
            //                 "type": "select",
            //                 "value": "",
            //                 "required": true,
            //                 visible:true,
            //                 // "readOnly": true,
            //                 "label": "Appointment Slot",
            //                 "option": ['9:00-11:00', '11:00-13:00','14:00-16:00', '16:00-18:00'],
            //                 "errorMsg": messages.get('applicationReferenceIdentifier'),
            //                 "validators": (validator: any) => [
            //                     validator.required,
            //                 ]
            //             },
            //             {
            //                 "key": "Notes",
            //                 "type": "textarea",
            //                 "label": "Notes",
            //                 visible:true,
            //                 // "readOnly": true,
            //                 "validators": (validator: any) => [
            //                     validator.maxLength(254)
            //                 ]
            //             },
            //         ]
            //     }
            // },
            // Service Order Details
            {
                "heading": "Service Order Details",
                visible:true,
                "createOrder":true,
                "id": "serviceOrderDetails",
                "key": "serviceOrderDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            visible: true,
                            "label": "FirstName",
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                             
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [

                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                       
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
           
                            ]
                        },
                        {
                            "key": "blockHouseNumber",
                            "type": "text",
                            "value": "",
                            "label": "Block/House Number",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "unitNumber",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Unit Number",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "buildingName",
                            "type": "text",
                            "value": "",
                            "label": "Building Name",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "streetName",
                            "type": "text",
                            "value": "",
                            "label": "Street Name",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "postalCode",
                            "type": "text",
                            "value": "",
                            "label": "Postal Code",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "copifType",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "COPIF Type",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "buildingType",
                            "type": "text",
                            "value": "",
                            "option": ["HDB"],
                            "readOnly": true, 
                            visible: true,
                            "label": "Building Type",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "schedule",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Schedule",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                    ]
                }
            },
            // End User Details
            {
                "heading": "End User Premise Contact Details",
                visible:true,
                "id": "endUserPremisesContactDetails",
                "key": "endUserPremisesContactDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            "required": true,
                            visible:true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                               // validation.name()
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            "required": true,
                            visible:true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                //validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            "required": true,
                            visible:true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                               // validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
    
                        },
                    ]
                }
            },
            // Secondary Requesting Licensee
            {
                "heading": "Secondary Requesting Licensee",
                visible:true,
                "id": "secondaryRequestingLisensee",
                "key": "secondaryRequestingLisensee",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [

                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                               
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                           
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                        
                            ]
    
                        },
                    ]
                }
            },
            // RL Field Engineer Contact Details
            {
                "heading": "RL Field Engineer Contact Details",
                visible:true,
                "id": "rlFieldEngineerContactDetails",
                "key": "rlFieldEngineerContactDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                // validator.required,
                                // validation.name()
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                // validator.required,
                                // validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                // validator.required,
                                // validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                // validator.required,
                                // validation.emailAddress()
                            ]
    
                        },
                    ]
                }
            },
            // Ticket Attachment
            {
                "heading": "Ticket Attachment",
                visible:true,
                "id": "TickerAttachment",
                "key": "TickerAttachment",
                "type": "group",
                "options": {
                    "children": [
    
                        // {
                        //     "key": "Attachment",
                        //     "type": "fileupload",
                        //     "label": "Attachment",
                        //     // "readOnly": true, 
                        //     visible: true,
                        //     "value": "",
                        //     "errorMsg": {
                        //     },
                        //     "validators": (validator: any) => [
                        //     ]
                        // },
                        {
                            "key": "Attachment",
                            "type": "fileupload",
                            "label": "Attachment",
                            // "readOnly": true, 
                            visible: true,
                            "value": "",
                            "errorMsg": {
                            },
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "Notes",
                            "type": "textarea",
                            "label": "Notes",
                            visible:true,
                            "validators": (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
                    ]
                }
            },
        ]}


export default manage_ticket; 
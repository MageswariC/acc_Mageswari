// import { Validators } from "@angular/forms";
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const nbapS11ConnectionFormData = {
    postalCodeForm : {
        controls: [
            {
                heading: "Serving Address (NBAP DP)",
                visible:true,
                "createOrder":true,
                id: "servingAddress",
                key: "servingAddress",
                type: "group",
                options: {
                    children: [
                        {
                            key: "dpName",
                            type: "text",
                            value: "NLT User",
                            // readOnly: true,
                            visible: true,
                            label: "DP Name",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "descriptionOfAddress",
                            type: "text",
                            value: "Singapore",
                            // readOnly: true,
                            visible: true,
                            label: "Description of Address",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "streetName",
                            type: "text",
                            value: "Mandalay Towers",
                            // readOnly: true,
                            required: true,
                            visible: true,
                            label: "Street Name",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "postalCode",
                            type: "text",
                            required: true,
                            // readOnly: true,
                            visible: true,
                            label: "Postal Code",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "landmark",
                            type: "text",
                            value: "V Towers",
                            // readOnly: true,
                            visible: true,
                            label: "Landmark",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "height",
                            type: "text",
                            value: "10.2",
                            required: true,
                            // readOnly: true,
                            visible: true,
                            label: "Height(m)",
                            validators: (validator: any) => [
                            ]
                        },
                    ]
                }
            },
            {
                heading: "Installation Address",
                visible:true,
                createOrder:true,
                id: "installationAddress",
                key: "installationAddress",
                type: "group",
                options: {
                    children: [
                        {
                            key: "streetName",
                            type: "text",
                            value: "",
                            required: true,
                            visible: true,
                            // readOnly: false,
                            label: "Street Name ",
                            errorMsg: messages.get('streetName'),
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "postalCode",
                            type: "text",
                            value: "",
                            label: "Postal Code",
                            visible: true,
                            errorMsg: messages.get('postalCode'),
                            validators: (validator: any) => [
                                validation.postalCode()
                            ]
                        },
                        {
                            key: "landmark",
                            type: "text",
                            value: "",
                            label: "Landmark",
                            visible: true,
                            errorMsg: {
                            },
                            validators: (validator: any) => [
                            ]
                        },    
                        {
                            key: "height",
                            type: "text",
                            value: "",
                            required: true,
                            visible: true,
                            label: "Height(m)",
                            errorMsg: messages.get('height'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.height(),
                                validator.maxLength(10)
                            ]
                        },
                        {
                            key: "fileUpload",
                            type: "fileupload",
                            value: "",
                            label: "Upload Required Documents",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Document is required",
                            },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                    ]
                }
            },
            {
                heading: "Order Details",
                visible:true,
                id: "orderDetails",
                key: "orderDetails",
                type: "group",
                options: {
                    children: [
                        {
                            key: "appRefIdentifier",
                            type: "text",
                            value: "",
                            required: true,
                            visible: true,
                            label: "Application Reference Identifier",
                            errorMsg: {
                                required: "Application Reference Identifier Required",
                                maxlength: "Application reference cannot exceed maximum length of 50, and special characters are allowed.",
                            },
                            validators: (validator: any) => [
                                validator.required,
                                validator.maxLength(50)
                            ]
                        },
                        {
                            key: "installationType",
                            type: "select",
                            label: "Installation Type",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('installationType'),
                            option: ['NLT to Install', 'Self Provide', 'Pre Install TP'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        // {
                        //     key: "technology",
                        //     type: "radio",
                        //     label: "Technology",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: messages.get('technology'),
                        //     readOnly: true,
                        //     option: [{
                        //         value: "GPON",
                        //         checked: true,
                        //         disable: false
                        //     },
                        //     {
                        //         value: "OE",
                        //         checked: false,
                        //         disable: false
                        //     }],
                        //     handler: ({ component, ...rest }: any) => { component.changeTechnology(rest) },
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        // {
                        //     key: "splitRatio",
                        //     type: "radio",
                        //     label: "Split Ratio",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: messages.get('splitRatio'),
                        //     option: [{
                        //         value: "1:16",
                        //         checked: true,
                        //         disable: false
                        //     },
                        //     {
                        //         value: "2:32",
                        //         checked: false,
                        //         disable: true
                        //     }],
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        {
                            key: "redundancyService",
                            type: "radio",
                            label: "Redundancy Service",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Redundancy Service Required"
                            },
                            option: [{
                                value: "Yes",
                                checked: false,
                                disable: false
                            },
                            {
                                value: "No",
                                checked: false,
                                disable: false
                            }],
                            handler: ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "rejectIfredundancyService",
                            type: "radio",
                            label: "Reject If Redundancy Service",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Reject If Redundancy Service Required"
                            },
                            option: [{
                                value: "Yes",
                                checked: false,
                                disable: true
                            },
                            {
                                value: "No",
                                checked: false,
                                disable: true
                            }],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "contractTerm",
                            type: "select",
                            label: "Contract Term",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Contarct Term Required"
                            },
                            option: ['12 Months'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "promoCode",
                            type: "select",
                            label: "Promo Code",
                            value: "",
                            option: ['M1MOECODXXX','VQLGAXXXXXXX'],
                            visible:true,
                            errorMsg: {},
                            validators: (validator: any) => [
                            ]
                        }
                    ]
                }
            },
            {
                heading: "Site Survey Details",
                visible:true,
                id: "siteSurveyDetails",
                key: "siteSurveyDetails",
                type: "group",
                options: {
                    children: [
                        {
                            key: "dateOfActivation",
                            type: "date",
                            label: "Preferred Site Survey Date",
                            value: "",
                            dateFrom: [],
                            dateTo: [],
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Preferred Site Survey Date is Required"
                            },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "preferredSiteSurveySlot",
                            type: "select",
                            label: "Preferred Site Survey Slot",
                            value: "",
                            option: ['AM', 'PM'],
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Preferred Site Survey Slot is Required"
                            },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: 'reverseAppointment',
                            type: 'button',
                            // showButtons:false,
                            value: 'Reserve Appointment',
                            label: '',
                            visible: true,
                            readOnly: false,
                            handler: ({ component, ...rest }: any) => {
                            },
                            errorMsg: {},
                            validators: (validator: any) => [],
                          },
                    ]
                }
            },
            {
                heading: "End User Details",
                visible:true,
                id: "authorizedEndUserDetails",
                key: "authorizedEndUserDetails",
                type: "group",
                options: {
                    children: [
                        {
                            key: "salutation",
                            type: "select",
                            label: "Salutation",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authSalutation'),
                            option: ['Mr', 'Mrs', 'Miss'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "userName",
                            type: "text",
                            value: "",
                            label: "Name",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('name'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            key: "phoneNumber",
                            type: "text",
                            value: "",
                            label: "Contact Number",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authContactNumber'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.phoneNumber(),
                                validator.maxLength(12)
    
                            ]
    
    
                        },
                        {
                            key: "alternatePhone",
                            type: "text",
                            value: "",
                            label: "Alternate Contact Number",
                            visible: true,
                            errorMsg: messages.get('authContactNumber'),
                            validators: (validator: any) => [
                                validation.phoneNumber(),
                                validator.maxLength(12)
                            ]
                        },
                        {
                            key: "faxNumber",
                            type: "text",
                            value: "",
                            label: "Fax Number",
                            visible: true,
                            errorMsg: messages.get('faxNumber'),
                            validators: (validator: any) => [
                                validation.phoneNumber()
                            ]
    
    
                        },
                        {
                            key: "emailAddress",
                            type: "email",
                            label: "Email Address",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authEmailAddress'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
                        },
                        // {
                        //     key: "userType",
                        //     type: "radio",
                        //     label: "End User Type",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: messages.get('authEndUuserType'),
                        //     option: [{
                        //         value: "Normal",
                        //         checked: true,
                        //         disable: false
                        //     },
                        //     {
                        //         value: "VIP",
                        //         checked: false,
                        //         disable: false
                        //     }],
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                    ]
                }
            },
            //price details
            // {
            //     heading: "Price Details",
            //     visible:true,
            //     id: "priceDetails",
            //     key: "priceDetails",
            //     type: "group",
            //     options: {
            //         children: [
    
            //             {
            //                 key: "installationCharge",
            //                 type: "text",
            //                 label: "Installation Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 value: "",
            //                 errorMsg: {
            //                 },
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "serviceActivationCharge",
            //                 type: "text",
            //                 value: "",
            //                 label: "Service Activation Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "monthlyRecurringCharge",
            //                 type: "text",
            //                 value: "",
            //                 label: "Monthly Recurring Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "noteMessage",
            //                 type: "message",
            //                 value: "",
            //                 label: "Note: Pricing shown is indicative and actual price will be shown in the invoice.",
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             }
            //         ]
            //     }
            // },
            {
                heading: "Additional Information",
                visible:true,
                id: "additionalInformation",
                key: "additionalInformation",
                type: "group",
                options: {
                    children: [
                        {
                            key: "addInformation",
                            type: "textarea",
                            label: "Additional Information",
                            visible: true,
                            validators: (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
    
    
                    ]
                }
            }
        ]  
    },
    coOrdinateSystemForm : {
        controls: [
            {
                heading: "Serving Address (NBAP DP)",
                visible:true,
                "createOrder":true,
                id: "servingAddress",
                key: "servingAddress",
                type: "group",
                options: {
                    children: [
                        {
                            key: "dpName",
                            type: "text",
                            value: "NLT User",
                            readOnly: true,
                            visible: true,
                            label: "DP Name",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "coordinateSystem",
                            type: "select",
                            value: "",
                            // readOnly: true,
                            defaultValue:"SVY21",
                            required: true,
                            visible: true,
                            label: "Coordinate System",
                            option: ['SVY21', 'WGS84'],
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "gpsXcoordinates",
                            type: "text",
                            // value: "31842.260",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "GPS X co-ordinates",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "gpsYcoordinates",
                            type: "text",
                            // value: "34123.037",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "GPS Y co-ordinates",
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            key: "height",
                            type: "text",
                            // value: "10.2",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "Height(m)",
                            validators: (validator: any) => [
                            ]
                        },
                    ]
                }
            },
            {
                heading: "Installation Address",
                visible:true,
                createOrder:true,
                id: "installationAddress",
                key: "installationAddress",
                type: "group",
                options: {
                    children: [
                        {
                            key: "coordinateSystem",
                            type: "select",
                            value: "",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "Coordinate System",
                            option: ['SVY21', 'WGS84'],
                            errorMsg: messages.get('coordinateSystem'),
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "gpsXcoordinates",
                            type: "text",
                            value: "",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "GPS X co-ordinates",
                            errorMsg: messages.get('GPSXcoOordinates'),
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "gpsYcoordinates",
                            type: "text",
                            value: "",
                            // readOnly: true,
                            visible: true,
                            required: true,
                            label: "GPS Y co-ordinates",
                            errorMsg: messages.get('GPSYcoOordinates'),
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "height",
                            type: "text",
                            value: "",
                            required: true,
                            visible: true,
                            label: "Height(m)",
                            errorMsg: messages.get('height'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.height(),
                                validator.maxLength(10)
                            ]
                        },
                        {
                            key: "fileupload",
                            type: "fileupload",
                            value: "",
                            label: "Upload Required Documents",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Document is required",
                            },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },

                    ]
                }
            },
            {
                heading: "Order Details",
                visible:true,
                id: "orderDetails",
                key: "orderDetails",
                type: "group",
                options: {
                    children: [
                        {
                            key: "appRefIdentifier",
                            type: "text",
                            value: "",
                            required: true,
                            visible: true,
                            label: "Application Reference Identifier",
                            errorMsg: {
                                required: "Application Reference Identifier Required",
                                maxlength: "Application reference cannot exceed maximum length of 50, and special characters are allowed.",
                            },
                            validators: (validator: any) => [
                                validator.required,
                                validator.maxLength(50)
                            ]
                        },
                        {
                            key: "installationType",
                            type: "select",
                            label: "Installation Type",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('installationType'),
                            option: ['NLT to Install', 'Self Provide', 'Pre Install TP'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        // {
                        //     key: "technology",
                        //     type: "radio",
                        //     label: "Technology",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: messages.get('technology'),
                        //     readOnly: true,
                        //     option: [{
                        //         value: "GPON",
                        //         checked: true,
                        //         disable: false
                        //     },
                        //     {
                        //         value: "OE",
                        //         checked: false,
                        //         disable: false
                        //     }],
                        //     handler: ({ component, ...rest }: any) => { component.changeTechnology(rest) },
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        // {
                        //     key: "splitRatio",
                        //     type: "radio",
                        //     label: "Split Ratio",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: messages.get('splitRatio'),
                        //     option: [{
                        //         value: "1:16",
                        //         checked: true,
                        //         disable: false
                        //     },
                        //     {
                        //         value: "2:32",
                        //         checked: false,
                        //         disable: true
                        //     }],
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        {
                            key: "redundancyService",
                            type: "radio",
                            label: "Redundancy Service",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Redundancy Service Required"
                            },
                            option: [{
                                value: "Yes",
                                checked: false,
                                disable: false
                            },
                            {
                                value: "No",
                                checked: false,
                                disable: false
                            }],
                            handler: ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "rejectIfredundancyService",
                            type: "radio",
                            label: "Reject If Redundancy Service",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Reject If Redundancy Service Required"
                            },
                            option: [{
                                value: "Yes",
                                checked: false,
                                disable: true
                            },
                            {
                                value: "No",
                                checked: false,
                                disable: true
                            }],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "contractTerm",
                            type: "select",
                            label: "Contract Term",
                            value: "",
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Contarct Term Required"
                            },
                            option: ['12 Months'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "promoCode",
                            type: "select",
                            label: "Promo Code",
                            value: "",
                            option: ['M1MOECODXXX','VQLGAXXXXXXX'],
                            visible:true,
                            errorMsg: {},
                            validators: (validator: any) => [
                            ]
                        }
                    ]
                }
            },
            {
                heading: "Site Survey Details",
                visible:true,
                id: "siteSurveyDetails",
                key: "siteSurveyDetails",
                type: "group",
                options: {
                    children: [
                        // {
                        //     key: "dateOfActivation",
                        //     type: "date",
                        //     dateFrom: [],
                        //     dateTo: [],
                        //     label: "Preferred Site Survey Date",
                        //     value: "",
                        //     required: true,
                        //     visible: true,
                        //     errorMsg: {
                        //         required: "Preferred Site Survey Date is Required"
                        //     },
                        //     validators: (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        {
                            key: 'dateOfActivation',
                            type: 'date',
                            label: 'Preferred Site Survey Date',
                            defaultValue: '',
                            required: true,
                            visible: true,
                            readOnly: false,
                            dateFrom: [],
                            dateTo: [],
                            errorMsg: { required: 'Preferred Site Survey Date is required' },
                            validators: (validator: any) => [validator.required],
                          },
                        {
                            key: "preferredSiteSurveySlot",
                            type: "select",
                            label: "Preferred Site Survey Slot",
                            value: "",
                            option: ['AM', 'PM'],
                            required: true,
                            visible: true,
                            errorMsg: {
                                required: "Preferred Site Survey Slot is Required"
                            },
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: 'reverseAppointment',
                            type: 'button',
                            // showButtons:false,
                            value: 'Reserve Appointment',
                            label: '',
                            visible: true,
                            readOnly: false,
                            handler: ({ component, ...rest }: any) => {
                            },
                            errorMsg: {},
                            validators: (validator: any) => [],
                          },
                    ]
                }
            },
            {
                heading: "End User Details",
                visible:true,
                id: "authorizedEndUserDetails",
                key: "authorizedEndUserDetails",
                type: "group",
                options: {
                    children: [
                        {
                            key: "salutation",
                            type: "select",
                            label: "Salutation",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authSalutation'),
                            option: ['Mr', 'Mrs', 'Miss'],
                            validators: (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            key: "userName",
                            type: "text",
                            value: "",
                            label: "Name",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('name'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            key: "phoneNumber",
                            type: "text",
                            value: "",
                            label: "Contact Number",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authContactNumber'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.phoneNumber(),
                                validator.maxLength(12)
    
                            ]
    
    
                        },
                        {
                            key: "alternatePhone",
                            type: "text",
                            value: "",
                            label: "Alternate Contact Number",
                            visible: true,
                            errorMsg: messages.get('authContactNumber'),
                            validators: (validator: any) => [
                                validation.phoneNumber(),
                                validator.maxLength(12)
                            ]
                        },
                        {
                            key: "faxNumber",
                            type: "text",
                            value: "",
                            label: "Fax Number",
                            visible: true,
                            errorMsg: messages.get('faxNumber'),
                            validators: (validator: any) => [
                                validation.phoneNumber()
                            ]
    
    
                        },
                        {
                            key: "emailAddress",
                            type: "email",
                            label: "Email Address",
                            required: true,
                            visible: true,
                            errorMsg: messages.get('authEmailAddress'),
                            validators: (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
                        },
                    ]
                }
            },
            // price details
            // {
            //     heading: "Price Details",
            //     visible:true,
            //     id: "priceDetails",
            //     key: "priceDetails",
            //     type: "group",
            //     options: {
            //         children: [
    
            //             {
            //                 key: "installationCharge",
            //                 type: "text",
            //                 label: "Installation Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 value: "",
            //                 errorMsg: {
            //                 },
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "serviceActivationCharge",
            //                 type: "text",
            //                 value: "",
            //                 label: "Service Activation Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "monthlyRecurringCharge",
            //                 type: "text",
            //                 value: "",
            //                 label: "Monthly Recurring Charge",
            //                 readOnly: true,
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             },
            //             {
            //                 key: "noteMessage",
            //                 type: "message",
            //                 value: "",
            //                 label: "Note: Pricing shown is indicative and actual price will be shown in the invoice.",
            //                 visible: true,
            //                 errorMsg: {},
            //                 validators: (validator: any) => [
            //                 ]
            //             }
            //         ]
            //     }
            // },
            {
                heading: "Additional Information",
                visible:true,
                id: "additionalInformation",
                key: "additionalInformation",
                type: "group",
                options: {
                    children: [
                        {
                            key: "addInformation",
                            type: "textarea",
                            label: "Additional Information",
                            visible: true,
                            validators: (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
    
    
                    ]
                }
            }
        ]
    },  
}

export default nbapS11ConnectionFormData;
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const coToCoConnectionFormData = {
    "controls": [
        {
            "heading": "Order Details",
            visible:true,
            "createOrder":true,
            "id": "orderDetails",
            "key": "orderDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "appRefIdentifier",
                        "type": "text",
                        "value": "",
                        "required": true,
                        visible: true,
                        "label": "Application Reference Identifier",
                        "errorMsg": {
                            "required": "Application Reference Identifier required",
                            "maxlength": "Application reference cannot exceed maximum length of 50, and special characters are allowed.",
                        },
                        "validators": (validator: any) => [
                            validator.required,
                            validator.maxLength(50)
                        ]
                    },
                    {
                        "key": "segmentfromCO",
                        "type": "select",
                        "label": "Segment From CO",
                        "value": "",
                        "required": true,
                        visible: true,
                        "option": ['AM', 'AR', 'BT'],
                        "errorMsg": {
                            "required": "Segment From CO required",
                        },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "segmenttoCO",
                        "type": "select",
                        "label": "Segment To CO",
                        "value": "",
                        "required": true,
                        visible: true,
                        "option": ['AM', 'AR', 'BT'],
                        "errorMsg": {
                            "required": "Segment To CO required",
                        },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "redundancyService",
                        "type": "radio",
                        "label": "Redundancy Service",
                        "value": "",
                        "required": true,
                        visible: true,
                        "errorMsg": {
                            "required": "Redundancy Service required",
                        },
                        "handler": ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
                        "option": [{
                            "value": "Yes",
                            "checked": false,
                            "disable": false
                        },
                        {
                            "value": "No",
                            "checked": false,
                            "disable": false
                        }],
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "redundancyServiceoptions",
                        "type": "select",
                        "label": "Redundancy Service Options",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {
                            "required": "Redundancy Service Options required",
                        },
                        "option": ['Wireline Diversity', 'Duct', 'Path'],

                        "validators": (validator: any) => [
                        ]
                    },

                    {
                        "key": "rejectIfredundancyService",
                        "type": "radio",
                        "label": "Reject If Redundancy Service Unavailable",
                        "value": "",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {
                            "required": "Reject If Redundancy Service required",
                        },
                        "option": [{
                            "value": "Yes",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "No",
                            "checked": false,
                            "disable": true
                        }],
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "promoCode",
                        "type": "select",
                        "label": "Promo Code",
                        "value": "",
                        "option": ['M1MOECODXXX','VQLGAXXXXXXX'],
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                      },
                    {
                        "key": "contractTerm",
                        "type": "select",
                        "label": "Contract Term",
                        "value": "",
                        "required": true,
                        visible: true,
                        "errorMsg": {
                            "required": "Contarct Term required",
                        },
                        "option": ['12 Months'],
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    
                ]
            }
        },
        {
            "heading": "Activation Details",
            visible:true,
            "id": "activationDetails",
            "key": "activationDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "dateOfActivation",
                        "type": "date",
                        "label": "Date of Activation",
                        "value": "",
                        "required": true,
                        visible: true,
                        "option": "",
                        "errorMsg": {
                            "required": "Date of Activation required",
                        },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "dateOfApplication",
                        "type": "text",
                        "label": "Date of Application",
                        "value": "",
                       // "required": true,
                        visible: true,
                        "option": "",
                        // "errorMsg": {
                        //     "required": "Date of Activation required",
                        // },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "orderStatus",
                        "type": "text",
                        "label": "Order Status",
                        "value": "",
                       // "required": true,
                        visible: true,
                        "option": "",
                        // "errorMsg": {
                        //     "required": "Date of Activation required",
                        // },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "tentativeStatusDate",
                        "type": "text",
                        "label": "Tentative Status Date",
                        "value": "",
                       // "required": true,
                        visible: true,
                        "option": "",
                        // "errorMsg": {
                        //     "required": "Date of Activation required",
                        // },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "rejectionReason",
                        "type": "text",
                        "label": "Rejection Reason",
                        "value": "",
                       // "required": true,
                        visible: true,
                        "option": "",
                        // "errorMsg": {
                        //     "required": "Date of Activation required",
                        // },
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                ]
            }
        },

        // {
        //     "heading": "Price Details",
        //     visible:true,
        //     "id": "priceDetails",
        //     "key": "priceDetails",
        //     "type": "group",
        //     "options": {
        //         "children": [
        //             {
        //                 "key": "installationCharge",
        //                 "type": "text",
        //                 "label": "Installation Charge",
        //                 "readOnly": true,
        //                 visible: true,
        //                 "value": "",
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 "key": "serviceActivationCharge",
        //                 "type": "text",
        //                 "value": "",
        //                 "label": "Service Activation Charge",
        //                 "readOnly": true,
        //                 visible: true,
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 "key": "monthlyRecurringCharge",
        //                 "type": "text",
        //                 "value": "",
        //                 "label": "Monthly Recurring Charge",
        //                 "readOnly": true,
        //                 visible: true,
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 "key": "noteMessage",
        //                 "type": "message",
        //                 "value": "",
        //                 "label": "Note: Pricing shown is indicative and actual price will be shown in the invoice.",
        //                 visible: true,
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             }
        //         ]
        //     }
        // },
        {
            "heading": "Additional Information",
            visible:true,
            "id": "additionalInformation",
            "key": "additionalInformation",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "addInformation",
                        "type": "textarea",
                        "label": "Additional Information",
                        visible: true,
                        "validators": (validator: any) => [
                            validator.maxLength(254)
                        ]
                    }
                ]
            }
        },
    ]
}
export default coToCoConnectionFormData;
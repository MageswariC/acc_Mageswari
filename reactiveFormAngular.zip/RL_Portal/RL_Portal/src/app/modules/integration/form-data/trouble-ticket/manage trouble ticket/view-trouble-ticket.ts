import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";
const view_ticket={
        // onehr_fibreProvision_fibreMain_main_manage : {
        "controls": [
            {
                "heading": "Ticket Details",
                visible:true,
                "createOrder":true,
                "id": "ticketDetails",
                "key": "ticketDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "ticketStatus",
                            "type": "text",
                            "value": "",
                            visible: true,
                            "label": "Ticket Status",
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            "key": "incidentID",
                            "type": "text",
                            "value": "",
                            "label": "Incident ID",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "incidentType",
                            "type": "text",
                            "value": "",
                            "required": true,
                            "label": "Incident Type",
                            "readOnly": true,
                            "option":['1 hour activation', 'Fibre provisioning', 'Joint investigation', 'Fibre maintenance', 'Fibre monitoring', 'CO-LOC Fault', 'OSS/BSS Fault'],
                            "errorMsg": {},
                            "handler": ({ component, ...rest }: any) => { component.changeIncidentType(rest) },
                            "validators": (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            "key": "OpCoIncidentID",
                            "type": "text",
                            "value": "",
                            "label": "OpCo Indident Id",
                            "errorMsg": {},
                            "readOnly": true,
                            "handler": ({ component, ...rest }: any) => { component.getOpCoIndidentId(rest) },
                            "validators": (validator: any) => [
                                
                            ]
                        },
                        {
                            "key": "orderRequestIdentifier",
                            "type": "text",
                            "value": "",
                            "required": true,
                            "readOnly": true,
                            "label": "Order Request Identifier",
                            "errorMsg": {},
                            "handler": ({ component, ...rest }: any) => { component.getOri(rest) },
                            "validators": (validator: any) => [
                                validator.required,  
                            ]
                        },
                        {
                            "key": "causeOfFault",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Cause Of Fault",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "scheduleCode",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Schedule",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        // {
                        //     "key": "urgency",
                        //     "type": "select",
                        //     "value": "",
                        //     "required": true,
                        //     visible:true,
                        //     "readOnly": true,
                        //     "label": "Urgency",
                        //     "option": ['Critical', 'High','Medium', 'Low'],
                        //     "errorMsg": messages.get('applicationReferenceIdentifier'),
                        //     "validators": (validator: any) => [
                        //         validator.required,
                        //         validator.maxLength(50)
                        //     ]
                        // },
                        // {
                        //     "key": "impact",
                        //     "type": "select",
                        //     "label": "Impact",
                        //     "value": "",
                        //     "required": true,
                        //     visible:true,
                        //     "readOnly": true,
                        //     "option": ['Extensive/Wide Spread', 'Significant/Large', 'Moderate/Limited', 'Minor/Localized'],
                        //     "errorMsg": messages.get('technology'),
                        //     "validators": (validator: any) => [
                        //         validator.required,
                        //     ]
                        // },
                        // {
                        //     "key": "numberOfServicesImpacted",
                        //     "type": "text",
                        //     "value": "",
                        //     "readOnly": true, 
                        //     visible: true,
                        //     "label": "No Of Services Impacted",
                        //     "errorMsg": {},
                        //     "validators": (validator: any) => [
    
                        //     ]
                        // },
                        {
                            "key": "ticketSummary",
                            "type": "text",
                            "value": "",
                            "required": true,
                            visible:true,
                            "readOnly": true,
                            "label": "Ticket Summary",
                            "validators": (validator: any) => [
                                validator.required,
                                validator.maxLength(50)
                            ]
                        },
                        {
                            "key": "ticketDescription",
                            "type": "text",
                            "value": "",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "label": "Ticket Description",
                            "validators": (validator: any) => [
                                validator.required,
                                validator.maxLength(50)
                            ]
                        },
                    ]
                }
            },
            // Service Order Details
            {
                "heading": "Service Order Details",
                visible:true,
                "createOrder":true,
                "id": "serviceOrderDetails",
                "key": "serviceOrderDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            visible: true,
                            "label": "FirstName",
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            "required": true,
                            visible:true,
                            "readOnly": true, 
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
                        },
                        {
                            "key": "blockHouseNumber",
                            "type": "text",
                            "value": "",
                            "label": "Block/House Number",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "unitNo",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Unit Number",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "buildingName",
                            "type": "text",
                            "value": "",
                            "label": "Building Name",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "streetName",
                            "type": "text",
                            "value": "",
                            "label": "Street Name",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "postalCode",
                            "type": "text",
                            "value": "",
                            "label": "Postal Code",
                            "readOnly": true, 
                            visible: true,
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "copifType",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "COPIF Type",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "buildingType",
                            "type": "text",
                            "value": "",
                            "option": ["HDB"],
                            "readOnly": true, 
                            visible: true,
                            "label": "Building Type",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                        {
                            "key": "schedule",
                            "type": "text",
                            "value": "",
                            "readOnly": true, 
                            visible: true,
                            "label": "Schedule",
                            "errorMsg": {},
                            "validators": (validator: any) => [
    
                            ]
                        },
                    ]
                }
            },
            // End User Details
            {
                "heading": "End User Details",
                visible:true,
                "id": "endUserPremisesContactDetails",
                "key": "endUserPremisesContactDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
    
                        },
                    ]
                }
            },
            // Secondary Requesting Licensee
            {
                "heading": "Secondary Requesting Licensee",
                visible:true,
                "id": "secondaryRequestingLisensee",
                "key": "secondaryRequestingLisensee",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
    
                        },
                    ]
                }
            },
            // RL Field Engineer Contact Details
            {
                "heading": "RL Field Engineer Contact Details",
                visible:true,
                "id": "rlFieldEngineerContactDetails",
                "key": "rlFieldEngineerContactDetails",
                "type": "group",
                "options": {
                    "children": [
                        {
                            "key": "firstName",
                            "type": "text",
                            "value": "",
                            "label": "First Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "lastName",
                            "type": "text",
                            "value": "",
                            "label": "Last Name",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('name'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.name()
                            ]
                        },
                        {
                            "key": "contactNumber",
                            "type": "text",
                            "value": "",
                            "label": "Contact Number",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('contactNumber'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.phoneNumber()
                            ]
    
                        },
                        {
                            "key": "emailAddress",
                            "type": "email",
                            "label": "Email Address",
                            // "required": true,
                            visible:true,
                            "readOnly": true,
                            "errorMsg": messages.get('emailAddress'),
                            "validators": (validator: any) => [
                                validator.required,
                                validation.emailAddress()
                            ]
    
                        },
                    ]
                }
            },
            // Ticket Attachment
            {
                "heading": "Ticket Attachment",
                visible:true,
                "id": "ticketAttachment",
                "key": "ticketAttachment",
                "type": "group",
                "options": {
                    "children": [
    
                        // {
                        //     "key": "Attachment",
                        //     "type": "fileupload",
                        //     "label": "Attachment",
                        //     // "readOnly": true, 
                        //     visible: true,
                        //     "value": "",
                        //     "errorMsg": {
                        //     },
                        //     "validators": (validator: any) => [
                        //     ]
                        // },
                        {
                            "key": "attachment",
                            "type": "fileupload",
                            "label": "Attachment",
                            // "readOnly": true, 
                            visible: true,
                            "readOnly": true,
                            "value": "",
                            "errorMsg": {
                            },
                            "validators": (validator: any) => [
                            ]
                        },
                        {
                            "key": "notes",
                            "type": "textarea",
                            "label": "Notes",
                            "readOnly": true,
                            visible:true,
                            "validators": (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
                    ]
                }
            },
            //Ticket Appointment
            {
                "heading": "Ticket Appointment",
                visible:true,
                "id": "ticketAppointment",
                "key": "ticketAppointment",
                "type": "group",
                "options": {
                    "children": [
                        // {
                        //     "key": "AppointmentDate",
                        //     "type": "text",
                        //     "value": "",
                        //     "label": "Appointment Date",
                        //     "required": true,
                        //     visible:true,
                        //     "errorMsg": messages.get('name'),
                        //     "validators": (validator: any) => [
                        //         validator.required,
                        //         validation.name()
                        //     ]
                        // },
                        {
                            key: "appointmentDate",
                            type: "text",
                            value: "",
                            visible: true,
                            required: true,
                            "readOnly": true,
                            label: "Appointment Date",
                            // option: ['#01-01', '#01-02','#01-03','#01-04','#01-05','#01-06','#01-07','#01-08','#01-09','#01-10'],
                            // errorMsg: messages.get('houseNo'),
                            validators: (validator: any) => [
                            ]
                        },
                        {
                            "key": "appointmentSlot",
                            "type": "text",
                            "value": "",
                            "required": true,
                            visible:true,
                            "readOnly": true,
                            "label": "Appointment Slot",
                            "option": ['9:00-11:00', '11:00-13:00','14:00-16:00', '16:00-18:00'],
                            "errorMsg": messages.get('applicationReferenceIdentifier'),
                            "validators": (validator: any) => [
                                validator.required,
                            ]
                        },
                        {
                            "key": "notes",
                            "type": "textarea",
                            "label": "Notes",
                            visible:true,
                            "readOnly": true,
                            "validators": (validator: any) => [
                                validator.maxLength(254)
                            ]
                        },
                    ]
                }
            },
        ]}


export default view_ticket; 
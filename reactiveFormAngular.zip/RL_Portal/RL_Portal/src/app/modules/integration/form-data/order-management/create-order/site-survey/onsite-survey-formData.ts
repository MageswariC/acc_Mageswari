
import { messages } from "src/app/components/utilities/error-message";
import validation from "src/app/components/utilities/validation";

const onSiteSurveyFormData = {
    "controls": [

        {
            "heading": "OnSite Visit Address",
            visible: true,
            "createOrder": true,
            "id": "onSiteVisitAddress",
            "key": "onSiteVisitAddress",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "buildingNumber",
                        "type": "text",
                        "value": "23",
                        visible: true,
                        readOnly:true,
                        "label": "Building Number",
                        "option": ['304'],
                        "errorMsg": messages.get('houseNo'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "buildingName",
                        "type": "text",
                        "value": "Building_ex",
                        "label": "Building Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "streetName",
                        "type": "text",
                        "value": "Tampines Street",
                        "label": "Street Name",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "unitNumber",
                        "type": "text",
                        "value": "#11-22",
                        "readOnly": true,
                        visible: true,
                        "label": "Unit Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "postalCode",
                        "type": "text",
                        "value": "600123",
                        "label": "Postal Code",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "landmark",
                        "type": "text",
                        "value": "Central Park",
                        "label": "Landmark",
                        "readOnly": true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "HDB",
                        "option": ["HDB"],
                        "readOnly": true,
                        visible: true,
                        "label": "Building Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "coverageStatus",
                        "type": "text",
                        "value": "Unit Reached",
                        "readOnly": true,
                        visible: true,
                        "label": "Coverage Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "copifType",
                        "type": "text",
                        "value": "Pre-Copif",
                        "readOnly": true,
                        visible: true,
                        "label": "COPIF Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        key: "coordinateSystem",
                        type: "text",
                        value: "WGS84",
                        readOnly: true,
                        visible: true,
                        label: "Coordinate System",
                        option: ['SVY21', 'WGS84'],
                        errorMsg: messages.get('coordinateSystem'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "gpsXcoordinates",
                        type: "text",
                        value: "333.111",
                        readOnly: true,
                        visible: true,
                        label: "GPS X co-ordinates",
                        errorMsg: messages.get('GPSXcoOordinates'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "gpsYcoordinates",
                        type: "text",
                        value: "331.112",
                        readOnly: true,
                        visible: true,
                        label: "GPS Y co-ordinates",
                        errorMsg: messages.get('GPSYcoOordinates'),
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                ]
            }
        },
        {
            "heading": "Order Details",
            visible: true,
            "id": "orderDetails",
            "key": "orderDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "appRefIdentifier",
                        "type": "text",
                        "value": "",
                        "required": true,
                        visible: true,
                        "label": "Application Reference Identifier",
                        "errorMsg": messages.get('applicationReferenceIdentifier'),
                        "validators": (validator: any) => [
                            validator.required,
                            validator.maxLength(50)
                        ]
                    }
                ]

            }
        },
        {
            "heading": "Site Survey Details",
            visible: true,
            "id": "siteSurveyDetails",
            "key": "siteSurveyDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "timeSlotOption",
                        "type": "radio",
                        "label": "Timeslot Option",
                        "value": "",
                        "required": true,
                        visible: true,
                        "option": [{
                            "value": "Normal",
                            "checked": true,
                            "disable": false
                        },
                        {
                            "value": "Seasonal",
                            "checked": false,
                            "disable": false
                        }],
                        "errorMsg": {
                        },
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "dateOfActivation",
                        "type": "date",
                        "label": "Date of Activation",
                        "value": "",
                        "required": true,
                        visible: true,
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "installationTime",
                        "type": "select",
                        "value": "",
                        "required": true,
                        visible: true,
                        "label": "Installation Time",
                        "option": ['12PM', '6PM'],
                        "errorMsg": messages.get('installationTime'),
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "reverseAppointment",
                        "type": "button",
                        "value": "Reserve Appointment",
                        "label": "",
                        visible: true,
                        "validators": (validator: any) => [
                        ]
                    },
                ]
            }
        },
        {
            heading: "End User Details",
            visible: true,
            id: "authorizedEndUserDetails",
            key: "authorizedEndUserDetails",
            type: "group",
            options: {
                children: [
                    {
                        key: "salutation",
                        type: "select",
                        label: "Salutation",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('authSalutation'),
                        option: ['Mr', 'Mrs', 'Miss'],
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "userName",
                        type: "text",
                        value: "",
                        label: "Name",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('name'),
                        validators: (validator: any) => [
                            validator.required,
                            validation.name()
                        ]
                    },
                    {
                        key: "phoneNumber",
                        type: "text",
                        value: "",
                        label: "Contact Number",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('authContactNumber'),
                        validators: (validator: any) => [
                            validator.required,
                            validation.phoneNumber(),
                            validator.maxLength(12)

                        ]


                    },
                    {
                        key: "alternatePhone",
                        type: "text",
                        value: "",
                        label: "Alternate Contact Number",
                        visible: true,
                        errorMsg: messages.get('authContactNumber'),
                        validators: (validator: any) => [
                            validation.phoneNumber(),
                            validator.maxLength(12)
                        ]
                    },
                    {
                        key: "emailAddress",
                        type: "email",
                        label: "Email Address",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('authEmailAddress'),
                        validators: (validator: any) => [
                            validator.required,
                            validation.emailAddress()
                        ]
                    }
                ]
            }
        },
        {
            "heading": "Additional Information",
            visible: true,
            "id": "additionalInformation",
            "key": "additionalInformation",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "addInformation",
                        "type": "textarea",
                        "label": "Additional Information",
                        visible: true,
                        "validators": (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


                ]
            }
        },
    ]
}
export default onSiteSurveyFormData;
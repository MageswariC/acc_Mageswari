import { Validators } from "@angular/forms";
// import { alphanumeric } from "../utilities/validation";
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";

const dpConnectionFormData = {
    "controls": [
        {
            heading: "Installation Address",
            visible:true,
            "createOrder":true,
            id: "installationAddress",
            key: "installationAddress",
            type: "group",
            options: {
                "children": [
                    {
                        key: "blockHouseNumber",
                        type: "text",
                        value: "",
                        required: true,
                        visible: true,
                        readOnly: true,
                        label: "Block/House Number",
                        errorMsg: messages.get('houseNo'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "buildingName",
                        type: "text",
                        value: "",
                        label: "Building Name",
                        readOnly: true,
                        visible: true,
                        errorMsg: {},
                        validators: (validator: any) => [
                        ]
                    },
                    {
                        key: "streetName",
                        type: "text",
                        value: "",
                        label: "Street Name",
                        readOnly: true,
                        visible: true,
                        errorMsg: {},
                        validators: (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "",
                        required:true,
                        visible: true,
                        readOnly: true,
                        "label": "Building Type",
                        
                        "errorMsg": messages.get('houseNo'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    // {
                    //     key: "unitNumber",
                    //     type: "text",
                    //     value: "",
                    //     readOnly: true,
                    //     visible: true,
                    //     label: "Unit Number",
                    //     errorMsg: {},
                    //     validators: (validator: any) => [

                    //     ]
                    // },
                    // {
                    //     key: "postalCode",
                    //     type: "text",
                    //     value: "",
                    //     label: "Postal Code",
                    //     readOnly: true,
                    //     visible: true,
                    //     errorMsg: {},
                    //     validators: (validator: any) => [

                    //     ]
                    // },
                    {
                        key: "copifType",
                        type: "text",
                        value: "",
                        readOnly: true,
                        visible: true,
                        label: "COPIF Type",
                        errorMsg: {},
                        validators: (validator: any) => [

                        ]
                    },
                    {
                        key: "coverageStatus",
                        type: "text",
                        value: "",
                        readOnly: true,
                        visible: true,
                        label: "Coverage Status",
                        errorMsg: {},
                        "validators": (validator: any) => [

                        ]
                    }
                    
                ]
            }
        },
        {
            heading: "Order Details",
            visible:true,
            id: "orderDetails",
            key: "orderDetails",
            type: "group",
            options: {
                children: [
                    {
                        key: "appRefIdentifier",
                        type: "text",
                        value: "",
                        required: true,
                        visible: true,
                        label: "Application Reference Number",
                        errorMsg: messages.get('applicationReferenceIdentifier'),
                        validators: (validator: any) => [
                            validator.required,
                            validator.maxLength(50)
                        ]
                    },
                    {
                        key: "redundancyService",
                        type: "radio",
                        label: "Redundancy Service",
                        value: "",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('redudencyRequired'),
                        option: [{
                            value: "Yes",
                            checked: false,
                            disable: false
                        },
                        {
                            value: "No",
                            checked: true,
                            disable: false
                        }],
                        handler: ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        key: "rejectIfredundancyService",
                        type: "radio",
                        label: "Reject If Redundancy Service Unavailable",
                        value: "",
                        required: false,
                        visible: true,
                        errorMsg: messages.get('rejectRedudency'),
                        option: [{
                            "value": "Yes",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "No",
                            "checked": true,
                            "disable": true
                        }],
                        validators: (validator: any) => [
                        ]
                    },
                    {
                        key: "contractTerm",
                        type: "select",
                        label: "Contract Term",
                        value: "",
                        required: true,
                        visible: true,
                        errorMsg: messages.get('contractTerm'),
                        option: ['12 Months'],
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "promoCode",
                        "type": "select",
                        "label": "Promo Code",
                        "value": "",
                        "option": ['M1MOECODXXX','VQLGAXXXXXXX'],
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                      }
                ]
            }
        },
        {
            heading: "Activation Details",
            visible:true,
            id: "activationDetails",
            key: "activationDetails",
            type: "group",
            options: {
                children: [

                    {
                        key: "dateOfActivation",
                        type: "date",
                        label: "Date of Activation",
                        value: "",
                        required: true,
                        visible: true,
                        validators: (validator: any) => [
                            validator.required,
                        ]
                    },


                ]
            }
        },

        // {
        //     heading: "Price Details",
        //     visible:true,
        //     id: "priceDetails",
        //     key: "priceDetails",
        //     type: "group",
        //     options: {
        //         children: [
        //             {
        //                 key: "name",
        //                 type: "text",
        //                 label: "Name",
        //                 readOnly: true,
        //                 visible: true,
        //                 value: "",
        //                 errorMsg: {
        //                 },
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "description",
        //                 type: "text",
        //                 label: "Description",
        //                 readOnly: true,
        //                 visible: true,
        //                 value: "",
        //                 errorMsg: {
        //                 },
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "amount",
        //                 type: "text",
        //                 label: "Amount",
        //                 readOnly: true,
        //                 visible: true,
        //                 value: "",
        //                 errorMsg: {
        //                 },
        //                 validators: (validator: any) => [
        //                 ]
        //             },

        //             {
        //                 key: "installationCharge",
        //                 type: "text",
        //                 label: "Installation Charge",
        //                 readOnly: true,
        //                 visible: true,
        //                 value: "",
        //                 errorMsg: {
        //                 },
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "serviceActivationCharge",
        //                 type: "text",
        //                 value: "",
        //                 label: "Service Activation Charge",
        //                 readOnly: true,
        //                 visible: true,
        //                 errorMsg: {},
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 key: "monthlyRecurringCharge",
        //                 type: "text",
        //                 value: "",
        //                 label: "Monthly Recurring Charge",
        //                 readOnly: true,
        //                 visible: true,
        //                 errorMsg: {},
        //                 validators: (validator: any) => [
        //                 ]
        //             },
        //             {
        //                 "key": "noteMessage",
        //                 "type": "message",
        //                 "value": "",
        //                 "label": "Note: Pricing shown is indicative and actual price will be shown in the invoice.",
        //                 visible: true,
        //                 "errorMsg": {},
        //                 "validators": (validator: any) => [
        //                 ]
        //             }
        //         ]
        //     }
        // },
        {
            heading: "Additional Information",
            visible:true,
            id: "additionalInformation",
            key: "additionalInformation",
            type: "group",
            options: {
                children: [
                    {
                        key: "addInformation",
                        type: "textarea",
                        label: "Additional Information",
                        visible: true,
                        validators: (validator: any) => [
                            validator.maxLength(254)
                        ]
                    },


                ]
            }
        },
    ]
}
export default dpConnectionFormData;
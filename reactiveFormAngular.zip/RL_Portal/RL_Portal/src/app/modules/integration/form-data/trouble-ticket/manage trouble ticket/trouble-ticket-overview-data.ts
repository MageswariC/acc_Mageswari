export const troubleTicketColoumn = [
    {
        header: 'OpCo Indident Id',
        value: 'OpCoIndidentId'
    },
    {
      header: 'Incident ID',
      value: 'incidentID'
    },
    {
        header: 'Order Request Identifier',
        value: 'ori'
    },
    {
      header: 'Incident Summary',
      value: 'incidentSummary'
    },
    {
      header: 'Appointment Date',
      value: 'appointmentDate'
    },
    {
        header: 'Appointment Slot',
        value: 'appointmentSlot'
    },
    {
        header: 'Cause of Fault',
        value: 'causeofFault'
    },
    {
        header: 'Incident Status',
        value: 'incidentStatus'
    },
   
  ]

  const displayTableData1 = [
    {
      OpCoIndidentId: "OP11118858855",
      incidentID: "ON7987387389",
      ori: "02-01-07012022-45671-A",
      incidentSummary: "TP-No signal",
      appointmentDate:"NA",
      appointmentSlot: "NA",
      causeofFault: "Denied Access by End User",
      incidentStatus: "pending"
    },
    
  ]

  // const troubleticketDataApi = [
  //   {
  //     heading:"Payment Information",
  //     label:"payment_information",
  //     readOnly:true,
  //     tableColoumFormat:  tableColoumFormat1,
  //     tableRowData: displayTableData1
  //   }
  // ]

  //export default troubleticketDataApi;
  
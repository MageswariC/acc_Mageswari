import { messages } from '../../utilities/error-message';
import validation from '../../utilities/validation';
const serachOrder = {
  controls: [
    {
      heading: 'Check Order Status',
      id: 'checkOrderStatus',
      key: 'checkOrderStatus',
      options: {
        children: [
          {
            key: 'applicationRefNo',
            type: 'text',
            value: '',
            required: true,
            visible: true,
            label: 'Application Reference Number',
            inputMask:'UU/UU/00A/0000/000',
            errorMsg: messages.get('applicationRefNo'),
            validators: (validator: any) => [
              validator.required,
              // validator.maxlength(),
              // validation.applicationReferenceIdentifier(),
            ],
          },
          {
            key: 'or',
            type: 'lable',
            value: 'OR',
            visible: true,
            label: '',

            errorMsg: {},
            validators: (validator: any) => [],
          },
          {
            key: 'orderReqIdentifier',
            type: 'text',
            value: '',
            required: true,
            visible: true,
            label: 'Order Request Identifier',
            inputMask:'00-00-00000000-00000-U',
            placeholder: '02-01-07012022-45671-A',
            errorMsg: { required: 'Order Request Identifier is required' },
            validators: (validator: any) => [validator.required],
          },
        ],
      },
    },
  ],
};
export default serachOrder;

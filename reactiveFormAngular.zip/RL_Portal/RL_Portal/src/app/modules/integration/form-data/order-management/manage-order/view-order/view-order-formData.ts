
import { messages } from "../../../../utilities/error-message";
import validation from "../../../../utilities/validation";

const residentialEndUserConnectionViewFormData = {
    "controls": [
        {
            "heading": "Application Details",
            visible:true,
            "id": "orderDetails",
            "key": "orderDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "ori",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Order Request Identifier",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "appRefIdentifier",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Application Reference No ",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "dateOfApp",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Date of Application",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "orderStatus",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Order Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "tentativeDate",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Tentative Provisioing Date",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                ]
            }
        },
        {
            "heading": "End User Details",
            "createOrder":true,
            visible:true,
            "id": "installationAddress",
            "key": "installationAddress",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "blockHouseNumber",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "readOnly": true, 
                        "label": "Block/House Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "buildingName",
                        "type": "text",
                        "value": "",
                        "label": "Building Name",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "streetName",
                        "type": "text",
                        "value": "",
                        "label": "Street Name",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "unitNumber",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "Unit Number",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "postalCode",
                        "type": "text",
                        "value": "",
                        "label": "Postal Code",
                        "readOnly": true, 
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "buildingType",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "Building Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "coverageStatus",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "Coverage Status",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "copifType",
                        "type": "text",
                        "value": "",
                        "readOnly": true, 
                        visible: true,
                        "label": "COPIF Type",
                        "errorMsg": {},
                        "validators": (validator: any) => [

                        ]
                    },
                    {
                        "key": "salutation",
                        "type": "text",
                        "label": "Salutation",
                        "readOnly": true,
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },

                    {
                        "key": "userName",
                        "type": "text",
                        "value": "",
                        "label": "Name",
                        "readOnly": true,
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "phoneNumber",
                        "type": "text",
                        "value": "",
                        "label": "Contact Number",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]

                    },
                    {
                        "key": "faxNumber",
                        "type": "text",
                        "value": "",
                        "label": "Fax Number",
                        visible:true,
                        "readOnly": true, 
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },

                    {
                        "key": "emailAddress",
                        "type": "email",
                        "label": "Email Address",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "userType",
                        "type": "radio",
                        "label": "End User Type",
                        "readOnly": false, 
                        visible:true,
                        "errorMsg": {},
                        "option": [{
                            "value": "Normal",
                            "checked": false,
                            "disable": false
                        },
                        {
                            "value": "VIP",
                            "checked": false,
                            "disable": false
                        }],
                        "validators": (validator: any) => [
                            
                        ]
                    },
                ]
            }
        },
        {
            "heading": "Connection Details",
            visible:true,
            "id": "connectionDetails",
            "key": "connectionDetails",
            "type": "group",
            "options": {
                "children": [
                   
                    {
                        "key": "technology",
                        "type": "radio",
                        "label": "Technology",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "option": [{
                            "value": "GPON",
                            "checked": true,
                            "disable": true
                        },
                        {
                            "value": "OE",
                            "checked": false,
                            "disable": true
                        }],
                        "errorMsg":{},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "splitRatio",
                        "type": "radio",
                        "readOnly": true, 
                        visible:true,
                        "label": "Split Ratio",
                        "value": "",

                        "option": [{
                            "value": "1:1",
                            "checked": true,
                            "disable": true
                        },
                        {
                            "value": "1:24",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "2:24",
                            "checked": false,
                            "disable": true
                        }],
                        "errorMsg": {},

                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "redundancyService",
                        "type": "radio",
                        "label": "Redundancy Service",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "option": [{
                            "value": "Yes",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "No",
                            "checked": true,
                            "disable": true
                        }],
                        "validators": (validator: any) => [
                           
                        ]
                    },
                    {
                        "key": "rejectIfredundancyService",
                        "type": "radio",
                        "label": "Reject If Redundancy Service Unavailable",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "option": [{
                            "value": "Yes",
                            "checked": false,
                            "disable": true
                        },
                        {
                            "value": "No",
                            "checked": true,
                            "disable": true
                        }],
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "contractTerm",
                        "type": "text",
                        "label": "Contract Term",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "promoCode",
                        "type": "text",
                        "label": "Promo Code",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "timeSlotOption",
                        "type": "radio",
                        "label": "Timeslot Option",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "option": [{
                            "value": "Normal",
                            "checked": true,
                            "disable": true
                        },
                        {
                            "value": "Seasonal",
                            "checked": false,
                            "disable": true
                        }],
                        "errorMsg": {
                        },
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "dateOfActivation",
                        "type": "text",
                        "label": "Date of Activation",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "installationTime",
                        "type": "text",
                        "value": "",
                        visible:true,
                        "readOnly": true, 
                        "label": "Installation Time",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                ]
            }
        },

        {
            "heading": "Network Attributes",
            visible:true,
            "id": "networkAttributes",
            "key": "networkAttributes",
            "type": "group",
            "options": {
                "children": [
                   
                    {
                        "key": "Provideinternalcablingtofirstterminationpoint",
                        "type": "text",
                        "label": "Provide internal cabling to first termination point                        ",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "LenthfromingresstoTP",
                        "type": "text",
                        "label": "Lenth from ingress to TP (in meters)",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "orderType",
                        "type": "text",
                        "label": "Order Type",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "Terminationtiecablefiberstrandidentifier",
                        "type": "text",
                        "label": "Termination tie cable fiber strand identifier",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "QPFDFtransmissontiecableport",
                        "type": "text",
                        "label": "QP FDF transmisson tie cable port",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "LocationofTP",
                        "type": "text",
                        "label": "Location of TP",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "IngressPoint",
                        "type": "text",
                        "label": "Ingress Point",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "COSite",
                        "type": "text",
                        "label": "CO Site",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "FTPPort",
                        "type": "text",
                        "label": "FTP Port",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "UplinkOrderReference",
                        "type": "text",
                        "label": "Uplink Order Reference",
                        "value": "",
                        "readOnly": true, 
                        visible:true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                ]
            }
        }
    ]
}
export default residentialEndUserConnectionViewFormData;
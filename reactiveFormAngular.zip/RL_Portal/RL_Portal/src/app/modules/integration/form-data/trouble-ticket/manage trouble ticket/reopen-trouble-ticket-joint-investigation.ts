import { Validators } from "@angular/forms";
import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation";
const reopenTroubleTicketJoint = {
    "controls": [
        {      cancelOrder:true,
            "heading": "Ticket Details",
            visible:true,
            "createOrder":true,
            "id": "ticketDetails",
            "key": "ticketDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "incidentID",
                        "type": "text",
                        "value": "",
                        "required": true,
                        "readOnly":true,
                        "label": " Incident Ticket ID",
                         visible:true,
                        "errorMsg":  {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "reason",
                        "type": "textarea",
                        "value": "",
                        "required": true,
                        visible:true,
                        "label": "Reason",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "jointInvestigationLocation",
                        "type": "select",
                        "label": "Joint Investigation Location",
                        "value": "",
                        "required": true,
                        visible:true,
                        "option": ['CO-LOC', 'Serving Cabinet', 'End User Premises'],
                        "errorMsg": messages.get('technology'),
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                  
                  ]
            }
        },
        {
            heading: 'Ticket Appointment',
            visible: true,
            id: 'ticketAppointment',
            key: 'ticketAppointment',
            type: 'group',
            options: {
              children: [
    
                {
                  key: 'appointmentDate',
                  type: 'date',
                  label: 'Date of Activation',
                  defaultValue: '',
                  required: true,
                  visible: true,
                  dateFrom: [],
                  dateTo: [],
                  errorMsg: {'required': 'Date of Activation is required'},
                  validators: (validator: any) => [],
                },
                {
                  key: 'appointmentSlot',
                  type: 'select',
                  defaultValue: '',
                  required: true,
                  visible: true,
                  label: 'Appointment Slot',
                  option: [],
                  handler: ({ component, ...rest }: any) => {
                    component.installationTimeChange(rest);
                  },
                  errorMsg: {'required': 'Appointment Time Type is required'},
                  validators: (validator: any) => [validator.required],
                },
                {
                  key: 'reserveAppoinment',
                  type: 'button',
                  value: 'Reserve Appointment',
                  label: '',
                  visible: true,
                  readOnly:true,
                  handler: ({ component, ...rest }: any) => {
                    component.reverseAppointment(rest);
                  },
                  errorMsg: {},
                  validators: (validator: any) => [],
                },
                {
                  key: 'Notes',
                  type: 'textarea',
                  label: 'Notes',
                  visible: true,
                  validators: (validator: any) => [validator.maxLength(254)],
                },
              ],
            },
          },
    
         
    ]
}
export default reopenTroubleTicketJoint;
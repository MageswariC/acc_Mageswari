import { messages } from "../../../utilities/error-message";
import validation from "../../../utilities/validation"

export const nonResidentialEndUserFormData = {
  "controls": [
    {
      "heading": "Installation Address",
      visible: true,
      "createOrder": true,
      "id": "installationDetails",
      "key": "installationDetails",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "buildingName",
            "type": "text",
            "value": "",
            "label": "Building Name",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "streetName",
            "type": "text",
            "label": "Street Name",
            "value": "",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [

            ]
          },

          {
            "key": "postalCode",
            "type": "text",
            "value": "",
            "label": "Postal Code",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "buildingType",
            "type": "text",
            "label": "Building Type",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "coverageStatus",
            "type": "text",
            "value": "",
            "label": "Coverage Status",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "copifType",
            "type": "text",
            "value": "",
            "label": "COPIF Type",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "dataCenter",
            "type": "text",
            "value": "",
            "label": "Data Center",
            visible: true,
            readOnly: true,
            "errorMsg": messages.get('dataCenter'),
            "validators": (validator: any) => [

            ]
          }

        ]
      }
    },
    {
      "heading": "Order Details",
      visible: true,
      "id": "orderDetails",
      "key": "orderDetails",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "arnNo",
            "type": "text",
            "value": "",
            required: true,
            visible: true,
            "label": "Application Reference Number",
            inputMask: 'UU/UU/00U/0000/000',
            placeholder: 'UU/UU/00A/9876/567',
            errorMsg: {
              required: 'Application Reference Number is required',
              mask: 'Invalid Application Reference Number eg:UU/UU/00A/9876/567',
            },

            "validators": (validator: any) => [
              validator.required,
              validator.maxLength(14)
            ]
          },
          {
            "key": "installationType",
            "type": "select",
            "label": "Installation Type",
            required: true,
            visible: true,
            "errorMsg": messages.get('installationType'),
            "option": ['NLT to Install', 'Self Provide', 'TP In Riser'],
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "technology",
            "type": "radio",
            "label": "Technology",
            defaultValue: 'GPON',
            required: true,
            visible: true,
            readonly: true,
            "errorMsg": messages.get('technology'),
            "option": [{
              "value": "GPON",
              "checked": true,
              "disable": false
            },
            {
              "value": "OE",
              "checked": false,
              "disable": false
            }],
            "handler": ({ component, ...rest }: any) => { component.changeTechnology(rest) },
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "splitRatio",
            "type": "radio",
            "label": "Split Ratio",
            required: true,
            visible: true,
            defaultValue: '1:16',
            handler: ({ component, ...rest }: any) => {
              component.spiltRatioChange(rest);
            },
            "errorMsg": messages.get('splitRatio'),
            "option": [{
              "value": "1:16",
              "checked": true,
              "disable": false
            },
            {
              "value": "1:1",
              "checked": false,
              "disable": false
            }
              ,
            {
              "value": "2:32",
              "checked": false,
              "disable": true
            }],
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "redundancyService",
            "type": "radio",
            "label": "Redundancy Service",
            defaultValue: 'No',
            required: true,
            visible: true,
            "errorMsg": messages.get('redundancyService'),
            "option": [{
              "value": "Yes",
              "checked": false,
              "disable": false
            },
            {
              "value": "No",
              "checked": true,
              "disable": false
            }],
            "handler": ({ component, ...rest }: any) => { component.changeRedundancyService(rest) },
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "rejectIfredundancyService",
            "type": "radio",
            "label": "Reject If Redundancy Service Unavailable",
            "required": false,
            defaultValue: 'No',
            visible: true,
            disabled:true,
            "errorMsg": {},
            "option": [{
              value: 'Yes',
              checked: false,
              disable: true,
            },
            {
              value: 'No',
              checked: true,
              disable: true,
            },],
            "validators": (validator: any) => [
            ]
          },

          {
            "key": "promoCode",
            "type": "select",
            "label": "Promo Code",
            "value": "",
            "option": [],
            visible: true,
            "errorMsg": {},
            handler: ({ component, ...rest }: any) => {
              component.promoCodeChange(rest);
            },
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "contractTerm",
            "type": "select",
            "label": "Contract Term",
            required: true,
            visible: true,
            "errorMsg": messages.get('contracterm'),
            "option": ['12 Months', '1 Months'],
            "validators": (validator: any) => [
              validator.required,
            ]
          },
        ]
      }
    },
    {
      "heading": "Activation Details",
      visible: true,
      "id": "activationDetails",
      "key": "activationDetails",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "timeSlotOption",
            "type": "radio",
            "option": [{
              "value": "Normal",
              "checked": true,
              "disable": false
            },
            {
              "value": "Express",
              "checked": false,
              "disable": false
            }],

            "label": "Timeslot Option",
            required: true,
            visible: true,
            "errorMsg": messages.get('timeSlotOption'),
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "dateOfActivation",
            "type": "date",
            "label": "RFA Date",
            required: true,
            visible: true,
            "errorMsg": messages.get('dateofActivation'),
            "validators": (validator: any) => [
              validator.required,
            ]
          },

          {
            "key": "installationTime",
            "type": "select",
            "label": "Installation Time",
            required: true,
            visible: true,
            "errorMsg": messages.get('{ "required": "Installation Time is required", }'),
            "option": ['AM', 'PM'],
            "validators": (validator: any) => [
              validator.required,
            ]
          },

        ]
      }
    },

    {
      "heading": "Authorised End User Details",
      visible: true,
      "id": "endUserDetails",
      "key": "endUserDetails",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "salutation",
            "type": "select",
            "label": "Salutation",
            required: true,
            visible: true,
            "errorMsg": messages.get('authSalutation'),
            "option": ['Mr', 'Mrs', 'Miss'],
            "validators": (validator: any) => [
              validator.required,
            ]
          },
          {
            "key": "userName",
            "type": "text",
            "value": "",
            "label": "Name",
            required: true,
            visible: true,
            "errorMsg": messages.get('name'),
            "validators": (validator: any) => [
              validator.required,
              validation.name()
            ]
          },
          {
            "key": "phoneNumber",
            "type": "text",
            "value": "",
            "label": "Contact Number",
            required: true,
            visible: true,
            "errorMsg": messages.get('authContactNumber'),
            "validators": (validator: any) => [
              validator.required,
              validation.phoneNumber()
            ]


          },
          {
            "key": "alternatePhone",
            "type": "text",
            "value": "",
            "label": "Alternate Contact Number",
            visible: true,
            "errorMsg": messages.get('authContactNumber'),
            "validators": (validator: any) => [
              validation.phoneNumber()
            ]
          },
          {
            "key": "faxNumber",
            "type": "text",
            "value": "",
            "label": "Fax Number",
            visible: true,
            "errorMsg": messages.get('faxNumber'),
            "validators": (validator: any) => [
              validation.phoneNumber()
            ]


          },
          {
            "key": "emailAddress",
            "type": "email",
            "label": "Email Address",
            required: true,
            visible: true,
            "errorMsg": messages.get('authEmailAddress'),
            "validators": (validator: any) => [
              validator.required,
              validation.emailAddress()
            ]
          },

        ]
      }
    },
    {
      "heading": "Price Details",
      visible: true,
      "id": "priceDetails",
      "key": "priceDetails",
      "type": "group",
      "options": {
        "children": [

          {
            "key": "installationCharge",
            "type": "text",
            "value": "",
            "label": "Installation Charge",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "serviceActivationCharge",
            "type": "text",
            "value": "",
            "label": "Service Activation Charge",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            "key": "monthlyRecurringCharge",
            "type": "text",
            "value": "$30",
            "label": "Monthly Recurring Charge",
            "errorMsg": {},
            readOnly: true,
            visible: true,
            "validators": (validator: any) => [
            ]
          },
          {
            key: 'noteMessage',
            type: 'message',
            value: '',
            label:
              'Note: Pricing shown is indicative and actual price will be shown in the invoice.',
            visible: true,
            errorMsg: {},
            validators: (validator: any) => [],
          },

        ]
      }
    },
    {
      "heading": "Additional Information",
      visible: true,
      "id": "addInformation",
      "key": "addInformation",
      "type": "group",
      "options": {
        "children": [
          {
            "key": "additionalInformation",
            "type": "textarea",
            "label": "Additional Information",
            "errorMsg": {},
            visible: true,
            "validators": (validator: any) => [
              validator.maxLength(254)
            ]
          },


        ]
      }
    },



  ]
}
export default nonResidentialEndUserFormData;
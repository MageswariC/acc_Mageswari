
import { messages } from "src/app/components/utilities/error-message";
import validation from "src/app/components/utilities/validation";
const preOrderFcForm = {
    controls: [{
      isFcBtnrequired:true,
        heading: "Feasibility Check",
        id: "feasibilityCheck",
        key: "feasibilityCheck",
        options: {
            children: [
                {
                    key: 'premiseType',
                    type: 'radio',
                    label: 'Premise Type',
                    defaultValue: '',
                    required: true,
                    visible: true,
                    option: [
                      {
                        value: 'Residential',
                        checked: true,
                        disable: false,
                      },
                      {
                        value: 'Non Residential',
                        checked: false,
                        disable: false,
                      },
                    ],
                    handler: ({ component, ...rest }: any) => {
                     
                    },
                    errorMsg: messages.get('requestType'),
                    validators: (validator: any) => [validator.required],
                  },     
                {
                    key: "postalCode",
                    type: "text",
                    value: "",
                    required: true,
                    visible: true,
                    label: "Postal Code",
                    errorMsg: {"required":"Postal Code is required"},
                    handler: () => {  },
                    validators: (validator: any) => [
                        validator.required,
                    ],
                    inputMask:"000000"
                },
                {
                    key: "unitNumber",
                    type: "text",
                    value: "",
                    visible: true,
                    label: "Unit Number",
                    errorMsg: {},
                    handler: () => {  },
                    validators: (validator: any) => [
                       
                    ]
                },
           
              
              
            ]
        }
    }
    ]
}
export default  preOrderFcForm; 
    
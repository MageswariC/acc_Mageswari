import { messages } from '../../utilities/error-message';
import validation from '../../utilities/validation';
const fibreroutingmap = {
  controls: [
    {
       isFcBtnrequired:true,
        heading: 'ORI check',
        id: 'feasibilityCheck',
        key: 'feasibilityCheck',
        options: {
          children: [
            {
              key: 'ori',
              type: 'text',
              value: '',
              visible: true,
              defaultValue: '',
              required: true,
              label: 'Primary Circuit ORI',
              errorMsg: { required: 'Order Request Identifier is required',
            pattern: "Invalid ORI pattern eg...." },
              handler: () => {},
              validators: (validator: any) => [
                validator.required,
              ],
            },
          ],
        },
      },
  ],
};
export default fibreroutingmap;


import { messages } from "../../../../../components/utilities/error-message";
import validation from "../../../../../components/utilities/validation";

const AddressNotFoundFormData = {
    controls: [
        {
            heading: "Installation Address",
            visible:true,
            createOrder:true,
            id: "installationDetails",
            key: "installationDetails",
            type: "group",
            options: {
                children: [
                    
                    {
                        key: 'buildingName',
                        type: 'text',
                        defaultValue: '',
                        label: 'Building Name',
                        visible: true,
                        errorMsg: {},
                        validators: (validator: any) => [],
                      },
                      {
                        key: 'streetName',
                        type: 'text',
                        defaultValue: '',
                        label: 'Street Name',
                        visible: true,
                        errorMsg: {},
                        validators: (validator: any) => [],
                      },
                    // {
                    //     "key": "unitNumber",
                    //     "type": "text",
                    //     "value": "",
                    //     "required": true,
                    //     visible: true,
                    //     "label": "Unit Number",
                    //     "errorMsg": {},
                    //     "validators": (validator: any) => [

                    //     ]
                    // },
                    // {
                    //     "key": "postalCode",
                    //     "type": "text",
                    //     "value": "",
                    //     "required": true,
                    //     "label": "Postal Code",
                    //     visible: true,
                    //     "errorMsg": {},
                    //     "validators": (validator: any) => [

                    //     ]
                    // },
                  
                ]
            }
        },
        {
            "heading": "Order Details",
            visible:true,
            "id": "orderDetails",
            "key": "orderDetails",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "arnNo",
                        "type": "text",
                        "value": "",
                        "required": true,
                        visible:true,
                        "label": "Application Reference Identifier",
                        errorMsg: {'required':'Application Reference Identifier is required'},
                        "validators": (validator: any) => [
                            validator.required,
                            validator.maxLength(50)
                        ]
                    },
                    
                ]
            }
        },
       
        {
            heading: 'End User Details',
            visible: true,
            id: 'endUserDetails',
            key: 'endUserDetails',
            type: 'group',
            options: {
              children: [
                {
                  key: 'salutation',
                  type: 'select',
                  label: 'Salutation',
                  defaultValue: 'Mr',
                  required: true,
                  visible: true,
                  errorMsg: { required: 'Salutation is required' },
                  option: ['Mr', 'Mrs', 'Miss'],
                  validators: (validator: any) => [validator.required],
                },
                {
                  key: 'endUsername',
                  type: 'text',
                  defaultValue: '',
                  label: 'Name',
                  required: true,
                  visible: true,
                  errorMsg: {'required': 'Name is required'},
                  validators: (validator: any) => [
                    validator.required,
                    validation.name(),
                  ],
                },
                {
                  key: 'endUserContactNo',
                  type: 'text',
                  defaultValue: '',
                  label: 'Contact Number',
                  required: true,
                  visible: true,
                  errorMsg: {'required': 'Contact Number  is required'},
                  validators: (validator: any) => [
                    validator.required,
                    validation.phoneNumber(),
                  ],
                },
                {
                  key: 'endUserfax',
                  type: 'text',
                  defaultValue: '',
                  label: 'Fax Number',
                  visible: true,
                  errorMsg: {'required': 'Fax Numbe  is required'},
                  validators: (validator: any) => [validation.phoneNumber()],
                },
                {
                  key: 'endUserEmailId',
                  type: 'email',
                  label: 'Email Address',
                  required: true,
                  visible: true,
                  defaultValue: '',
                  errorMsg: {'required': 'Email Address  is required'},
                  validators: (validator: any) => [
                    validator.required,
                    validation.emailAddress(),
                  ],
                },
              ],
            },
          },
          {
            heading: 'Additional Information',
            visible: true,
            id: 'additionalInfo',
            key: 'additionalInfo',
            type: 'group',
            options: {
              children: [
                {
                  key: 'addInformation',
                  type: 'textarea',
                  label: 'Additional Information',
                  visible: true,
                  defaultValue: '',
                  errorMsg: {},
                  validators: (validator: any) => [validator.maxLength(254)],
                },
              ],
            },
          },
    ]
}
export default AddressNotFoundFormData;
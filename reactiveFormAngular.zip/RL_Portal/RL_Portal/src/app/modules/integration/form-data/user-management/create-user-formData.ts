const createUserFormData = {
    "controls": [
        {
            "heading": "User Detail",
            visible:true,
            "createOrder":true,
            "id": "userInfo",
            "key": "userInfo",
            "type": "group",
            "options": {
                "children": [
                    {
                        "key": "userId",
                        "type": "text",
                        "value": "",
                        "label": "User Id",
                        required:true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "company",
                        "type": "select",
                        "value": "",
                        "label": "Company",
                        required:true,
                        "option": ["Singtel"],
                        "readOnly":true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "billingId",
                        "type": "multiSelect",
                        "value": "",
                        required:true,
                        visible: true,
                        selectedOptions:['02'],
                         "readOnly":true,
                        "label": "Billing ID",
                         "option": ["02","03","04"],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "emailId",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Alternate Email Address",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "password",
                        "type": "password",
                        "value": "",
                        "label": "Password",
                        required:true,
                        visible: true,
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "confirmPassword",
                        "type": "password",
                        "value": "",
                        required:true,
                        visible: true,
                        "label": "Confirm Password",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "principalName",
                        "type": "text",
                        "value": "",
                        required:true,
                        visible: true,
                        "label": "Principal Name",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            validator.required
                        ]
                    },
                    {
                        "key": "designation",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Designation",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "contactNo",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Contact No",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                        ]
                    },
                    {
                        "key": "faxNo",
                        "type": "text",
                        "value": "",
                        visible: true,
                        "label": "Fax No",
                        "errorMsg": {},
                        "validators": (validator: any) => [
                            
                        ]
                    },
                    {
                        "key": "expiryDate",
                        "type": "date",
                        "label": "Expiry Date",
                        "value": "",
                        // "required": true,
                        visible:true,
                        "validators": (validator: any) => [
                            validator.required,
                        ]
                    },
                    {
                        "key": "priorityCircuit",
                        "type": "checkbox",
                        "label": "Priority Circuit",
                        "option": ["Yes"],
                        "value": "",
                        visible:true,
                        "validators": (validator: any) => [
                        ]
                    }
                ]
            }
        },
        {
            "heading": "User Role",
            visible:true,
            "createOrder":true,
            "id": "role",
            "key": "role",
            "type": "group",
            "options": {
                "children": [                 
                    {
                        "key": "assign Roles",
                        "type": "checkbox",
                        "value": "",
                       // "required":true,
                        "visible": true,
                       // "selectedOptions":[''],
                        // "readOnly":true,
                        "label": "Assign Roles",
                         "option": [
                            {
                                value:"RL Admin"
                            },
                            { 
                                value:"RL User"
                            },
                            {
                                value:"Finance User"
                            },
                            {
                                value:"Trouble Ticket User"
                            },
                ],
                        "errorMsg": {},
                        "validators": (validator: any) => [
                           // validator.required
                        ]
                    }
                ]
            }
        }
    ]
}
export default createUserFormData;
import { createAction, props } from '@ngrx/store';

export const setRoomDetails = createAction('setRoomDetails',props<{ value: any }>());
export const getRoomDetails = createAction('getRoomDetails',props<{ payload: any }>());

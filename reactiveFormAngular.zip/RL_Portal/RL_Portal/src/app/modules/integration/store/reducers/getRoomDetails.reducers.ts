import { state } from '@angular/animations';
import { createReducer, on } from '@ngrx/store';
import { Action } from 'rxjs/internal/scheduler/Action';
import { getRoomDetails } from '../actions/getRoomDetails.action';
import { initialState } from '../state/getRoomDetails.state';
const _roomDetails = createReducer(
  
  initialState,
 
 on(getRoomDetails, (state, action) => {
 
 
    return {
    
      ...state,
      roomDetails: action.payload.status,
    };
  })
);
export function RoomDetailsReducer(state: any, action: any) { 
    return _roomDetails(state, action);
}


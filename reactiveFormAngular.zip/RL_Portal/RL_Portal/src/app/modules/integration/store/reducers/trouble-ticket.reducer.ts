import { createReducer, on } from "@ngrx/store";
import { successEntryIncidentTicket } from "../actions/trouble-ticket.action";
import { troubleTicketState } from "../state/trouble-ticket.state";




const _troubleTicketReducer= createReducer(troubleTicketState,
    on(successEntryIncidentTicket,(state,action)=>{

    
        return({
            ...troubleTicketState,
            getEntryIncidentTicketResponse :action.payload
        })
        
    }));

export function troubleTicketReducer(action:any, state:any){
    return _troubleTicketReducer(action,state);
}
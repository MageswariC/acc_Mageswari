import { createReducer, on } from "@ngrx/store"
import { feasibilityCheckSuccess, feasibilityReset } from "../actions/feasibility-check.action";
import { initialState } from "../state/feasibility-check.state";

const _feasibilityCheckReducer = createReducer(initialState,
    on(feasibilityReset, () => {
        return {
            ... initialState,
            isFeasibilityDataFetched:false
        }
    }),
    on(feasibilityCheckSuccess, (state, action) => {
        return {
            ...state,
            isFeasibilityDataFetched:true,
            feasibilityResponse:{... action.response}
        }
    })
);

export function FeasibilityCheckReducer(state: any, action: any) {
    return _feasibilityCheckReducer(state, action)
}
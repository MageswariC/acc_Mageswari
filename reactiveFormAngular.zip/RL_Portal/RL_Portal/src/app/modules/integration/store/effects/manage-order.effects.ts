
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { map, mergeMap } from 'rxjs';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { OrderManagementService } from '../../service/order-management/order-management.service';
import { getOrderDetails, successGetOrderDetails } from '../actions/manage-order.action';
@Injectable({
    providedIn: 'root',
  })
  export class ManageOrderEffects {
    constructor(private action$: Actions, private store: Store<DynamicComponentState>,private orderManagementServive: OrderManagementService ) {
  
    }
    getServiveOrderDetails$ = createEffect(
      () => {
        return this.action$.pipe(
          ofType(getOrderDetails),
          mergeMap((action) => {
            return this.orderManagementServive.getServiceOrderDetails({}).pipe(
              map((data) => {
                this.store.dispatch(setLoadingSpinner({ status: false }))
                return successGetOrderDetails({payload:data});
              })
            )
          })
        )
      }
    )
  }
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { createAction } from '@ngrx/store';
import { exhaustMap, map } from 'rxjs';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';

@Injectable()
export class customerEligibilityEffects {
  constructor(
    private actions$: Actions,
    private orderManagementService: OrderManagementService
  ) {
  }
  // customerEligibilty$ = createEffect(() => {
  //   return this.actions$.pipe(
  //     ofType(setCustomerEligibility),
  //     exhaustMap((action) => {
  //       return this.orderManagementService
  //         .getcustomerEligibility(action.value)
  //         .pipe(
  //           map((data) => {
  //             return getCustomerEligibility({ payload: data });
  //           })
  //         );
  //     })
  //   );
  // });
}

import { state } from '@angular/animations';
import { createReducer, on } from '@ngrx/store';
import { Action } from 'rxjs/internal/scheduler/Action';
import { getCODetails } from '../actions/getCODetails.action';

import { initialState } from '../state/getCODetails.state';
const _coDetails = createReducer(
  
  initialState,
 
 on(getCODetails, (state, action) => {
 
 
    return {
    
      ...state,
      CODetails: action.value.status,
    };
  })
);
export function CODetailsReducer(state: any, action: any) { 
    return _coDetails(state, action);
}


import { createAction, props } from '@ngrx/store';

export const setCODetails = createAction('setCODetails',props<{ value: any }>());
export const getCODetails = createAction('getCODetails',props<{ value: any }>());

import { createReducer, on } from "@ngrx/store";
import { successGetOrderDetails } from "../actions/manage-order.action";

import { manageOrderState } from "../state/manage-residential-connection.state";


const _manageOrderReducer= createReducer(manageOrderState,
    on(successGetOrderDetails,(state,action)=>{
        console.log(action);
        

    
        return({
            ...manageOrderState,
            manageOrderDetails :action.payload
        })
        
    }));

export function ManageOrderReducer(action:any, state:any){
    return _manageOrderReducer(action,state);
}
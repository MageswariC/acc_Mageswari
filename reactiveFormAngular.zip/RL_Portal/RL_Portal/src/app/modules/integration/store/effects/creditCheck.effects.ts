import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { createAction } from '@ngrx/store';
import { exhaustMap, map } from 'rxjs';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { getCreditCheck, setCreditCheck } from '../actions/creditCheck.action';
@Injectable()
export class creditCheckEffects {
  constructor(
    private actions$: Actions,
    private orderManagementService: OrderManagementService
  ) {}

  // creditCheck$ = createEffect(() => {
  //   return this.actions$.pipe(
  //     ofType(setCreditCheck),
  //     exhaustMap((action) => {
  //       return this.orderManagementService.getCreditCheck(action.value).pipe(
  //         map((data) => {
            
  //           return getCreditCheck({ payload: data });
  //         })
  //       );
  //     })
  //   );
  // });
}

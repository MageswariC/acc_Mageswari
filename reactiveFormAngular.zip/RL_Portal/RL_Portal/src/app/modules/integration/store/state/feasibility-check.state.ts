export const initialState: FeasibilityResponseState = {
    isFeasibilityDataFetched: false,
    feasibilityResponse: {}
}
export interface FeasibilityResponse {
    listOfUnits?: string[],
    listOfBlocks?: string[],
    coId?: any,
    buildingType?: any,
    feasibilityNote?: any,
    feasibilityCode?: any,
    streetName?: any,
    buildingName?: any,
    buildingHouseNo?: any,
    feasibilityStatus?: any,
    firstPassIndicator?: any,
    tpInstallation?: any,
    copifType?: any,
    physicalCo?: any,
    logicalCo?: any,
    isDataFetched?: boolean
}
export interface FeasibilityResponseState {
    isFeasibilityDataFetched: boolean,
    feasibilityResponse: FeasibilityResponse,
}
export interface ScheduleInfo {
    scheduleCode?: string,
    scheduleId?: string,
    scheduleName?: string,
    serviceType?: string
}
export interface FeasibilityRequestDTO {
    schedule?: string,
    unitNumber?: string,
    postalCode?: string,
    inputBuildingNo?: string,
    coordinateSystem?: string,
    longitude?: string,
    latitude?: string,
    coId?: string,
    coloRoomNumber?: string,
    coloRequestType?: string,
    rackSize?: string,
    weightOfDevice?: string,
    rackId?: string,
    quantityAcPhase1?: string,
    quantityAcPhase2?: string,
    dcBreaker?: string,
    qpid?: string
}
export interface FeasibilityRequest {
    scheduleInfo?: ScheduleInfo,
    feasibilityRequestDTO?: FeasibilityRequestDTO
}


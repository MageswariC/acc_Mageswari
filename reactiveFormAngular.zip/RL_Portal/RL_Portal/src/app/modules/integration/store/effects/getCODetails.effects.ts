import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { createAction } from '@ngrx/store';
import { exhaustMap, map } from 'rxjs';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { TroubleTicketService } from '../../service/trouble-ticket/trouble-ticket.service';
import { getCODetails, setCODetails } from '../actions/getCODetails.action';


@Injectable()
export class coDetailsEffects {
  constructor(
    private actions$: Actions,
    private troubleTicketService: TroubleTicketService
  ) {}

  // CODetails$ = createEffect(() => {
  
  
  //   return this.actions$.pipe(
  //     ofType(setCODetails),
      
  //     exhaustMap((action) => {
      
  //       return this.troubleTicketService.getCODetails(action.value).pipe(
  //         map((data) => {
            
            
  //           return getCODetails({ value: data });
  //         })
  //       );
  //     })
  //   );
  // });
}

import { createAction, props } from "@ngrx/store";
import { FeasibilityRequest, FeasibilityResponse } from "../state/feasibility-check.state";

export const FEASIBILITY_CHECK_ACTION = 'feasibility check';
export const FEASIBILITY_CHECK_SUCCESS = 'feasibility check success';
export const FEASIBILITY_CHECK_RESET = 'feasibility check reset';

export const feasibilityCheck = createAction(FEASIBILITY_CHECK_ACTION, props<{payload:FeasibilityRequest}>());
export const feasibilityCheckSuccess = createAction(FEASIBILITY_CHECK_SUCCESS, props<{response:FeasibilityResponse}>());
export const feasibilityReset = createAction(FEASIBILITY_CHECK_RESET);
import { createFeatureSelector, createSelector } from "@ngrx/store";

import { FeasibilityResponseState,  } from "../state/feasibility-check.state";


export const FEASIBILITY_CHECK_STATE_NAME = 'feasibility-check';
const feasibilityCheck = createFeatureSelector<FeasibilityResponseState>(FEASIBILITY_CHECK_STATE_NAME)

export const getFeasibilityRes = createSelector(feasibilityCheck, (state) => {
    return state;
})

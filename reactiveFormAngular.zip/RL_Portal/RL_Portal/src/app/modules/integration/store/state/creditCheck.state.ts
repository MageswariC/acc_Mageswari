export interface CreditCheckState {
  creditCheck: any;
}
export const initialState: CreditCheckState = {
  creditCheck: 1,
};

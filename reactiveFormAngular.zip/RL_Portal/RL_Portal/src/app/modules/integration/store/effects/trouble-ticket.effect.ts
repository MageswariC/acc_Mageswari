
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { map, mergeMap } from 'rxjs';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { TroubleTicketService } from '../../service/trouble-ticket/trouble-ticket.service';
import { getEntryIncidentTicket, successEntryIncidentTicket } from '../actions/trouble-ticket.action';



@Injectable({
  providedIn: 'root',
})
export class TroubleTicketEffects {
  constructor(private action$: Actions, private store: Store<DynamicComponentState>, private troubleTicketService:TroubleTicketService ) {

  }
  getIncidentTicket$ = createEffect(
    () => {
      return this.action$.pipe(
        ofType(getEntryIncidentTicket),
        mergeMap((action) => {
          return this.troubleTicketService.getEntryIncidentTicket({}).pipe(
            map((data) => {
              this.store.dispatch(setLoadingSpinner({ status: false }))
              return successEntryIncidentTicket({payload:data});
            })
          )
        })
      )
    }
  )
}

import { CreditCheckReducer } from './reducers/creditCheck.reducers';
import { CustomerEligibilityReducer } from './reducers/customerEligibility.reducers';

import { FeasibilityCheckReducer } from './reducers/feasibility-check.reducer';
import { CreateOrderReducer } from './reducers/order-management';
import { troubleTicketReducer } from './reducers/trouble-ticket.reducer';
import { CREDIT_CHECK_STATE_NAME } from './selectors/creditCheck.selectors';
import { CUSTOMER_ELIGIBILITY_STATE_NAME } from './selectors/customerEligibility.selectors';

import { FEASIBILITY_CHECK_STATE_NAME } from './selectors/feasibility-check.selectors';
import { CREATE_ORDER } from './selectors/order-management';
import { TROUBLE_TICKET_STATE_NAME } from './selectors/trouble-ticket.selectors';
import { CreditCheckState } from './state/creditCheck.state';
import { CustomerEligibilityState } from './state/customerEligibilty.state';

import { FeasibilityResponseState } from './state/feasibility-check.state';
import { CreateOrder } from './state/order-management';
import { ManageOrderReducer } from './reducers/manage-order.reducer';
import { MANAGEORDER_STATE_NAME } from './selectors/manage-order.selectors';
import { RoomDetailsReducer } from './reducers/getRoomDetails.reducers';
import { RoomDetailsState } from './state/getRoomDetails.state';
import { GET_ROOM_DETAILS } from './selectors/getRoomDetails.selectors';
import { CODetailsReducer } from './reducers/getCODetails.reducers';
import { CODetailsState } from './state/getCODetails.state';
import { GET_CO_DETAILS } from './selectors/getCODetails.selectors';
export interface RLState {
  [FEASIBILITY_CHECK_STATE_NAME]: FeasibilityResponseState;
  [TROUBLE_TICKET_STATE_NAME]: any;
  [CREATE_ORDER]: CreateOrder;
  [CREDIT_CHECK_STATE_NAME]: CreditCheckState;
  [CUSTOMER_ELIGIBILITY_STATE_NAME]: CustomerEligibilityState;
  [MANAGEORDER_STATE_NAME]: any;
  [GET_ROOM_DETAILS]:RoomDetailsState;
  [GET_CO_DETAILS]:CODetailsState;
}
export const RLReducer = {
  [FEASIBILITY_CHECK_STATE_NAME]: FeasibilityCheckReducer,
  [TROUBLE_TICKET_STATE_NAME]: troubleTicketReducer,
  [CREATE_ORDER]: CreateOrderReducer,
  [CREDIT_CHECK_STATE_NAME]: CreditCheckReducer,
  [CUSTOMER_ELIGIBILITY_STATE_NAME]: CustomerEligibilityReducer,
  [MANAGEORDER_STATE_NAME]: ManageOrderReducer,
  [GET_ROOM_DETAILS]:RoomDetailsReducer,
  [GET_CO_DETAILS]:CODetailsReducer
};

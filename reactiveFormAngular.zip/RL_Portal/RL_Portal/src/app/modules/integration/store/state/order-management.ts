import { ServiceOrder } from "../../interface/forms/common/service-order-detail-interface";

export const createOrder: CreateOrder = {
    serviceOrder: {

        installationDetails: {
        },
        orderDetails: {
        },
        activationDetails: {

        },
        pricingInfo: {
            bunldleName: '',
            productName: '',
            productDescription: '',
            mrcAmt: '',
            otcAmt: '',
        },
        endUserDetails: {

        },
        additionalInfo: {
        },
        otherInfo: {
            ori: '',
            orderSource: 'swp',
            orderType: 'A',
            revision: '1',
            reclasification: 'RESCO',//serviceType
            scheduleId: 'schedule 1',
            serviceType: 'RESCO'

        }
    },
    bookAppointmentStatus: '',
    availableDatesWithSlots: '',
    selectedDateWithSlot: ''
}
export interface CreateOrder {
    serviceOrder: ServiceOrder,
    bookAppointmentStatus: string,
    selectedDateWithSlot: any,
    availableDatesWithSlots: any,
}


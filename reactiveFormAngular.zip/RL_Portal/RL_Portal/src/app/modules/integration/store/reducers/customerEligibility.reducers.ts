import { createReducer, on } from '@ngrx/store';
import {
  getCustomerEligibility,
  setCustomerEligibility,
} from '../actions/customerEligibility.action';
import { initialState } from '../state/customerEligibilty.state';
const _customerEligibility = createReducer(
  initialState,
  on(getCustomerEligibility, (state, action) => {
  
    return {
      ...state,
      customerEligibility: action.payload,
    };
  })
);

export function CustomerEligibilityReducer(state: any, action: any) {
  return _customerEligibility(state, action);
}

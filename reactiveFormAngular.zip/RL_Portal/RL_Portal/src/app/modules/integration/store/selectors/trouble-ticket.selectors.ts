import { createFeatureSelector, createSelector } from "@ngrx/store";

export const TROUBLE_TICKET_STATE_NAME = 'troubleTicket';
const troubleTicketSelectors = createFeatureSelector<any>("troubleTicket");

export const getEntryIncidentTicketSelector= createSelector(troubleTicketSelectors,(state)=>{
    return state.getEntryIncidentTicketResponse;
})

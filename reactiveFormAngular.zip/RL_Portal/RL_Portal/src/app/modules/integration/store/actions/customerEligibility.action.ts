import { createAction, props } from '@ngrx/store';

export const setCustomerEligibility = createAction(
  'setCustomerEligibilty',
  props<{ value: any }>()
);
export const getCustomerEligibility = createAction(
  'getCustomerEligibilty',
  props<{ payload: any }>()
);

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { createAction } from '@ngrx/store';
import { exhaustMap, map } from 'rxjs';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { TroubleTicketService } from '../../service/trouble-ticket/trouble-ticket.service';
//import { getCreditCheck, setCreditCheck } from '../actions/creditCheck.action';
import { setRoomDetails } from '../actions/getRoomDetails.action';
import { getRoomDetails } from '../actions/getRoomDetails.action';
@Injectable()
export class roomDetailsEffects {
  constructor(
    private actions$: Actions,
    private troubleTicketService: TroubleTicketService
  ) {}

  // roomDetails$ = createEffect(() => {
  
  
  //   return this.actions$.pipe(
  //     ofType(setRoomDetails),
      
  //     exhaustMap((action) => {
      
  //       return this.troubleTicketService.getRoomDetails(action.value).pipe(
  //         map((data) => {
           
            
  //           return getRoomDetails({ payload: data });
  //         })
  //       );
  //     })
  //   );
  // });
}

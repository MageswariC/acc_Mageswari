import { createAction, props } from "@ngrx/store";
import { ServiceOrder } from "../../interface/forms/common/service-order-detail-interface";




export const INITIAL_STATE = 'initial state';
export const RETRIVE_SLOTS = 'retrive slots';
export const AVAILABLE_DATESWITHSLOTS = 'available dates slots';
export const LOADBUNDLENAME = 'load bundle with charge details';
export const BUNDLEDETAIL_SUCCESS = 'bundle detail success';
export const CHARGE_INFO = "charge info";
export const SELECTED_DATE = 'selected date with slot';
export const SELECTED_DATE_SUCCESS = 'selected date with slot success';
export const BOOK_APPOITMENT = 'book appointmtnty';
export const BOOK_APPOITMENT_SUCCESS = 'book appointmtnt success';
export const ORDER_SUBMISSION = 'order submission';
export const SET_OTHER_INFO = 'set other info';
// export const ORDER_SUBMISSION_SUCCESS = 'order submission success';

export const initialState = createAction(INITIAL_STATE);
export const retiveSlots = createAction(RETRIVE_SLOTS, props<{payload:any}>())
export const availableDatesWithSlot = createAction(AVAILABLE_DATESWITHSLOTS, props<{data:any}>());
//pricing info
export const loadBundleName = createAction(LOADBUNDLENAME, props<{payload:any}>())
export const bundleDetailSuccess = createAction(BUNDLEDETAIL_SUCCESS, props<{response:any}>())
export const bookAppointment = createAction(BOOK_APPOITMENT, props<{payload:any}>());
export const bookAppointmentSuccess = createAction(BOOK_APPOITMENT_SUCCESS, props<{payload:any}>());
export const selectedSlot = createAction(SELECTED_DATE, props<{data:any}>());
export const selectedSlotSuccess = createAction(SELECTED_DATE_SUCCESS, props<{data:any}>());
export const orderSubmission = createAction(ORDER_SUBMISSION, props<{payload:any}>())
export const setOtherInfo = createAction(SET_OTHER_INFO, props<{data:any}>())
// export const orderSubmissionSuccess = createAction(ORDER_SUBMISSION_SUCCESS, props<{response:any}>())
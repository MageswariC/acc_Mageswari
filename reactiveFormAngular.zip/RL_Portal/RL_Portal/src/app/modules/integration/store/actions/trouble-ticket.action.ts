import { createAction, props } from "@ngrx/store";


export const  getEntryIncidentTicket = createAction("getEntryIncidentTicket",props<{payload:any}>());
export const successEntryIncidentTicket = createAction("successEntryIncidentTicket",props<{payload:any}>());


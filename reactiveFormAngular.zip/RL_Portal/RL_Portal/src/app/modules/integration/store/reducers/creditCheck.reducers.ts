import { createReducer, on } from '@ngrx/store';
import { getCreditCheck } from '../actions/creditCheck.action';
import { initialState } from '../state/creditCheck.state';
const _creditCheck = createReducer(
  initialState,
  on(getCreditCheck, (state, action) => {
   
    return {
      ...state,
      creditCheck: action.payload.status,
    };
  })
);

export function CreditCheckReducer(state: any, action: any) {
  
  return _creditCheck(state, action);
}

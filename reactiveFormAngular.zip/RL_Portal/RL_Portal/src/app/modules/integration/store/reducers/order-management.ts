import { createReducer, on } from "@ngrx/store";
import { ServiceOrder } from "../../interface/forms/common/service-order-detail-interface";

import { bookAppointmentSuccess, initialState, availableDatesWithSlot, selectedSlot } from "../actions/residential-connection-create-order";
import { createOrder } from "../state/order-management";

const _createOrder = createReducer(createOrder,

    // on(bundleDetailSuccess, (state, action) => {
    //     const serviceOrderDetail: ServiceOrder = { ...state.serviceOrder }
    //     serviceOrderDetail.pricingInfo = { ...serviceOrderDetail.pricingInfo, bunldleName: action.response.bunldleName }
    //     return {
    //         ...state,
    //         serviceOrderDetail

    //     }
    // }),

    on(availableDatesWithSlot, (state, action) => {
        return {
            ...state,
            availableDatesWithSlots:action.data
        }
    }),
    on(selectedSlot, (state, action) => {
        return {
            ...state,
            selectedDateWithSlot: action.data,
        }
    }),

    on(bookAppointmentSuccess, (state, action) => {
        return {
            ...state,
            bookAppointmentStatus: action.payload.status,
        }
    }),



    on(initialState, (state, action) => {

        return {
            ...state,
            ...createOrder
        }
    }),
);

export function CreateOrderReducer(action: any, state: any) {
    return _createOrder(action, state);
}

interface ticketDetails{
 
    ticketStatus?: string,
    reopenIndicator?: string,
    incidentType?: string,
    incidentID?: string,
    OpCoIncidentID?: string,
    ori?: string,
    orderRequestIdentifier?: number,
    causeOfFault?: string,
    scheduleId?: number,
    scheduleCode?: number,
    scheduleName?: string,
    serviceType?: number,
    coloServiceType?: number,
    jointInvestigationLocation?: number,
    coDetail?: string,
    roomId?: number,
    ticketSummary?: string,
    ticketDescription?: string
}

interface ticketAppointment {
dateFrom?: string,
dateTo?: string,
appointmentSlot?: string,
appointmentDate?: string,
taskId?: string,
notes?: string
}

interface serviceOrderDetails{
firstName?: string,
lastName?: string,
contactNumber?: string,
emailAddress?: string,
blockHouseNumber?: number,
unitNo?: string,
buildingName?: number,
streetName?: string,
postalCode?: string,
copifType?: string,
dataCenter?: string,
coverageStatus?: string,
buildingType?: string
}

const exp={
getENtryIncidentTicketResponse: {
  ticketDetails: {
    ticketStatus: "Cancelled",
    reopenIndicator: 0,
    incidentType: "Fibre Provisioning Fault",
    incidentID: "ON2212160002604",
    OpCoIncidentID: "TEST_OPcoticketID - New",
    ori: "06-02-19112014-53728-A",
    orderRequestIdentifier: 0,
    causeOfFault: "Require BM Approval",
    scheduleId: 0,
    scheduleCode: 12,
    scheduleName: "CO-LOC Service",
    serviceType: 0,
    coloServiceType: 0,
    jointInvestigationLocation: 0,
    coDetail: "AM1",
    roomId: 0,
    ticketSummary: "TP No Signal",
    ticketDescription: "New Incident - Update 1"
  },
  ticketAppointment: {
    dateFrom: "2022-04-27T15:00:00.000+0000",
    dateTo: 0,
    appointmentSlot: "9:00-11:00",
    appointmentDate: "9:00-11:00",
    taskId: 0,
    notes: 0
  },
  serviceOrderDetails: {
    firstName: "Contact Name",
    lastName: "Contact Name",
    contactNumber: "TEST_ContactNumber",
    emailAddress: "TEST_ContactEmail",
    blockHouseNumber: 101,
    unitNo: "#10-309",
    buildingName: 100,
    streetName: "TAMPINES STREET 12",
    postalCode: "TAMPINES STREET 12",
    copifType: "Test",
    dataCenter: 0,
    coverageStatus: 0,
    buildingType: "Test"
  },
  endUserPremisesContactDetails: {
    firstName: "Contact Name",
    lastName: "Contact Name",
    contactNumber: "TEST_ContactNumber",
    salutation: 0,
    emailAddress: "TEST_ContactEmail"
  },
  secondaryRequestingLisensee: {
    firstName: "TEST_SCFirstName TEST_SCLastName",
    lastName: "TEST_SCFirstName TEST_SCLastName",
    contactNumber: 12345678,
    salutation: 0,
    emailAddress: "SCE@nlt.com"
  },
  rlFieldEngineerContactDetails: {
    firstName: "TEST_RL_FN TEST_RL_LN",
    lastName: "TEST_RL_FN TEST_RL_LN",
    contactNumber: 12345678,
    salutation: 0,
    emailAddress: "RL@nlt.com"
  },
  ticketAttachment: {
    attachment: 0,
    notes: 0
  }
}
}


export const troubleTicketState ={
getEntryIncidentTicketResponse:{}
}
export interface RoomDetailsState {
    roomDetails: any;
  }
  export const initialState:RoomDetailsState  = {
   roomDetails:[
        
   {
      "user": "swp",
      "operation": "RoomDetails",
      "location": "HG"
   }


    ]
  };
  

  
import { createAction, props } from "@ngrx/store";


export const  getOrderDetails = createAction("getOrderDetails",props<{payload:any}>());
export const successGetOrderDetails = createAction("successGetOrderDetails",props<{payload:any}>());


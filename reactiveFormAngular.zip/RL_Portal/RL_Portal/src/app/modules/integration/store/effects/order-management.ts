
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { map, mergeMap, tap } from 'rxjs';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';

import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { OrderManagementService } from '../../service/order-management/order-management.service';

import { bookAppointment, availableDatesWithSlot, bookAppointmentSuccess, loadBundleName, bundleDetailSuccess, orderSubmission, retiveSlots } from '../actions/residential-connection-create-order';

@Injectable({
  providedIn: 'root',
})

export class ResidentialEndUSerCreateOrderEffects {
  constructor(private action$: Actions,
    private store: Store<DynamicComponentState>,
    private router: Router,
    private toastrService: ToastrService,
    private orderManagementService: OrderManagementService) {

  }

  retriveSlots$ = createEffect(
    () => {

      return this.action$.pipe(
        ofType(retiveSlots),
        mergeMap((action) => {
          this.store.dispatch(setLoadingSpinner({ status: true }));
          let payload: any = {
            scheduleInfo: {
              scheduleCode: action.payload.scheduleCode
            },
            retrieveSlotForAppointmentRequestDTO: {
              centerCode: action.payload.centerCode, //mandatory if externalSystemId is empty (SO/SA)
              externalSystemId: action.payload.externalSystemId, // this is blank at time of create order
              latitude:action.payload.latitude,
              longitude:action.payload.longitude,
              street:action.payload.street,
              town:"SINGAPORE",
              postalCode:action.payload.postalCode,
              country:"SGP",
              coDetail:action.payload.coDetail,
              fromDate:new Date(),
              sourceType:"SWP",
              profileName:action.payload.profileName,
              taskType:action.payload.taskType,
              timeSlotOption: action.payload.timeSlotOption,
            }
          }
          // let payload = {SINGAPORE
          //   centerCode: action.payload.centerCode,
          //   timeSlotOption: action.payload.timeSlotOption,
          //   street: action.payload.streetName,
          //   town: 'SINGAPORE',
          //   postalCode: action.payload.postalCode,
          //   country: 'SGP',
          //   zone: action.payload.zone,
          //   fromDate: new Date().toUTCString,
          //   sourceType: 'SWP',
          //   profileName: action.payload.profileName, //#Question Function will be written for this
          //   taskType: '', //#Question Static
          //   externalSystemId: '',// #Question
          // };
          return this.orderManagementService.retriveSlots(payload).pipe(
            map((availableSlots) => {
              this.store.dispatch(setLoadingSpinner({ status: false }))
              // let slots;
              // if (data.timeSlotsList) {
              //   slots = this.orderManagementService.getTimeSlotsList(data.timeSlotsList);
              // }
              // let timeSlots = {
              //   actualAPIResponse: data,
              //   formattedResponse: slots
              // }
              return availableDatesWithSlot({ data: availableSlots });
            })
          )
        })
      )
    }
  )
  loadBundleName$ = createEffect(
    () => {

      return this.action$.pipe(
        ofType(loadBundleName),
        mergeMap((action) => {
          this.store.dispatch(setLoadingSpinner({ status: true }));
          let payload: any = {
            scheduleInfo: {
              scheduleCode: action.payload.scheduleCode
            },
            bundleListRequest: [
              {
                categoryRule: "PrimaryBundleRule",
                serviceType: "RESCO",
                splitRatio: action.payload.splitRatio,
                redundancy: action.payload.redundancyService,
                commitment: "12",
                roomType: "NA",
                buildingType: "Residential"
              },
              {
                categoryRule: "InstallationRule",
                serviceType: "MDFNR",
                buildingType: "Any",
                coverageStatus: "Any",
                copifType: "Any",
                firstPassFreeIndicator: "Any",
                firstTP: "Any"
              }
            ]

          }
          // let payload = {
          //   serviceType: 'RESCO',
          //   technology: action.payload.technology,
          //   splitRatio: action.payload.splitRatio,
          //   redundancyService: action.payload.redundancyService,
          //   commitment: '12',
          // }
          return this.orderManagementService.getBundleNameWithPriceDetails(payload).pipe(
            map((data) => {
              this.store.dispatch(setLoadingSpinner({ status: false }))
              return bundleDetailSuccess({ response: data });
            })
          )
        })
      )
    }
  )

  bookAppoitment$ = createEffect(
    () => {
      return this.action$.pipe(
        ofType(bookAppointment),
        mergeMap((action) => {
          this.store.dispatch(setLoadingSpinner({ status: true }));
          let payload = {
            scheduleInfo: {
                scheduleCode: action.payload.scheduleCode,
            },
            hlaRequest: {
                bookDate: action.payload.dateOfActivation, // date picker date
                startDate: "", // blank
                typeCode: "",
                centerCode: "", //mandatory if externalSystemId is empty (SO/SA)
                externalSystemId: "", // this is blank at time of create order
                clientLog: "SWP",
                externalSystemCode:  action.payload.externalSystemCode,
                priority: "",
                sourceType: "",
                contactName: "",
                phoneNumber: "",
                emailId: "",
                addressAddress: "",
                building: "",
                street: "",
                town: "",
                country: "",
                postalCode: "",
                longitude: "",
                latitude: "",
                zone: "",
                callUdfInput: "",
                nltRlName: "",
                actionInput: "",
                taskType: "",
                openDate: "",
                requiredDateFrom: "",
                requiredDateTo: "",
                actionudfInput: "",
                slotType: "Normal"
            },
            bookAppointmentRequest: {
                externalSystemId: "",
                timeSlotOption:action.payload.timeSlotOption,
                dateOfActivation:action.payload.dateOfActivation,
                installationTime:action.payload.installationTime,
                profileName: "", // java will bre to get this value send to SWP on load create order API
                sourceType: "",// java will bre to get this value send to SWP on load create order API
                timeZone: ""
            }
        }
          // let payload = {
          //   createUpdateCallActionHla: {
          //     externalSystemCode: action.data.externalSystemCode,
          //     centerCode: 'SO', // coming from our component SO/SA
          //     externalSystemId: '', // system generated unique number based on logic
          //     clientLog: 'SWP',
          //     openDate: new Date().toUTCString(),
          //   },
          //   externalSystemId: '',
          //   dateFrom: action.data.dateFrom,
          //   dateTo: action.data.dateTo,
          //   profileName: 'NLT',
          //   userId: 'SWP',
          //   timeZone: action.data.timeZone
          // }
          return this.orderManagementService.bookAppointment(payload).pipe(
            map((data) => {
              this.store.dispatch(setLoadingSpinner({ status: false }));
              return bookAppointmentSuccess({
                payload: data
              });

            })
          )
        })
      )
    },
  )
  createOrder$ = createEffect(
    () => {
      return this.action$.pipe(
        ofType(orderSubmission),
        mergeMap(({ payload }) => {
          this.store.dispatch(setLoadingSpinner({ status: true }));
          return this.orderManagementService.createOrder(payload).pipe(
            map((data) => {
              this.store.dispatch(setLoadingSpinner({ status: false }));
              // const response: any = {}
              if (data.CreateOrderResponseType) {
                // response.success = true;
                this.toastrService.success('Order Created Successfully');
                this.router.navigate(['home']);
              }
              // return orderSubmissionSuccess({ response });
            })
          )
        })
      )
    }, { dispatch: false }
  )
}



import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CreditCheckState } from '../state/creditCheck.state';

export const CREDIT_CHECK_STATE_NAME = 'credit';
const getCreditCheckState = createFeatureSelector<CreditCheckState>(
  CREDIT_CHECK_STATE_NAME
);
export const getCreditCheck = createSelector(getCreditCheckState, (state) => {
  return state;
});

import { createFeatureSelector, createSelector } from "@ngrx/store";
import { CreateOrder } from "../state/order-management";

export const CREATE_ORDER = 'create order';


// slots

const slots = createFeatureSelector<CreateOrder>(CREATE_ORDER)

export const getAvailableDates = createSelector(slots, (state) => {
    return state.availableDatesWithSlots;
})

export const getSelectedDateWithSlot = createSelector(slots, (state) => {
    return state.selectedDateWithSlot;
})

// bundle name
const bundleNameCharge = createFeatureSelector<CreateOrder>(CREATE_ORDER);
export const getBundleNameWithCharge = createSelector(bundleNameCharge, (state) => {
     return state.serviceOrder.pricingInfo
})
// chaarge Info
const chargeInfo = createFeatureSelector<CreateOrder>(CREATE_ORDER);
export const getchargeInfo = createSelector(chargeInfo, (state) => {
    return state.serviceOrder.pricingInfo;
})

// bookAppointmentStatus
const bookAppointmentStatus = createFeatureSelector<CreateOrder>(CREATE_ORDER);
export const getbookAppointmentStatus = createSelector(bookAppointmentStatus, (state) => {
    return state.bookAppointmentStatus;
})




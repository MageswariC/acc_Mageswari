export interface CustomerEligibilityState {
  customerEligibility: any;
}
export const initialState: CustomerEligibilityState = {
  customerEligibility: {
    osbUID: 'Test1001',
    applicableSchedule: [
      'schedule1',
      'schedule2',
      'schedule3',
      'schedule4',
      'schedule5',
      'schedule6',
      'schedule7',
      'schedule8',
      'schedule9',
      'schedule10',
      'schedule11',
      'schedule12',
      'schedule12A',
      'schedule12B',
      'schedule12C',
      'schedule13',
      'schedule22orCustomizedAgreement97',
    ],
  },
};

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CODetailsState } from '../state/getCODetails.state';

export const GET_CO_DETAILS = 'CODetails';
const getCODetailsState = createFeatureSelector<CODetailsState>(
    GET_CO_DETAILS
);
export const getCODetails = createSelector(getCODetailsState, (state) => {
  return state;
});

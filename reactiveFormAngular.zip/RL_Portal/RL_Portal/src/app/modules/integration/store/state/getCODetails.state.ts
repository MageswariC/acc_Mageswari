export interface CODetailsState {
    CODetails: any;
  }
  export const initialState:CODetailsState  = {
   CODetails:[
        
   
 {
      "user": "swp",
      "operation": "CODetails"
   }



    ]
  };
  

  
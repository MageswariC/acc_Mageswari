import { createFeatureSelector, createSelector } from "@ngrx/store";

export const MANAGEORDER_STATE_NAME = 'manageOrderState';
const manageOrderSelectors = createFeatureSelector<any>("manageOrderState");

export const manageOrderDetails= createSelector(manageOrderSelectors,(state)=>{
    return state.manageOrderDetails;
})
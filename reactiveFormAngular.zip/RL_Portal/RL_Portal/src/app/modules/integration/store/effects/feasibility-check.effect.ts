
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { map, mergeMap } from 'rxjs';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { FeasibilityCheckService } from '../../service/order-management/feasibility-check.service';
import { feasibilityCheck, feasibilityCheckSuccess } from '../actions/feasibility-check.action';
import { FeasibilityResponse } from '../state/feasibility-check.state';
@Injectable({
  providedIn: 'root',
})
export class FeasibilityCheckEffects {
  constructor(private action$: Actions, private store: Store<DynamicComponentState>, private feasibilityCheckService: FeasibilityCheckService) {

  }
  feasibilityCheck$ = createEffect(
    () => {
      return this.action$.pipe(
        ofType(feasibilityCheck),
        mergeMap((action) => {
          this.store.dispatch(setLoadingSpinner({ status: true }));
          return this.feasibilityCheckService.feasibilityCheck(action.payload).pipe(
            map((response:FeasibilityResponse) => {
              this.store.dispatch(setLoadingSpinner({ status: false }))
              return feasibilityCheckSuccess({response});
            })
          )
        })
      )
    }
  )
}
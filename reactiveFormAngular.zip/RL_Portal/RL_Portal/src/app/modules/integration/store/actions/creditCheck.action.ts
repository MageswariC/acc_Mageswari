import { createAction, props } from '@ngrx/store';

export const setCreditCheck = createAction(
  'setCreditCheck',
  props<{ value: any }>()
);
export const getCreditCheck = createAction(
  'getCreditCheck',
  props<{ payload: any }>()
);

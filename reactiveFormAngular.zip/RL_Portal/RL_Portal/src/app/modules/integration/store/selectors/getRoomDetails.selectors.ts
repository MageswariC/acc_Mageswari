import { createFeatureSelector, createSelector } from '@ngrx/store';
//import { CreditCheckState } from '../state/creditCheck.state';
import { RoomDetailsState } from '../state/getRoomDetails.state';

export const GET_ROOM_DETAILS = 'Details';
const getRoomDetailsState = createFeatureSelector<RoomDetailsState>(
    GET_ROOM_DETAILS
);
export const getRoomDetails = createSelector(getRoomDetailsState, (state) => {
  return state;
});

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CustomerEligibilityState } from '../state/customerEligibilty.state';
export const CUSTOMER_ELIGIBILITY_STATE_NAME = 'menu1';
const getCustomerEligibiltyState =
  createFeatureSelector<CustomerEligibilityState>(
    CUSTOMER_ELIGIBILITY_STATE_NAME
  );
export const getcustomerEligibility = createSelector(
  getCustomerEligibiltyState,
  (state) => {
    return state;
  }
);


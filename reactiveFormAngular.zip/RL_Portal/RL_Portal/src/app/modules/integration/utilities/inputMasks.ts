

export const masks={
    phone:"00000000000",
    postalCode:"000000",
    arn:"UU/UU/00A/0000/000",
    ori:"00-00-00000000-00000-U"
} 
import { Injectable } from '@angular/core';
import { ApiBaseService } from '../http/apiBaseService';
import { ApiService } from '../http/apiService';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { FeasibilityResponse } from '../../store/state/feasibility-check.state';

@Injectable({
  providedIn: 'root',
})
export class FeasibilityCheckService {
  sl_senario1 = ['listOfUnits', 'listOfBlocks'];
  // sl_senario2 = [ 'listOfBlocks', 'listOfBlocks'];
  s1_senario3 = [
    'buildingType',
    'feasibilityNote',
    'streetName',
    'buildingName',
    'buildingHouseNo',
    'feasibilityStatus',
  ];
  constructor(
    private apiBaseService: ApiBaseService,
    private apiService: ApiService,
    private store: Store<DynamicComponentState>
  ) {}
  feasibilityCheck(payload: any) {
    return this.apiBaseService.post(
      this.apiService.checkServiceFeasibility,
      payload
    );
  }

 responseSenarioCheck(data: FeasibilityResponse, cb: Function) {
  if(data.feasibilityCode == 'ListOfBlocksAndUnits') return cb('ListOfBlocksAndUnits');

  if(data.feasibilityCode == 'Reclassify' || data.feasibilityCode == 'UnitReached' || data.feasibilityCode == 'ReConnect' || data.feasibilityCode == 'HomeReached') return cb('NoBookAppointment');
  if(data.feasibilityCode == 'FRC') return cb('FRC');
  if(data.feasibilityCode == 'USO') return cb('USO');
  if(data.feasibilityCode == 'Diversion') return cb('Diversion');
  if(data.feasibilityCode == 'BuildingDemolishing') return cb('BuildingDemolishing');
  

  return cb('default');

}

}

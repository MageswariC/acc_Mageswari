import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject, catchError, exhaustMap, filter, Observable, of, switchMap, take, throwError } from 'rxjs';
import { setErrorMessage } from 'src/app/components/integration/store/actions/error-message.action';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';


@Injectable({
    providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
 
    constructor(private store: Store<DynamicComponentState>) {}
    intercept(
      req: HttpRequest<any>,
      next: HttpHandler
    ): Observable<HttpEvent<any>> {
        // let modifiedReq = req.clone({
        //     // params: req.params.append('auth', 'xdfgfdhf'),
        //     setHeaders: { 
        //     'Authorization': sessionStorage.getItem("auth") as string,
        // },
        //   });
        return next.handle(req)
            .pipe(
                catchError((error: HttpErrorResponse) => {
                   
                    if (error.error instanceof ErrorEvent) {
                        console.log('This is client side error');
                    } else {
                        console.log('This is server side error');
                    }
                  
                    let errorMsg:any = {
                        type:'error',
                        title:'API Error',
                        status:error.status,
                        message: error.message
                    };
                  
                    this.store.dispatch(setLoadingSpinner({status:false}))
                    this.store.dispatch(setErrorMessage({message:errorMsg}));
                    // return of(setErrorMessage({message:errorMsg}))
                    return throwError(errorMsg);
                })
            )
   
    }
    
  

  
}
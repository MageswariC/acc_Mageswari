import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiBaseService } from '../http/apiBaseService';
import { ApiService } from '../http/apiService';


@Injectable({
  providedIn: 'root'
})
export class TroubleTicketService {
  

  constructor(private apiBaseService: ApiBaseService, private apiService: ApiService) { }

   getEntryIncidentTicket(payload:any){
    
     return this.apiBaseService.post(this.apiService.getEntryIncidentTicket,payload);
   }
   getEntryChange(payload:any){
    return this.apiBaseService.post(this.apiService.getEntryChange,payload);
   }

   mergeIncidentTicketClose(payload:any){
    return this.apiBaseService.post(this.apiService.mergeEntryIncidentTicket,payload);
   }

   getTicketStatusByORI(payload:any){
    return this.apiBaseService.post(this.apiService.getOrderStatusByORI,payload);
   }
   getServiceOrderDetails(payload:any){
    return this.apiBaseService.post(this.apiService.getServiceOrderDetails,payload);
   }
   createUpdateCallActionHLA(payload: any) {
    return this.apiBaseService.post(this.apiService.createUpdateCallActionHLA, payload);
  }
   createEntryIncidentTicket(payload:any){
    return this.apiBaseService.post(this.apiService.createEntryIncidentTicket,payload);
   }
   
  bookAppointment(payload: any) {
    return this.apiBaseService.post(this.apiService.bookAppointment, payload);
  }
  createGeneralEvent(payload: any) {
    return this.apiBaseService.post(this.apiService.createGeneralEvent, payload);
  }
  getRoomDetails(payload: any){
    return this.apiBaseService.post(
      this.apiService.getRoomDetails,
      payload);
      
  }
   getCODetails(payload: any){
    return this.apiBaseService.post(
      this.apiService.getCODetails,
      payload);
  }

}

import { Injectable } from '@angular/core';
import { ApiBaseService } from '../http/apiBaseService';
import { ApiService } from '../http/apiService';
import { Store } from '@ngrx/store';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class OrderManagementService {
  getRoomDetails(value: any) {
      throw new Error('Method not implemented.');
  }
  getBundleDetail(getBundleDetail: { technology: any; spiltRatio: any; redundancyService: any; commitment: string; }) {
    throw new Error('Method not implemented.');
  }
  constructor(
    private apiBaseService: ApiBaseService,
    private apiService: ApiService
  ) {}
  // availableSlots: any;
  // feasibilityNote = new Subject();
  // selectedDate = new Subject();

  // this.apiBaseService.postAPI(`${environment.bmcURI}arsys/v1/entry/HPD:IncidentInterface_Create?fields=values(Incident Number)`,this.payload ).subscribe(data=>{
  //   console.log("%c API Response", 'background-color:yellow', data);
  // })
  // }
  requestingLicensee = {
    name: 'RL User',
    companyName: 'Singtel',
    designation: 'System Engineer',
    companyPhoneNumber: '63297537',
    companyFaxNumber: '63297537',
    companyEmail: 'rluser@singtel.com',
  };
  getTimeSlotsList(timeSlotsList: any) {
    var slots: any = {};
    timeSlotsList.forEach((slot: any) => {
      var [sdate, stime] = slot.dateFrom.split('T');
      var [edate, etime] = slot.dateTo.split('T');
      let [shours] = stime.split(':');
      let [ehours] = etime.split(':');
      if (slots[sdate]) {
        slots[sdate].push({ hours: `${shours}-${ehours}`, slot });
      } else {
        slots[sdate] = [{ hours: `${shours}-${ehours}`, slot }];
      }
    });
    console.log("slots", slots)
    return slots;
  }
  getPromoCode(payload: any) {
    return this.apiBaseService.post(this.apiService.getPromoCode, payload);
  }
  getTieCableCheck(payload: any) {
    return this.apiBaseService.post(this.apiService.tieCableCheck, payload);
  }
  createUpdateCallActionHLA(payload: any) {
    return this.apiBaseService.post(
      this.apiService.createUpdateCallActionHLA,
      payload
    );
  }
  bookAppointment(payload: any) {
    return this.apiBaseService.post(this.apiService.bookAppointment, payload);
  }
  createOrder(payload: any) {
    return this.apiBaseService.post(this.apiService.orderSubmission, payload);
  }
  retriveSlots(payload: any) {
    return this.apiBaseService.post(
      this.apiService.retrieveSoltsForAppointment,
      payload
    );
  }
  getFromThisDateForward() {}
  getBundleNameWithPriceDetails(payload: any) {
    return this.apiBaseService.post(this.apiService.getBundleNameWithPriceDetails, payload);
  }
  opGetChargeInfo(payload: any) {
    return this.apiBaseService.post(this.apiService.opGetChargeInfo, payload);
  }
  generateORI(payload: any) {
    return this.apiBaseService.post(this.apiService.generateORI, payload);
  }
  getPromoCodeDetails(payload: any) {
    return this.apiBaseService.post(
      this.apiService.getPromoCodeDetails,
      payload
    );
  }
  createGeneralEvent(payload: any) {
    return this.apiBaseService.post(
      this.apiService.createGeneralEvent,
      payload
    );
  }
  getHolidayEventByYear(payload: any) {
    return this.apiBaseService.post(
      this.apiService.getHolidayEventByYear,
      payload
    );
  }
  profileName(sheduleno: any, slotType: any, buildingType?: any) {
    if ((sheduleno == '1' || sheduleno == '8') &&
      slotType == 'Normal' &&
      buildingType == 'Landed'
    )
      return 'SONORM1_8_LAND';
    else if ((sheduleno == '1' || sheduleno == '8') && slotType == 'Seasonal')
      return 'SOSEAS1_8';
    else if ((sheduleno == '1' || sheduleno == '8') && slotType == 'Normal')
      return 'SONORM1_8';
    return '';
  }
  externalSystemCode(centerCode: any) {
    if (centerCode == 'SA') return 'HLX';
    if (centerCode == 'SO') return 'SOM';
    return '';
  }
  getServiceOrderDetails(payload: any) {
    return this.apiBaseService.post(
      this.apiService.getServiceOrderDetails,
      payload
    );
  }
  getOrderStatusByORI(payload: any) {
    return this.apiBaseService.post(
      this.apiService.getOrderStatusByORI,
      payload
    );
  }
  
  // getCreditCheck(payload: any) {
  //   return this.apiBaseService.post(this.apiService.getCreditCheck, payload);
  // }
  // getcustomerEligibility(payload: any) {
  //   return this.apiBaseService.post(
  //     this.apiService.getcustomerEligibility,
  //     payload
  //   );
  // }
}

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  downloadFile = 'http://10.6.2.6:7002/DMS/RestService';
  checkServiceFeasibility = 'http://localhost:8086/api/checkServiceFeasibility';
  // checkServiceFeasibility = 'http://localhost:7000/api/getFeasibilty';
  // getPromoCode = 'http://localhost:8086/api/getPromoCode';
  getPromoCode = 'http://localhost:7000/api/loadCreateOrder';
  bookAppointment = 'http://localhost:8086/api/bookAppointment';
  tieCableCheck = 'http://localhost:8086/api/getTieCable';
  retrieveSoltsForAppointment =
    'http://localhost:8086/swp/vxfield/retrieveslotsforappointment';
  getEntryIncidentTicket = 'http://localhost:8086/api/getEntryIncidentTicket';
  getEntryChange = 'http://localhost:8086/api/getEntryChange';
  mergeEntryIncidentTicket =
    'http://localhost:8086/api/mergeEntryIncidentTicketClose';
  getOrderStatusByORI = 'http://localhost:8086/api/getOrderSatusByORI';
  getServiceOrderDetails = 'http://localhost:8086/api/getServiceOrderDetails';
  createEntryIncidentTicket =
    'http://localhost:8086/api/createEntryIncidentTicket';
  createUpdateCallActionHLA =
    'http://localhost:8086/api/createUpdateCallActionHLA';
  orderSubmission = 'http://localhost:8086/api/orderSubmission';
  getBundleNameWithPriceDetails = 'http://localhost:8086/api/getBundleNameWithPriceDetails';
  opGetChargeInfo = 'http://localhost:8086/api/opGetChargeInfo';
  generateORI = 'http://localhost:8086/order/swp/generateori';
  getPromoCodeDetails = 'http://localhost:8086/api/getPromoCodeDetails';
  createGeneralEvent = 'http://localhost:8086/api/createGeneralEvent';
  getHolidayEventByYear = 'http://localhost:8086/api/getHolidayEventByYear';
  getCreditCheck = 'http://localhost:8086/api/getCreditCheck';
  getcustomerEligibility = 'http://localhost:8086/getcustomerEligibility';
  getRoomDetails = 'http://localhost:8086/api/getRoomDetails';
  getCODetails = 'http://localhost:8086/api/getCODetails';

  constructor() {}
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import  manageUserFormData from '../../integration/form-data/user-management/manage-user-forData';
import { CreateUser } from '../../integration/interface/forms/user-management/create-user';
import { manageUser } from '../../integration/modal/user-management/manage-user.modal';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.scss']
})
export class ManageUserComponent implements OnInit {

  manageUserForm!: FormGroup;
  manageUser:CreateUser = {...manageUser};


    //form builder input
    formData: any;
    getFormControl: any;
    manageUserModel = manageUser;

    formSubmitted = false;
    constructor(private fb: FormBuilder, private toastrService: ToastrService, private router: Router, private formBuilder: FormBuilder) { }
  
    ngOnInit(): void {
    
      this.formData = manageUserFormData;
      this.manageUserForm = this.fb.group({})
    }
    getForm(form: FormGroup) {
      this.getFormControl = form.controls;
    }
    
    fcFormValue(fcForm: FormGroup) {
      
    }
    getFormVal(val: any) {
      this.router.navigate(['swp/home']);
      this.toastrService.success('Your request has been submitted successfully', '');
    }

}

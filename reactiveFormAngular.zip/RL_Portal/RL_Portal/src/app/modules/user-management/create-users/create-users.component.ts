
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import  createUserFormData from '../../integration/form-data/user-management/create-user-formData';
import { CreateUser } from '../../integration/interface/forms/user-management/create-user';
import { createUser } from '../../integration/modal/user-management/craete-user.modal';

@Component({
  selector: 'app-create-users',
  templateUrl: './create-users.component.html',
  styleUrls: ['./create-users.component.scss']
}) 
export class CreateUsersComponent implements OnInit {

  createUserForm!: FormGroup;
  createUser:CreateUser = {...createUser};


    //form builder input
    formData: any;
    getFormControl: any;
    createUserModel = createUser;

    formSubmitted = false;
    constructor(private fb: FormBuilder, private toastrService: ToastrService, private router: Router, private formBuilder: FormBuilder) { }
  
    ngOnInit(): void {
    
      this.formData = createUserFormData;
      this.createUserForm = this.fb.group({})
    }
    getForm(form: FormGroup) {
      this.getFormControl = form.controls;
    }
    
    fcFormValue(fcForm: FormGroup) {
      
    }
    getFormVal(val: any) {
      this.router.navigate(['swp/home']);
      this.toastrService.success('Your request has been submitted successfully', '');
    }
}


import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-configuration',
  templateUrl: './role-configuration.component.html',
  styleUrls: ['./role-configuration.component.scss']
})
export class RoleConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

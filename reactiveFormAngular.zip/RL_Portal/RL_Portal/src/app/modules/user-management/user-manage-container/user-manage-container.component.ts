import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-manage-container',
  templateUrl: './user-manage-container.component.html',
  styleUrls: ['./user-manage-container.component.scss']
})
export class UserManageContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserManageContainerComponent } from './user-manage-container.component';

describe('UserManageContainerComponent', () => {
  let component: UserManageContainerComponent;
  let fixture: ComponentFixture<UserManageContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserManageContainerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserManageContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

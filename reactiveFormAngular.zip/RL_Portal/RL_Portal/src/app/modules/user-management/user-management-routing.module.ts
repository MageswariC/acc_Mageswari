import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateUsersComponent } from './create-users/create-users.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { RoleConfigurationComponent } from './role-configuration/role-configuration.component';
import { UserManageContainerComponent } from './user-manage-container/user-manage-container.component';
import { UserManagementComponent } from './user-management.component';
import { UsersListComponent } from './users-list/users-list.component';



const routes: Routes = [
  {
    path: '', component: UserManagementComponent, children: [
      {
        path: 'user-management/create-users',
        component: CreateUsersComponent,
        data: { breadcrumb: ['User-Management', 'Create-Users'] }
      },
      {
        path: 'user-management/manage-users',
        component: ManageUserComponent,
        data: { breadcrumb: ['User-Management', 'Manage-Users'] }
      },
      {
        path: 'user-management/role-configuration',
        component: RoleConfigurationComponent,
        data: { breadcrumb: ['User-Management', 'Role-Configuration'] }
      },
      {
        path: 'user-management/user-manage-container',
        component: UserManageContainerComponent,
        data: { breadcrumb: ['User-Management', 'User-Manage-Container'] }
      },
      {
        path: 'user-management/user-list',
        component: UsersListComponent,
        data: { breadcrumb: ['User-Management', 'User-List'] }
      },
    


    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserManagementRoutingModule { }

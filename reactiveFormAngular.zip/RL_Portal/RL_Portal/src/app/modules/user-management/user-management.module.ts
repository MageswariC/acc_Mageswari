import { NgModule } from '@angular/core';
import { DynamicComponentModule } from 'src/app/components/dynamic-components/dynamic-component.module';
import { CreateUsersComponent } from './create-users/create-users.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { RoleConfigurationComponent } from './role-configuration/role-configuration.component';
import { UserManageContainerComponent } from './user-manage-container/user-manage-container.component';
import { UserManagementRoutingModule } from './user-management-routing.module';
import { UserManagementComponent } from './user-management.component';
import { UsersListComponent } from './users-list/users-list.component';

@NgModule({
  declarations: [
    UsersListComponent,
    UserManagementComponent,
    UserManageContainerComponent,
    RoleConfigurationComponent,
    ManageUserComponent,
    CreateUsersComponent 

    
  ],
  imports: [
    UserManagementRoutingModule,
    DynamicComponentModule
  ]
})
export class UserManagementModule { }

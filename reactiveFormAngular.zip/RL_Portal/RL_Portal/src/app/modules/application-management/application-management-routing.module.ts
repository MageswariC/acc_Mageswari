import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationManagementComponent } from './application-management.component';

const routes: Routes = [
  {
    path: '',
    component: ApplicationManagementComponent,
    children: [
      // {
      //   path: 'swp/app-management/CR-70',
      //   component: Cr70Component,
      //   // canDeactivate:[CanDeactivateGuard],
      //   data: {
      //     breadcrumb: ['Application Management', 'CR70'],
      //   },
      // },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ApplicationManagementRoutingModule {}

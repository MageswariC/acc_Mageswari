import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { ApplicationManagementRoutingModule } from './application-management-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DynamicComponentModule } from 'src/app/components/dynamic-components/dynamic-component.module';
@NgModule({
  //declarations: [Cr70Component, Cr70TableComponent],
  imports: [
    CommonModule,
    ApplicationManagementRoutingModule,
    NgbModule,
    ReactiveFormsModule,
    FormsModule,
    DynamicComponentModule,
  ],
})
export class ApplicationManagementModule {}

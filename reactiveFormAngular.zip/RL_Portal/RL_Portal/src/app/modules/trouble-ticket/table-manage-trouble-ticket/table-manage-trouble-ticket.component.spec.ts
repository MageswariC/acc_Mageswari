import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableManageTroubleTicketComponent } from './table-manage-trouble-ticket.component';

describe('TableManageTroubleTicketComponent', () => {
  let component: TableManageTroubleTicketComponent;
  let fixture: ComponentFixture<TableManageTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableManageTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableManageTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketCreationDetailsComponent } from './ticket-creation-details.component';

describe('TicketCreationDetailsComponent', () => {
  let component: TicketCreationDetailsComponent;
  let fixture: ComponentFixture<TicketCreationDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TicketCreationDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TicketCreationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

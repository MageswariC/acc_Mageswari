import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  ViewChild,
  OnChanges,
  SimpleChanges,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

import { FormData } from '../../../components/integration/interface/form-builder';
 interface Player {
  id: number;
  name: string;
}

@Component({
  selector: 'ticket-creation-details',
  templateUrl: './ticket-creation-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./ticket-creation-details.component.scss']
})
export class TicketCreationDetailsComponent implements OnInit  {
  ticketDetailsData:any;

  @Input()
  set ticketDetails(value: FormData) {
    this.ticketDetailsData = value;
    this.addHandler(value);
  }
  // @Input() ticketDetails!: FormData;
  @Input() parent: any;
  @Output() ticketCreation = new EventEmitter();
  @Output() oriDetails = new EventEmitter();
  

  public ticketCreationForm!: FormGroup;
  constructor(private fb: FormBuilder, private changeDetectorRef:ChangeDetectorRef,) { }

  ngOnInit(): void {
    this.addHandler(this.ticketDetailsData);
  }


  addHandler(td: any) {
    this.ticketCreationForm = this.fb.group({});
    if (td && td.controls) {
      td.controls.forEach((ele: any) => {
        ele.options.children.forEach((e: any) => {
          if (!e.handler) e.handler = () => { };
        })
      })
      this.createForm(td.controls);
   }
    

  }

  createForm(controls: FormData['controls']) {
  
    for (const control of controls) {
      const newGroup = new FormGroup({});
      control?.options.children.map((child: any) => {
        const newControl = new FormControl();
        const validatorsToAdd = child?.validators(Validators);
        newControl.setValidators(validatorsToAdd);
        // if(child.defaultValue)newControl.setValue(child.defaultValue);
        newGroup.addControl(child.key, newControl);
        this.ticketCreationForm.addControl(child.key, newControl);
      });
    }
    this.ticketCreation.emit(this.ticketCreationForm);
  }
  onSubmit() {
    console.log('--in clcik--', this.ticketCreationForm.value);
    this.oriDetails.emit(this.ticketCreationForm.value);
  }
  checkErrors(f: FormGroup, fg: any, fc: any) {
    if (f.controls && f.controls[fc]?.touched) {
      if (f.controls[fc].errors) {
        const error = Object.keys(f.controls[fc].errors || {})[0];
        return error;
      }
    }
    return null;
  }

}

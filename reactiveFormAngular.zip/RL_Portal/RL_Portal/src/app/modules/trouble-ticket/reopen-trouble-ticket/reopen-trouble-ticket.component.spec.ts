import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReopenTroubleTicketComponent } from './reopen-trouble-ticket.component';

describe('ReopenTroubleTicketComponent', () => {
  let component: ReopenTroubleTicketComponent;
  let fixture: ComponentFixture<ReopenTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReopenTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReopenTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

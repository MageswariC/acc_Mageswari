import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import { Observable, Subscription } from 'rxjs';
import reopenTroubleTicket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/reopen-trouble-ticket';
// import { AllShedule } from 'src/app/modules/integration/interface/forms/order-management/all-shedule';
import { reopenTroubleTicketModal } from 'src/app/modules/integration/modal/trouble-ticket/reopen-trouble-ticket.modal';
import reopenTroubleTicketJoint from '../../integration/form-data/trouble-ticket/manage trouble ticket/reopen-trouble-ticket-joint-investigation';
import { getEntryIncidentTicketSelector } from '../../integration/store/selectors/trouble-ticket.selectors';
import { Store } from '@ngrx/store';
import { OrderManagementService } from '../../integration/service/order-management/order-management.service';
import { TroubleTicketService } from '../../integration/service/trouble-ticket/trouble-ticket.service';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
// import { createUpdateCallHLA, timeSlotsLists } from '../../integration/store/actions/residential-connection-create-order';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-reopen-trouble-ticket',
  templateUrl: './reopen-trouble-ticket.component.html',
  styleUrls: ['./reopen-trouble-ticket.component.scss']
})
export class ReopenTroubleTicketComponent implements OnInit {
  formData: any;
  formValue:any;
  modifyValue!:any;
  reOpenTTmodal: any;
  incidentType:any;
  ticketData:any;
 modalTitle:any;
modalBody:any;
modalVisibilty=false;
modalOkFunction:any=null;

isCancelRequired=false;

formValues:any;
  selectedDate: any;
  getFormControl:any;
  selectedSlot: any;
  isAppointmentBooked=false;
  constructor(private router: Router, private formService:FormService, private store:Store,private orderManagementService: OrderManagementService,private troubleTicketService:TroubleTicketService, private toastrService: ToastrService) { }

  getForm(form: any) {
    this.getFormControl = form.controls;
    console.log(this.getFormControl);
    
  }
  ngOnInit(): void {
    // this.orderManagementService.selectedDate.subscribe((date: any) => {
    //   if (date) {
    //     this.selectedDate = date;
    //     this.formData?.controls?.forEach((section: any) => {
    //       if (section.id == 'ticketAppointment') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'appointmentSlot') {
    //             control.option = date.map((val: any) => {
    //               return val.hours
    //             });
    //           }
    //         });
    //       }
    //     });
    //    this.reverseAptBtnEnablementCheck()
    //   }
    // })

    // this.incidentType=data.getENtryIncidentTicketResponse.ticketDetails.incidentID;
    this.formValue =  this.formService.getManageOrderData();
  //  this.reOpenTTmodal = reopenTroubleTicketModal;
    console.log("modify form data", this.formValue);
    this.modifyValue = this.formValue;
    this.store.select(getEntryIncidentTicketSelector).subscribe((data)=>{
    console.log("Mosal",data);
    this.ticketData=data;

    this.incidentType =  data.ticketDetails.incidentType;

    if(this.incidentType=='Joint Investigation Fault')

    {

      this.formData=reopenTroubleTicketJoint;
      let payload: any = {
        timeSlotOption: 'Normal',
      };
      this.orderManagementService
      .retriveSlots(payload)
      .subscribe((val: any) => {
        if (val.timeSlotsList) {
          this.orderManagementService.getTimeSlotsList(val.timeSlotsList);
        }
        // let slots = this.orderManagementService.availableSlots;
        if (val.status == 0) {
          console.log(this.formData);
          this.formData?.controls?.forEach((section: any) => {
            console.log(section);
            if (section.id == 'ticketAppointment') {
              console.log('Came In');
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'appointmentDate') {
                  // let date = Object.keys(slots);
                  // control.dateFrom = [date[0]];
                  // control.dateTo = [date[date.length - 1]];
                }
              });
            }
          });
        }
      });

      this.reOpenTTmodal ={
        ticketDetails : {
          incidentID : data.ticketDetails.incidentID,
          reason: 'Needed further processing,Joint Investigation'},
          ticketAppointment : {
          appointmentDate : data.ticketAppointment.appointmentDate,
          appointmentSlot : data.ticketAppointment.appointmentSlot
        },
      }

    }

    else{
      this.formData = reopenTroubleTicket;
      this.reOpenTTmodal ={
       ticketDetails : {
          incidentID : data.ticketDetails.incidentID,
          reason: 'Needed further processing.'},
      }
    }
    console.log("Data Modal",this.reOpenTTmodal);
  })

  }
  onSubmit(form:any){
   console.log("Sujdk",form);
   this.formValues=form;
   let successMsg: any = {
    title: `Confirm Reopen`,
    body: `Do you want to reopen this ticket?`,
    okFunction:"mergeEntryTicket",
    cancelButton:true
  };
  
 this.setModal(successMsg);
   
  }
  mergeEntryIncidentTicket(){
    let payload:any={
     rlInfo: {
        rlName: "",
        qpId: "",
        rlId: "",
        companyName: "",
        designation: "",
        faxNo: "",
        emailId: "",
        contactInfo: {
          code: "+65",
          contactNo: ""
        },
        ticketCreationDetails: this.ticketData.ticketDetails,
        serviceOrderDetail: this.ticketData.serviceOrderDetails,
        ticketDetails:{...this.ticketData.ticketDetails,submissionType:"REOPEN"},
        endUserContactDetails:this.ticketData.endUserPremisesContactDetails,
        secondaryRlDetails:this.ticketData.secondaryRequestingLisensee,
        ticketAppointment:this.formValues.ticketAppointment
    }
  }
    this.troubleTicketService.mergeIncidentTicketClose(payload).subscribe((data)=>{
      console.log("Returned from service" ,data);

      
      if(data.status==="Pass"){
        let successMsg: any = {
          title: `Reopen Incident ticket Succcess`,
          body: `Incident was reopened successfully`,
          okFunction:"routeHome"
        };
       this.setModal(successMsg);
      }
      else{
        let errorMsg: any = {
          title: `SWP-018 Close Incident Ticket Failure`,
          body: `There is a techncial Error occurred, Please try later to perfrom your activities. `
          ,okFunction:null
        };
       
        this.setModal(errorMsg);
        
      }
      
    })

    console.log("From Merge" ,payload);
  }
  setModal(modalData:any){
    this.modalBody=modalData.body;
    this.modalTitle=modalData.title;
    this.modalVisibilty=true;
    this.modalOkFunction=modalData.okFunction;
    this.isCancelRequired=modalData.cancelButton;
   }

   modalCancel(){
    this.modalVisibilty=false;
   }

   routeHome(){
    this.router.navigate(['/home']);
  }
  modalConfirm(func:any){
    if(func==="mergeEntryTicket"){
      this.mergeEntryIncidentTicket();
    }
    if(func==="routeHome"){
      this.routeHome();
    }
    this.modalVisibilty=false;
    this.modalOkFunction=null;
  }
  installationTimeChange(obj: any) {
    console.log("CLan");

    this.reverseAptBtnEnablementCheck();
  }
  reverseAppointment(obj: any) {
    this.store.dispatch(setLoadingSpinner({ status: true }));
    let timeSlotType = "Normal";
    let installationTime = this.getFormControl.ticketAppointment.get('appointmentSlot').value;
    if (this.selectedDate) {
      this.selectedSlot = this.selectedDate.find((val: any) => {
        return val.hours == installationTime
      })?.slot
    }
    let createUpdateCallActionHla = {
      addressAddress: "",
      requiredDateFrom: this.selectedSlot.dateFrom,
      requiredDateTo: this.selectedSlot.dateTo,
      slotType: timeSlotType,
    }
    // this.store.dispatch(createUpdateCallHLA({ payload: createUpdateCallActionHla }));
    let timeSlotsList = {
      dateFrom: this.selectedSlot.dateFrom,
      dateTo: this.selectedSlot.dateTo,
    }
    // this.store.dispatch(timeSlotsLists({ payload: timeSlotsList }))
    //this.store.dispatch(timeSlotsLists({ payload: timeSlotsList }))

    this.troubleTicketService.createUpdateCallActionHLA(createUpdateCallActionHla).subscribe((data) => {
      let createUpdateCallActionHLAstatus = data.status;
      if (createUpdateCallActionHLAstatus && createUpdateCallActionHLAstatus == 0) {
        console.log("status of createUpdateCallActionHLA>>>", createUpdateCallActionHLAstatus)
        let bookAppointment = {
          taskId: data.taskId,
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          profileName: 'NLT',
          userId: 'SWP',
          timeZone: 'CTT'
        }
        this.troubleTicketService.bookAppointment(bookAppointment).subscribe((data) => {
          this.store.dispatch(setLoadingSpinner({ status: false }));
          let bookAppointmentStatus = data.status;
          if (bookAppointmentStatus && bookAppointmentStatus == 0) {
            console.log("status of bookAppointment>>>", bookAppointmentStatus);
            this.isAppointmentBooked=true;
            this.formData?.controls?.forEach((section: any) => {
              if (section.id == 'ticketAppointment') {
                section?.options?.children.forEach((control: any) => {
                  if (control.key == 'reserveAppoinment') {
                    control.readOnly = true;
                  }
                });
              }
            })
            this.toastrService.success('Appointment Booked Successfully');
            this.getFormControl.ticketAppointment.disable();
          } else if (bookAppointmentStatus) {
            this.handleWFMStatus(bookAppointmentStatus)
          }
        })
      } else if (createUpdateCallActionHLAstatus) {
        this.handleWFMStatus(createUpdateCallActionHLAstatus)
      }
    }
    )
  }
  handleWFMStatus(status: any) {
    // handle WFM status expect status:0
    console.log(status)
  }
  reverseAptBtnEnablementCheck() {
    console.log("CLa");
    
    let appointmentSlot = this.getFormControl?.ticketAppointment?.get("appointmentSlot").value;
    let dateOfAppointment = this.getFormControl?.ticketAppointment?.get("appointmentDate").value;

    console.log(this.getFormControl);
    
    this.formData?.controls?.forEach((section: any) => {
      if (section.id == 'ticketAppointment') {
        section?.options?.children.forEach((control: any) => {
          if (control.key == 'reserveAppoinment') {
            (appointmentSlot && dateOfAppointment) ? control.readOnly = false : control.readOnly = true;
          }
        });
      }
    })
  }
  cancelAppoinment(){

    this.store.dispatch(setLoadingSpinner({ status: true }));
    let payload = {
      taskId: '',
      dateFrom: this.selectedSlot?.dateFrom,
      dateTo: this.selectedSlot?.dateTo,
      userId: "SWP",
    }
    this.troubleTicketService.createGeneralEvent(payload).subscribe(data => {
      this.store.dispatch(setLoadingSpinner({ status: false }));
      if (data.status == 0) {
        this.toastrService.success('Appoinment Cancelled');
        this.router.navigate(['home']);
      }
    })
  
  }
    onCancel(){
      
      if(this.incidentType="Joint investigation"&&this.isAppointmentBooked){
        this.cancelAppoinment();  
      }
      
    }

  
}

import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { ApiBaseService } from 'src/app/modules/integration/service/http/apiBaseService';
import { ApiService } from 'src/app/modules/integration/service/http/apiService';
import ticketDetails from '../../../integration/form-data/feasibility-check/trouble-ticket-creation/ticket-creation';
import { clone } from '../../../../components/utilities/util';
import onehr_fibreProvision_fibreMain_main from '../../../integration/form-data/trouble-ticket/create/onehr_fibreProvision_fibreMain';
import { createTroubleTicketModal } from 'src/app/modules/integration/modal/trouble-ticket/create-trouble-ticket.model';
import residentialEndUserConnectionForm from '../../../integration/form-data/order-management/create-order/residential-end-user-connection-formData';
import joint_investigation from 'src/app/modules/integration/form-data/trouble-ticket/create/joint_investigation';
import co_loc_fault from 'src/app/modules/integration/form-data/trouble-ticket/create/co-loc_fault';
import fiberMonitor_OssBss_fault from 'src/app/modules/integration/form-data/trouble-ticket/create/fiberMonitor_ossBss_fault';
import { BehaviorSubject, Observable, combineLatest, map, from } from 'rxjs';
import { getEntryIncidentTicketSelector } from 'src/app/modules/integration/store/selectors/trouble-ticket.selectors';
import { getEntryIncidentTicket } from 'src/app/modules/integration/store/actions/trouble-ticket.action';
import { setErrorMessage } from 'src/app/components/integration/store/actions/error-message.action';
import { TroubleTicketService } from 'src/app/modules/integration/service/trouble-ticket/trouble-ticket.service';
import createTroubleTicketFormData from 'src/app/modules/integration/form-data/trouble-ticket/create/create-trouble-ticket-formData';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { setRoomDetails } from 'src/app/modules/integration/store/actions/getRoomDetails.action';
import { getRoomDetails } from 'src/app/modules/integration/store/selectors/getRoomDetails.selectors';
import { setCODetails } from 'src/app/modules/integration/store/actions/getCODetails.action';
import { getCODetails } from 'src/app/modules/integration/store/selectors/getCODetails.selectors';

// import { createUpdateCallHLA, timeSlotsLists } from 'src/app/modules/integration/store/actions/residential-connection-create-order';
@Component({
  selector: 'app-create-trouble-ticket',

  templateUrl: './create-trouble-ticket.component.html',
  styleUrls: ['./create-trouble-ticket.component.scss'],
})
export class CreateTroubleTicketComponent implements OnInit {
  troubleTicketCreation!: FormGroup;
  getORIDetailsDone: Boolean = false;
  getTicketDetailControl: any;
  // modalOkFunction: any = null;

  //get ORI details
  fcInput: any;
  incidentType: any;
  opCoIndidentId: any;
  // ori: any;
  ticketCreated: boolean = false;

  //modalObj
  modalVisibilty = false;
  modalObj = {
    modalTitle: '',
    modalBody: '',
    cancelRequired: false,
    modalOkFunction: null
  }

  //form builder input
  formData: any;
  getFormControl: any;
  troubleTicketModal: any;

  //create
  ticketCreationDetails: any;
  serviceOrderDetails: any;


  //orderFormValue: any ;
  //ticketSummary1 = ["TP No Signal", "No Light Source", "High Loss", "Patching Issue"];
  //ticketSummary2 = ["Colo Tie Fibre Fault", "Rack high temperature", "Loss of Electrical Power to Rack", "Others"];
  orderFormValue: any = null;
  ticketSummary1 = [
    'TP No Signal',
    'No Light Source',
    'High Loss',
    'Patching Issue',
  ];
  ticketSummary2 = [
    'Colo Tie Fibre Fault',
    'Rack high temperature',
    'Loss of Electrical Power to Rack',
    'Others',
  ];
  installationAddress: any;
  isAppointmentBooked = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastrService: ToastrService,
    private store: Store,
    private troubleTicketService: TroubleTicketService,
    private orderManagementService: OrderManagementService
  ) { }

  ngOnInit(): void {
    this.fcInput = ticketDetails.onehrActivation;
    this.troubleTicketCreation = this.fb.group({})

  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }

  getFormVal(val: any) {
    this.orderFormValue = val;
    //console.log("---in get value--",val.value)
    this.router.navigate(['swp/home']);
    this.toastrService.success(
      'The request for the connection has been submitted successfully ORI Details: 02-01-07012022-45671-A',
      ''
    );
  }
  getORIdetails(obj: any) {
    this.ticketCreationDetails = obj;
    this.getORIDetailsDone = true;

    this.formData = clone(createTroubleTicketFormData);
    if (this.incidentType !== 'Joint investigation') {
      this.formData.controls = this.formData?.controls?.filter(
        (section: any) => section.id != 'ticketAppointment'
      );
    } 



    // this.checkOrderStatusByOri(obj);
  }

  getTicketCreationControl(event: any) {
    this.getTicketDetailControl = event;
    if (this.incidentType)
      event.controls.incidentType.patchValue(this.incidentType);
    if (this.opCoIndidentId)
      event.controls.opCoIndidentId.patchValue(this.opCoIndidentId);
    // if (this.ori) event.controls.ori.patchValue(this.ori);
  }

  changeIncidentType(obj: any) {
    this.getORIDetailsDone = false;
    this.incidentType = obj.event.currentTarget.value;
    if (this.getTicketDetailControl.controls.opCoIndidentId.value) this.opCoIndidentId = this.getTicketDetailControl.controls.opCoIndidentId.value;
    // if (this.getTicketDetailControl.controls.ori.value) this.ori = this.getTicketDetailControl.controls.ori.value;
    if (this.incidentType == 'Joint investigation') this.fcInput = clone(ticketDetails.jointInvestigation);
    else if (this.incidentType == 'CO-LOC Fault') this.fcInput = clone(ticketDetails.CO_LOC_Fault);
    else if (this.incidentType == 'Fibre monitoring') this.fcInput = clone(ticketDetails.fibreMonitoring);
    else if (this.incidentType == 'OSS/BSS Fault') {
      this.fcInput = clone(ticketDetails.ossBssFault);
    }
    else if (this.incidentType == '1 hour activation') this.fcInput = clone(ticketDetails.onehrActivation);
    else if (this.incidentType == 'Fibre provisioning') this.fcInput = clone(ticketDetails.fibreProvisioning);
    else if (this.incidentType == 'Fibre maintenance') this.fcInput = clone(ticketDetails.fibreMaintainence);
  }

  onSubmit(data: any) {
    console.log("data", data)
  }

  onCancel() {

  }
  modalCancel() {

  }
  setActiveOpenTicketError(data: any) {
    let errorMsg: any = {
      title: 'SA-ERR-017 Active Open Ticket',
      body: 'There is an open Ticket raised already for this ORI. Please user Manage Ticket to check the latest status of the open ticket',
    };
    this.setModal(errorMsg);
    this.ticketCreated = true;
  }
  setMaintanenceMessage(data: any) {
    let errorMsg: any = {
      title: `SWP-019 Planned Maintenance Message`,
      body: `There is a Planned Maintenance activity in your location. Your ticket may take longer time to resolve.`,
    };
    this.setModal(errorMsg);
  }
  setServiceNotCompletedError() {
    let errorMsg: any = {
      title: 'SWP-061 Order not Completed',
      body: 'Order status is not completed. User cannot proceed with ticket creation.',
    };
    this.setModal(errorMsg);
    // this.isOrderCompleted = false;
  }
  setCreateIncidentTicketSuccess(data: any) {
    let successMsg: any = {
      title: `Incident Ticket Created Successfully`,
      body: `Incident ticket created successfully with id ${data.incidentId} `,
      okFunction: 'routeHome',
    };
    this.setModal(successMsg);
  }
  setCreateIncidentTicketFailure() {
    let successMsg: any = {
      title: 'SA-ERR-018 SA Ticket Creation Error',
      body: `There is a techncial Error occurred, Please try later to perfrom your activities. `,
    };
    this.setModal(successMsg);
  }

  setModal(modalData: any) {
    this.modalObj.modalBody = modalData.body;
    this.modalObj.modalTitle = modalData.title;
    this.modalVisibilty = true;
    this.modalObj.modalOkFunction = modalData.okFunction;
  }
  modalConfirm(func: any) {
    if (func) {
      if (func === 'routeHome') {
        this.routeHome();
      }
    }
    this.modalVisibilty = false;
    this.modalObj.modalOkFunction = null;
  }

  routeHome() {
    this.router.navigate(['/home']);
  }



}

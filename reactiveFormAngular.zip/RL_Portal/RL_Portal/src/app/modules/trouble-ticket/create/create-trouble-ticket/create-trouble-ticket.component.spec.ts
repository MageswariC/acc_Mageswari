import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTroubleTicketComponent } from './create-trouble-ticket.component';

describe('CreateTroubleTicketComponent', () => {
  let component: CreateTroubleTicketComponent;
  let fixture: ComponentFixture<CreateTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

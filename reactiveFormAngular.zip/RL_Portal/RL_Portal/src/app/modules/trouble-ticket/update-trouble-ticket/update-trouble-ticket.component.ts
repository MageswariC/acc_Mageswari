import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import manage_ticket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/update-trouble-ticket';
import residentialEndUserConnectionForm from 'src/app/modules/integration/form-data/order-management/manage-order/modify-order/residential-end-user-connection-formData';
import manageTP from 'src/app/modules/integration/form-data/order-management/manage-order/manage-tp/manage-tp-formData';
import { updateTroubleTicketModal } from 'src/app/modules/integration/modal/trouble-ticket/update-trouble-ticket.model';
import { Store } from '@ngrx/store';
import { getEntryIncidentTicketSelector } from '../../integration/store/selectors/trouble-ticket.selectors';
import { OrderManagementService } from '../../integration/service/order-management/order-management.service';
import { TroubleTicketService } from '../../integration/service/trouble-ticket/trouble-ticket.service';



@Component({
  selector: 'app-update-trouble-ticket',
  templateUrl: './update-trouble-ticket.component.html',
  styleUrls: ['./update-trouble-ticket.component.scss']
})
export class UpdateTroubleTicketComponent implements OnInit {

checkFeasibility: any;
formData: any;
formValue:any;
modifyValue!:any;
manageTPValue:any;
incidentType:any;
modalTitle:any;
modalBody:any;
modalVisibilty=false;
modalOkFunction:any=null;
ticketData:any
isCancelRequired=false;

formValues:any;
  constructor(private router: Router,private toastrService: ToastrService, private formService:FormService,private store:Store,private orderManagementService: OrderManagementService,private troubleTicketService:TroubleTicketService) { }

  ngOnInit(): void {
    this.formData = manage_ticket;
   this.formValue =  this.formService.getManageOrderData();
   this.store.select(getEntryIncidentTicketSelector).subscribe((data) => {
    console.log("Mosal", data);
      this.manageTPValue=data;
      this.incidentType=data.ticketDetails.incidentType;
      this.ticketData=data;
  })   

   console.log("modify form data", this.formValue);
   this.modifyValue = this.formValue;

   console.log("Up",this.incidentType);
   

   this.formData.controls.forEach((main: any) => {
    if (main.key === "ticketAppointment" && this.incidentType === "Joint Investigation Fault") {
       main.visible=true;
       let payload: any = {
        timeSlotOption: 'Normal',
      };
      this.orderManagementService
      .retriveSlots(payload)
      .subscribe((val: any) => {
        if (val.timeSlotsList) {
          this.orderManagementService.getTimeSlotsList(val.timeSlotsList);
        }
        // let slots = this.orderManagementService.availableSlots;
        if (val.status == 0) {
          console.log(this.formData);
          this.formData?.controls?.forEach((section: any) => {
            console.log(section);
            if (section.id == 'ticketAppointment') {
              console.log('Came In');
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'appointmentDate') {
                  // let date = Object.keys(slots);
                  // control.dateFrom = [date[0]];
                  // control.dateTo = [date[date.length - 1]];
                }
              });
            }
          });
        }
      });
    }
    if (main.key === "endUserDetails" && (this.incidentType === "CO-LOC Fault" || this.incidentType === "Fibre monitoring")) {
      main.visible = false;
    }
   });

  }
  onSubmit(val:any){
    this.formValues=val;
    let successMsg: any = {
      title: `Confirm Update`,
      body: `Do you want to update this ticket?`,
      okFunction:"mergeEntryTicket",
      cancelButton:true
    };
    
   this.setModal(successMsg);
  }
  mergeEntryIncidentTicket(){
    let payload:any={
     rlInfo: {
        rlName: "",
        qpId: "",
        rlId: "",
        companyName: "",
        designation: "",
        faxNo: "",
        emailId: "",
        contactInfo: {
          code: "+65",
          contactNo: ""
        },
        ticketCreationDetails: {...this.ticketData.ticketDetails,ticketDescription:this.formValues.ticketDetails.ticketDescription},
        serviceOrderDetail: this.ticketData.serviceOrderDetails,
        ticketDetails:{...this.ticketData.ticketDetails,submissionType:"UPDATE"},
        endUserContactDetails:this.formValues.endUserPremisesContactDetails,
        secondaryRlDetails:this.ticketData.secondaryRequestingLisensee,
        ticketAppointment:this.formValues.ticketAppointment
    }
  }
    this.troubleTicketService.mergeIncidentTicketClose(payload).subscribe((data)=>{
      console.log("Returned from service" ,data);

      
      if(data.status==="Pass"){
        let successMsg: any = {
          title: `Ticket Updated Success`,
          body: `Incident was updated successfully`,
          okFunction:"routeHome"
        };
       this.setModal(successMsg);
      }
      else{
        let errorMsg: any = {
          title: `SWP-018 Update Incident Ticket Failure`,
          body: `There is a techncial Error occurred, Please try later to perfrom your activities. `
          ,okFunction:null
        };
       
        this.setModal(errorMsg);
        
      }
      
    })

    console.log("From Merge" ,payload);
  }
  setModal(modalData:any){
    this.modalBody=modalData.body;
    this.modalTitle=modalData.title;
    this.modalVisibilty=true;
    this.modalOkFunction=modalData.okFunction;
    this.isCancelRequired=modalData.cancelButton;
   }

   modalCancel(){
    this.modalVisibilty=false;
   }

   routeHome(){
    this.router.navigate(['/home']);
  }
  modalConfirm(func:any){
    if(func==="mergeEntryTicket"){
      this.mergeEntryIncidentTicket();
    }
    if(func==="routeHome"){
      this.routeHome();
    }
    this.modalVisibilty=false;
    this.modalOkFunction=null;
  }

  

}

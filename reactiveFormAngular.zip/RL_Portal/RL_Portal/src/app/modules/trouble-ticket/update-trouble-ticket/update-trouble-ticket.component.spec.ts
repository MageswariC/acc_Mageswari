import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTroubleTicketComponent } from './update-trouble-ticket.component';

describe('UpdateTroubleTicketComponent', () => {
  let component: UpdateTroubleTicketComponent;
  let fixture: ComponentFixture<UpdateTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

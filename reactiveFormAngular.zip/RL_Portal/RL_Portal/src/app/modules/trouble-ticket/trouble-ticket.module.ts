import { NgModule } from '@angular/core';
import { DynamicComponentModule } from 'src/app/components/dynamic-components/dynamic-component.module';
import { CreateTroubleTicketComponent } from './create/create-trouble-ticket/create-trouble-ticket.component';
import { TroubleTicketRoutingModule } from './trouble-ticket-routing.module';
import { TroubleTicketComponent } from './trouble-ticket.component';
import { TicketCreationDetailsComponent } from './ticket-creation-details/ticket-creation-details.component';
import { ManageTroubleTicketComponent } from './manage-trouble-ticket/manage-trouble-ticket.component';
import { ViewTroubleTicketComponent } from './view-trouble-ticket/view-trouble-ticket.component';
import { UpdateTroubleTicketComponent } from './update-trouble-ticket/update-trouble-ticket.component';
import { ReopenTroubleTicketComponent } from './reopen-trouble-ticket/reopen-trouble-ticket.component';
import { CancelTroubleTicketComponent } from './cancel-trouble-ticket/cancel-trouble-ticket.component';
import { TroubleTicketModalComponent } from './trouble-ticket-modal/trouble-ticket-modal.component';
import { CloseTroubleTicketComponent } from './close-trouble-ticket/close-trouble-ticket.component';
import { TableManageTroubleTicketComponent } from './table-manage-trouble-ticket/table-manage-trouble-ticket.component';

// import { ReactiveFormsModule,FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    TroubleTicketComponent,
    CreateTroubleTicketComponent,
    ManageTroubleTicketComponent,
    TicketCreationDetailsComponent,
    ViewTroubleTicketComponent,
    UpdateTroubleTicketComponent,
    ReopenTroubleTicketComponent,
    CancelTroubleTicketComponent,
    TroubleTicketModalComponent,
    CloseTroubleTicketComponent,
    TableManageTroubleTicketComponent,
  ],
  imports: [
    TroubleTicketRoutingModule,
    DynamicComponentModule,

    // SearchOrderComponent,
  ],
})
export class TroubleTicketModule {}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTroubleTicketComponent } from './manage-trouble-ticket.component';

describe('ManageTroubleTicketComponent', () => {
  let component: ManageTroubleTicketComponent;
  let fixture: ComponentFixture<ManageTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { ApiBaseService } from 'src/app/modules/integration/service/http/apiBaseService';
import { ApiService } from 'src/app/modules/integration/service/http/apiService';
import { clone } from '../../../components/utilities/util';
import searchTroubleTicket from 'src/app/modules/integration/form-data/feasibility-check/search-trouble-ticket';
import onehr_fibreProvision_fibreMain_main_manage from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/update-trouble-ticket';
import joint_investigation from 'src/app/modules/integration/form-data/trouble-ticket/create/joint_investigation';
import co_loc_fault from 'src/app/modules/integration/form-data/trouble-ticket/create/co-loc_fault';
import fiberMonitor_OssBss_fault from 'src/app/modules/integration/form-data/trouble-ticket/create/fiberMonitor_ossBss_fault';
import { ModalComponent } from 'src/app/components/dynamic-components/modal/modal.component';
import { filter } from 'rxjs';
import onehr_fibreProvision_fibreMain_main from 'src/app/modules/integration/form-data/trouble-ticket/create/onehr_fibreProvision_fibreMain';
import manage_ticket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/update-trouble-ticket';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import { troubleTicketColoumn } from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/trouble-ticket-overview-data';
import { getEntryIncidentTicketSelector } from '../../integration/store/selectors/trouble-ticket.selectors';
import { getEntryIncidentTicket } from '../../integration/store/actions/trouble-ticket.action';
import { setErrorMessage } from 'src/app/components/integration/store/actions/error-message.action';



@Component({
  selector: 'app-manage-trouble-ticket',
  templateUrl: './manage-trouble-ticket.component.html',
  styleUrls: ['./manage-trouble-ticket.component.scss']
})
export class ManageTroubleTicketComponent implements OnInit {
  troubleTicketmanage!: FormGroup;
  formData: any;
  ticketData: any;
  modalFormData: any;
  getORIDetails: Boolean = false;
  // shedule1Modal = residentialConnectionModal;
  orderStatusData: any;
  initalMangerOrder: Boolean = true;
  isOrderSatusSubmitted: Boolean = false;
  checkOrderStatusData: any;
  actionBtnList!: any;
  fcInput: any;
  incidentType: any;
  opCoIndidentId: any;
  ori: any;
  getFormControl: any;
  orderFormValue: any = null;
  showTable = false;
  tableColoumnData: any;
  tableRowData: any;
  incidentStatus: any;
  showModal=false;
  modalTitle="";
  modalBody="";

  constructor(private fb: FormBuilder, private router: Router, private formService: FormService, private toastrService: ToastrService, private store: Store) { }

  @ViewChild('modal')
  private modalComponent!: ModalComponent;
  modalObj!: any;
  tableHeader: any = ['Incident ID', 'OpCo Incident ID', 'Order Request Indentifier', 'Incident Summary', 'Appointment Date', 'Appointment Slot', 'Cause of Fault', 'Incident Status', 'Action'];
  item = {

  }
  async openModal() {
    return await this.modalComponent.open();
  }
  openModalForCancel() {
    // console.log('inside openModalForCancel');
  }
  ngOnInit(): void {
    if (this.router.events) {
      this.router.events.pipe(
        filter((event) => event instanceof NavigationEnd)
      ).subscribe(event => {
        let url = this.router.routerState.snapshot.url;
        if (url.includes("update")) this.initalMangerOrder = false;
        else if (url.includes("cancel")) this.initalMangerOrder = false;
        else if (url.includes("reopen")) this.initalMangerOrder = false;
        else this.initalMangerOrder = true;
      });
    }
    this.actionBtnList = this.formService.manageOrderBtnListroubleticket;
    this.troubleTicketmanage = this.fb.group({})
    this.checkOrderStatusData = searchTroubleTicket;
    // this.fcInput = ticketDetails.onehr_fibreProvision_fibreMain_FibreMonitor_ossBssFault;
    this.formData = manage_ticket;
    // this.ticketData= [...troubleticketDataApi];
  }

  orderStatusValue(orderSatus: any) {
    this.orderStatusData = orderSatus;
    this.formService.orderSatusData = orderSatus;
    this.isOrderSatusSubmitted = true;

    console.log("From ", orderSatus);

    this.fetchTicketDetails(orderSatus);

  }
  cancelOrderStatus() {
    this.isOrderSatusSubmitted = false;
  }
  view() {
    // this.formService.manageOrderData = this.shedule1Modal;
    this.initalMangerOrder = false;
    this.router.navigate(['trouble-ticket/manage/view']);
  }
  update() {
    // this.formService.manageOrderData = this.shedule1Modal;
    this.initalMangerOrder = false;
    this.router.navigate(['trouble-ticket/manage/update']);
  }
  cancel() {
    this.initalMangerOrder = false;
    this.router.navigate(['trouble-ticket/manage/cancel']);
  }
  reopen() {
    this.initalMangerOrder = false;
    this.router.navigate(['trouble-ticket/manage/reopen']);
  }
  close() {
    this.initalMangerOrder = false;
    this.router.navigate(['trouble-ticket/manage/close']);
  }
  getFCFormControl(e: any) {
    e.controls.incidentType.patchValue(this.incidentType);
  }
  getFormVal(val: any) {
    this.orderFormValue = val;
    this.router.navigate(['swp/home']);
    this.toastrService.success('The request for the connection has been submitted successfully ORI Details: 02-01-07012022-45671-A', '');
  }

  fetchTicketDetails(formValue: any) {
    let payload = { ...formValue, qpId: "string" }
    delete payload['or'];
    console.log(payload);

    this.store.dispatch(getEntryIncidentTicket(payload));
    this.store.select(getEntryIncidentTicketSelector).subscribe((data) => {

      if(data.ticketFound===false){
        this.setTicketNotFoundError(data.ticketFound);
      }
      else{
        if (Object.keys(data).length > 0) {
          console.log("From Select", data);
          this.setTableData(data);
        }
      }


    })

  }

  setTableData(data: any) {
    console.log("From setTable", data);


    this.tableColoumnData = troubleTicketColoumn;
    this.tableRowData = {
      OpCoIndidentId: data.ticketDetails.OpCoIncidentID,
      incidentID: data.ticketDetails.incidentID,
      ori: data.ticketDetails.ori,
      incidentSummary: data.ticketDetails.ticketSummary,
      appointmentDate: new Date(data.ticketAppointment.dateFrom).toLocaleDateString(),
      appointmentSlot: data.ticketAppointment.appointmentSlot,
      causeofFault: data.ticketDetails.causeOfFault,
      incidentStatus: data.ticketDetails.ticketStatus
    }
    this.incidentStatus = data.ticketDetails.ticketStatus;

    this.tableColoumnData = [...this.tableColoumnData];
    this.tableRowData = [this.tableRowData]

    console.log(this.tableRowData);


    this.showTable = true;
  }
  setTicketNotFoundError(data:any){

    this.modalBody=`There is no incident ticket found for this ORI. `
    this.modalTitle="SWP-018 :No Incident Ticket Found"
     this.showModal=true;
  }
  modalConfirm(){
    this.showModal=false;
  }


}

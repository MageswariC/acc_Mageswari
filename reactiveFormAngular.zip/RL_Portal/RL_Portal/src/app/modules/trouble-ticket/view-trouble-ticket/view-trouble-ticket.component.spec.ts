import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTroubleTicketComponent } from './view-trouble-ticket.component';

describe('ViewTroubleTicketComponent', () => {
  let component: ViewTroubleTicketComponent;
  let fixture: ComponentFixture<ViewTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

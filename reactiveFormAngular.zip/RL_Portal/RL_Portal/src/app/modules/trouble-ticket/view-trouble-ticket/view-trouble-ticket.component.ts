import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import manage_ticket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/update-trouble-ticket';
import view_ticket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/view-trouble-ticket';
import { viewTroubleTicketModal } from 'src/app/modules/integration/modal/trouble-ticket/view-trouble-ticket.model';
import { Store } from '@ngrx/store';
import { getEntryIncidentTicketSelector } from '../../integration/store/selectors/trouble-ticket.selectors';


@Component({
  selector: 'app-view-trouble-ticket',
  templateUrl: './view-trouble-ticket.component.html',
  styleUrls: ['./view-trouble-ticket.component.scss']
})
export class ViewTroubleTicketComponent implements OnInit {

  checkFeasibility: any;
  formData: any;
  formValue: any;
  modifyValue!: any;
  viewTTmodal: any;
  incidentType: any;
  formShow = false;

  constructor(private router: Router, private toastrService: ToastrService, private formService: FormService, private store: Store) { }

  ngOnInit(): void {
    this.formData = view_ticket;
    this.formValue = this.formService.getManageOrderData();
    this.store.select(getEntryIncidentTicketSelector).subscribe((data) => {
      console.log("Mosal", data);

      if (Object.keys(data).length > 0) {
        this.setModalData(data);
      }
      this.incidentType = data.ticketDetails.incidentType;
      console.log("From init", this.incidentType);

    })
    //  this.viewTTmodal = viewTroubleTicketModal;

    if (this.incidentType &&this.incidentType !== "Joint Investigation Fault") {

      this.formData.controls.forEach((control: any) => {
        if (control.key === "ticketAppointment") {
          control.visible = false;
        }
      })

    }

    console.log("modify form data", this.formValue);
    this.modifyValue = this.formValue;
  }

  setModalData(data: any) {

    this.viewTTmodal = data;

  }

}

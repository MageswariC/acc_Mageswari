import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TroubleTicketComponent } from './trouble-ticket.component';

describe('TroubleTicketComponent', () => {
  let component: TroubleTicketComponent;
  let fixture: ComponentFixture<TroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

declare var window: any;
@Component({
  selector: 'app-trouble-ticket-modal',
  templateUrl: './trouble-ticket-modal.component.html',
  styleUrls: ['./trouble-ticket-modal.component.scss']
})
export class TroubleTicketModalComponent  implements OnInit {
  formModal: any;
 
  @Input() title:any="Ram";
  @Input() body:any="Ram";
  @Input() cancelRequired=false;
  @Input() okFunction:any=null;
  @Output() confirmClicked= new EventEmitter<any>();
  @Output() cancelClicked= new EventEmitter<any>();
 
  constructor() {}
 
  ngOnInit(): void {
    this.formModal = new window.bootstrap.Modal(
      document.getElementById('myModal')
    );
    this.openFormModal();
  }
 
  openFormModal() {
    this.formModal.show();

  }
  confirm() {
    
    this.confirmClicked.emit(this.okFunction!==null?this.okFunction:false);
    this.formModal.hide();
   
    
  }
  cancel(){
 this.cancelClicked.emit();
 this.formModal.hide();
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TroubleTicketModalComponent } from './trouble-ticket-modal.component';

describe('TroubleTicketModalComponent', () => {
  let component: TroubleTicketModalComponent;
  let fixture: ComponentFixture<TroubleTicketModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TroubleTicketModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TroubleTicketModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelTroubleTicketComponent } from './cancel-trouble-ticket.component';

describe('CancelTroubleTicketComponent', () => {
  let component: CancelTroubleTicketComponent;
  let fixture: ComponentFixture<CancelTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CancelTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CancelTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

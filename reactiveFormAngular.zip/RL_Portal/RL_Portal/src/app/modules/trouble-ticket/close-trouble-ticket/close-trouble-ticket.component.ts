import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import { Observable, Subscription } from 'rxjs';
import reopenTroubleTicket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/reopen-trouble-ticket';

import cancelTroubleTicket from 'src/app/modules/integration/form-data/trouble-ticket/manage trouble ticket/cancel-trouble-ticket';
import { closeTroubleTicketModal } from 'src/app/modules/integration/modal/trouble-ticket/close-trouble-ticket.modal';
import { Store } from '@ngrx/store';
import { getEntryIncidentTicketSelector } from '../../integration/store/selectors/trouble-ticket.selectors';
import { TroubleTicketService } from '../../integration/service/trouble-ticket/trouble-ticket.service';
import { setErrorMessage } from 'src/app/components/integration/store/actions/error-message.action';

@Component({
  selector: 'app-close-trouble-ticket',
  templateUrl: './close-trouble-ticket.component.html',
  styleUrls: ['./close-trouble-ticket.component.scss']
})
export class CloseTroubleTicketComponent implements OnInit {

  checkFeasibility: any;
formData: any;
formValue:any;
modifyValue!:any;
closeTTmodalvalue:any;
modalVisibilty=false;
formValues:any;
modalTitle="Close Trouble Ticket";
modalBody="Do you want to close your trouble ticket?";
ticketData:any;
modalOkFunction:any=null;

  constructor(private router: Router,private toastrService: ToastrService, private formService:FormService,private store:Store,private troubleTicketService:TroubleTicketService) { }

  ngOnInit(): void {
    this.formData = cancelTroubleTicket;
   this.formValue =  this.formService.getManageOrderData();
   //this.closeTTmodalvalue = closeTroubleTicketModal;
  //  this.closeTTmodalvalue={
  //   ticketDetails:{
  //     incidentID:"svjvsjvj"
  //   }
  // }
   this.store.select(getEntryIncidentTicketSelector).subscribe((data)=>{
  let incidentIDRes= data.ticketDetails.incidentID;

  this.closeTTmodalvalue={
    ticketDetails:{
      incidentID:incidentIDRes
    }
  }

  this.ticketData=data;
  
    
   })

   console.log("modify form data", this.formValue);
   this.modifyValue = this.formValue;
  }



  getFormVal(data:any){
    console.log("From form" ,data);
    let confirmMsg: any = {
      title: `Close Trouble Ticket`,
      body: `Do you want to close your trouble ticket?`,
      okFunction:"mergeEntryTicket"
    };
   this.setModal(confirmMsg);

    this.formValues= data;
  }

  modalConfirm(func:any){
    if(func==="mergeEntryTicket"){
      this.mergeEntryIncidentTicket();
    }
    if(func==="routeHome"){
      this.routeHome();
    }
    this.modalVisibilty=false;
    this.modalOkFunction=null;
  }
  modalCancel(){
    this.modalVisibilty=false;

  }
  mergeEntryIncidentTicket(){
    let payload:any={
     rlInfo: {
        rlName: "",
        qpId: "",
        rlId: "",
        companyName: "",
        designation: "",
        faxNo: "",
        emailId: "",
        contactInfo: {
          code: "+65",
          contactNo: ""
        },
        ticketCreationDetails: this.ticketData.ticketDetails,
        serviceOrderDetail: this.ticketData.serviceOrderDetails,
        ticketDetails:{...this.ticketData.ticketDetails,submissionType:"CLOSE"},
        endUserContactDetails:this.ticketData.endUserPremisesContactDetails,
        secondaryRlDetails:this.ticketData.secondaryRequestingLisensee,

    }
  }
    this.troubleTicketService.mergeIncidentTicketClose(payload).subscribe((data)=>{
      console.log("Returned from service" ,data);

      
      if(data.status==="Pass"){
        let successMsg: any = {
          title: `SWP-019 Close Incident ticket Succcess`,
          body: `Incident was closed successfully`,
          okFunction:"routeHome"
        };
       this.setModal(successMsg);
      }
      else{
        let errorMsg: any = {
          type: 'info',
          title: `Close Incident Ticket Failure`,
          status: "SWP-018",
          message: `There is a techncial Error occurred, Please try later to perfrom your activities. `
        };
        this.store.dispatch(setErrorMessage({ message: errorMsg }));

        
      }
      
    })

    console.log("From Merge" ,payload);
  }

  routeHome(){
    this.router.navigate(['/home']);
  }
  setModal(modalData:any){
    this.modalBody=modalData.body;
    this.modalTitle=modalData.title;
    this.modalVisibilty=true;
    this.modalOkFunction=modalData.okFunction;
   }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CloseTroubleTicketComponent } from './close-trouble-ticket.component';

describe('CloseTroubleTicketComponent', () => {
  let component: CloseTroubleTicketComponent;
  let fixture: ComponentFixture<CloseTroubleTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CloseTroubleTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CloseTroubleTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewFeasiblityCheckerComponent } from 'src/app/components/dynamic-components/form/new-feasiblity-checker/new-feasiblity-checker.component';
import { CancelTroubleTicketComponent } from './cancel-trouble-ticket/cancel-trouble-ticket.component';
import { CloseTroubleTicketComponent } from './close-trouble-ticket/close-trouble-ticket.component';
import { CreateTroubleTicketComponent } from './create/create-trouble-ticket/create-trouble-ticket.component';
import { ManageTroubleTicketComponent } from './manage-trouble-ticket/manage-trouble-ticket.component';
import { ReopenTroubleTicketComponent } from './reopen-trouble-ticket/reopen-trouble-ticket.component';
import { TroubleTicketModalComponent } from './trouble-ticket-modal/trouble-ticket-modal.component';

import { TroubleTicketComponent } from './trouble-ticket.component';
import { UpdateTroubleTicketComponent } from './update-trouble-ticket/update-trouble-ticket.component';
import { ViewTroubleTicketComponent } from './view-trouble-ticket/view-trouble-ticket.component';


const routes: Routes = [
  {
    path: '', component: TroubleTicketComponent, children: [
      {
        path: 'trouble-ticket/create',
        component: CreateTroubleTicketComponent,
        data: {
          breadcrumb: ['Trouble Ticket', 'Create'],
          orderInfo: {
            code: "SA",
            type: "Service Assurance"
          }
        }
      },
      {
        path: 'trouble-ticket/manage',
        component: ManageTroubleTicketComponent,
        data: {
          breadcrumb: ['Trouble Ticket', 'Manage'], orderInfo: {
            code: "SA",
            type: "Service Assurance"
          }
        },
        children: [
          // {path: 'view', component: view_ticket, data: { breadcrumb: ['View'] }},
          //  {path: 'trouble-ticket/manage/update', component: UpdateTroubleTicketComponent1, data: { breadcrumb: ['Update'] }},
          //  {path: 'cancel', component: CancelOrderComponent, data: { breadcrumb: ['Cancel'] }},
          // {path: 'reopen', component: ReopenTroubleTicketComponent, data: { breadcrumb: ['Reopen'] }},
        ]
      },
      {
        path: 'trouble-ticket/manage/view',
        component: ViewTroubleTicketComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'View'] }
      },
      {
        path: 'trouble-ticket/manage/update',
        component: UpdateTroubleTicketComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'Update'] }
      },
      {
        path: 'trouble-ticket/manage/cancel',
        component: CancelTroubleTicketComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'Cancel'] }
      },
      {
        path: 'trouble-ticket/manage/reopen',
        component: ReopenTroubleTicketComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'Reopen'] }
      },
      {
        path: 'trouble-ticket/manage/close',
        component: CloseTroubleTicketComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'Close'] }
      },
      {
        path: 'trouble-ticket/modal',
        component: TroubleTicketModalComponent,
        data: { breadcrumb: ['Trouble Ticket', 'Manage', 'Reopen'] }
      },
      {
        path: 'trouble-ticket/newfc',
        component: NewFeasiblityCheckerComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Create Order',
          ]
        }
      },



    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TroubleTicketRoutingModule { }

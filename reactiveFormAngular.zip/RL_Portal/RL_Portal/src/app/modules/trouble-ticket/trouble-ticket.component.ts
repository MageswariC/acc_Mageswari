import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trouble-ticket',
  templateUrl: './trouble-ticket.component.html',
  styleUrls: ['./trouble-ticket.component.scss']
})
export class TroubleTicketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

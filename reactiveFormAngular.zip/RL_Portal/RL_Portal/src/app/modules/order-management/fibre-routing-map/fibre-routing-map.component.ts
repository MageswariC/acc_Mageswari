import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormService } from 'src/app/form.service';
import fibreRoutingMapFormData from '../../integration/form-data/order-management/create-order/fibre-routing-map';
import fc from 'src/app/modules/integration/form-data/feasibility-check/fibre-routing-map';

@Component({
  selector: 'app-fibre-routing-map',
  templateUrl: './fibre-routing-map.component.html',
  styleUrls: ['./fibre-routing-map.component.scss']
})
export class FibreRoutingMapComponent implements OnInit {
  //form builder inputs
  formData: any;
  fiberRoutingMapForm: any;

  //feasibility check input
  fcInput: any;
  getFormControl: any;
  isFesibilityCheckClicked: Boolean = false;
  formValue: any;
  getFCFormControl: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private formService: FormService,
    private toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.formData = fibreRoutingMapFormData;
    this.fcInput=fc;
    this.fiberRoutingMapForm= this.fb.group({});
  }
  getForm(form: FormGroup)
  {
    this.getFormControl = form.controls;
  }
  getFCForm(form: FormGroup)
  {
    this.getFCFormControl = form.controls;
    // this.isFesibilityCheckClicked = true;
  }
  fcFormValue(fcForm: FormGroup) {
    this.isFesibilityCheckClicked = true;
  }
  getFormVal(val: any) {
    this.formValue = val;
    this.router.navigate(['home']);
    this.toastrService.success(
      'Your request has been submitted successfully',
      ''
    );
  }

}

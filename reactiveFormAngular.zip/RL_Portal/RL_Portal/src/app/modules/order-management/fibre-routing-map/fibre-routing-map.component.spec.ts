import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FibreRoutingMapComponent } from './fibre-routing-map.component';

describe('FibreRoutingMapComponent', () => {
  let component: FibreRoutingMapComponent;
  let fixture: ComponentFixture<FibreRoutingMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FibreRoutingMapComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FibreRoutingMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

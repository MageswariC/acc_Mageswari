import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import tprrrForm from 'src/app/modules/integration/form-data/order-management/create-order/tprrr-formData';
import fc from 'src/app/modules/integration/form-data/feasibility-check/feasibility-check-tprrr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-tprrr',
  templateUrl: './tprrr.component.html',
  styleUrls: ['./tprrr.component.scss']
})
export class TprrrComponent implements OnInit {

  tprrr!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;
  //Feasibility check input 
  fcInput: any;

  //form builder input
  formData: any;
  getFormControl: any;
  sheduleModal:any;
 
  constructor(private fb: FormBuilder, private router: Router,private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.formData = tprrrForm;
    this.fcInput = fc;
    this.tprrr = this.fb.group({})
  }

  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
  fcFormValue(fcForm: any) {
    this.isFesibilityCheckClicked = true;
    this.sheduleModal={

      tpDetails:{
        tpName:"TPname",
        operation:""
      },
      installationAddress:{
        blockHouseNumber: "4A",

        "postalCode": "567363",

        "dataCenter": "",
        "coverageStatus": "Unit Reached",
  
        "unitNumber": "#10-309",
        "tpName":"TPname",
        "buildingType":"HDR", 
        "feasibilityNote":"Home Reached",
        "feasibilityCode":"HomeReached",
       "streetName":"YISHUN STREET 6", 
        "buildingName":"OLEANDER BREEZE", 
        "buildingHouseNo":"302",
        "feasibilityStatus":"sample text",
         "firstPassIndicator":"", 
         "tpInstallation":"", 
         "copifType":"COPIF 2008", 
         "physicalCo":"Phy001", 
         "logicalCo":"Logicl001"
      }
    }
  }
  fcFormControl(fcForm: any){

  }
  getFormVal(val: any) {
    //console.log("---in get value--",val.value)
  
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TprrrComponent } from './tprrr.component';

describe('TprrrComponent', () => {
  let component: TprrrComponent;
  let fixture: ComponentFixture<TprrrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TprrrComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TprrrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

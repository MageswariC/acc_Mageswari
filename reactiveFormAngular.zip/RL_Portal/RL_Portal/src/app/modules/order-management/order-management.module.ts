import { NgModule } from '@angular/core';
import { DynamicComponentModule } from 'src/app/components/dynamic-components/dynamic-component.module';
import { FormService } from '../integration/service/order-management/form.service';
import { EffectsModule } from '@ngrx/effects';
import { OrderManagementRoutingModule } from '../order-management/order-management-routing.module';
import { OrderManagementComponent } from './order-management.component';
import { CreateResidentialEndUserConnectionComponent } from './residentrial-end-user/create-residential-end-user-connection/create-residential-end-user-connection.component';
import { ManageOrderResidentialEndUserComponent } from './residentrial-end-user/manage-order-residential-end-user-connection/manage-order-residential-end-user/manage-order-residential-end-user.component';
import { FeasibilityCheckEffects } from '../integration/store/effects/feasibility-check.effect';
import { ResidentialEndUSerCreateOrderEffects } from '../integration/store/effects/order-management';
import { ManageOrderTableComponent } from './residentrial-end-user/manage-order-table/manage-order-table.component';
import { GponToOeComponent } from './residentrial-end-user/gpon-to-oe/gpon-to-oe.component';
import { RelocateServiceComponent } from './residentrial-end-user/relocate-service/relocate-service.component';
import { ManageTpComponent } from './residentrial-end-user/manage-tp/manage-tp.component';
import { CreditCheckComponent } from './credit-check/credit-check.component';
import { CancelOrderComponent } from './residentrial-end-user/cancel-order/cancel-order.component';
import { TerminateOrderComponent } from './residentrial-end-user/terminate-order/terminate-order.component';
import { ModifyOrderComponent } from './residentrial-end-user/modify-order/modify-order.component';
import { CreateCoToNbapDpConnectionComponent } from './co-to-nbap-dp-connection/create-co-to-nbap-dp-connection/create-co-to-nbap-dp-connection.component';
import { CreateNbapTpConnectionComponent } from './nbap-dp-to-nbap-tp-connection/create-nbap-tp-connection/create-nbap-tp-connection.component';
import { FibreRoutingMapComponent } from './fibre-routing-map/fibre-routing-map.component';
import { CreateCoToBuildingMdfConnectionComponent } from './segment-connection/co-to-building-mdf-connection/create-co-to-building-mdf-connection/create-co-to-building-mdf-connection.component';
import { CreateFttbNodeConnectionComponent } from './create-fttb-node-connection/create-fttb-node-connection.component';
import { CreateDpConnectionComponent } from './fttb-node-to-dp-connection/create-dp-connection/create-dp-connection.component';

import { TprrrComponent } from './tprrr/tprrr.component';
import { AdvanceCoverageCheckComponent } from './advance-coverage-check/advance-coverage-check.component';
import { SiteSurveyComponent } from './site-survey/site-survey.component';
import { CreateResidentialPremiseConnectionComponent } from './segment-connection/create-residential-premise-connection/create-residential-premise-connection.component';
import { CreateNonResidentialPremisesConnectionComponent } from './segment-connection/create-non-residential-premises-connection/create-non-residential-premises-connection.component';
import { CreateNonResidentialEndUserComponent} from './non-residential-end-user/non-residential-end-user.component';
import { CreateNBAPConnectionComponent } from './nbap-connection/create-nbap-connection/create-nbap-connection/create-nbap-connection.component';
import { CreateCoConnectionComponent } from './segment-connection/co-connection/create-co-connection/create-co-connection.component';
@NgModule({
  declarations: [
    OrderManagementComponent,
    CreateResidentialEndUserConnectionComponent,
    ManageOrderResidentialEndUserComponent,
    ManageOrderTableComponent,
    GponToOeComponent,
    RelocateServiceComponent,
    ManageTpComponent,
    CreditCheckComponent,
    CancelOrderComponent,
    TerminateOrderComponent,
    ModifyOrderComponent,
    CreateNonResidentialEndUserComponent,
    CreateNBAPConnectionComponent,
    CreateResidentialEndUserConnectionComponent,
    CreateResidentialPremiseConnectionComponent,
    CreateCoToBuildingMdfConnectionComponent,
    CreateFttbNodeConnectionComponent,
    CreateDpConnectionComponent,
    CreateCoToNbapDpConnectionComponent,
    CreateNbapTpConnectionComponent,
    FibreRoutingMapComponent,
    CreateNonResidentialPremisesConnectionComponent,
    TprrrComponent,
          AdvanceCoverageCheckComponent,
          SiteSurveyComponent,
          CreateCoConnectionComponent,
    
  ],
  imports: [
    OrderManagementRoutingModule,
    DynamicComponentModule,
    // StoreModule.forFeature('OrderManagementReducer', OrderManagementReducer),
    EffectsModule.forFeature([
      FeasibilityCheckEffects,
      ResidentialEndUSerCreateOrderEffects,
    ]),
  ],
})
export class OrderManagementModule {}

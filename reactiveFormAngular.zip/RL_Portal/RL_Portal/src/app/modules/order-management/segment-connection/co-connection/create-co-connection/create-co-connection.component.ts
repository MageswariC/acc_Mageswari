import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import  coToCoConnectionFormData from 'src/app/modules/integration/form-data/order-management/create-order/co-to-co-connection-formData';
import { Router } from '@angular/router';
import { FormService } from 'src/app/form.service';
import { coToCoConnectionModal } from 'src/app/modules/integration/modal/order-management/create-order/co-to-connection.modal';

@Component({
  selector: 'app-create-co-connection',
  templateUrl: './create-co-connection.component.html',
  styleUrls: ['./create-co-connection.component.scss']
})
export class CreateCoConnectionComponent implements OnInit {
  cocToCoConnectionS4!: FormGroup;

  //form builder input
  formData: any;
  shedule4Modal = coToCoConnectionModal;
  getFormControl: any;

  // getFormVal: any;
  // formValue: any;

  constructor(private fb: FormBuilder, private router: Router, private formService: FormService, private toastrService: ToastrService) {

  }

  ngOnInit(): void {
    this.formData = coToCoConnectionFormData;
    this.cocToCoConnectionS4 = this.fb.group({
    });

  }
  
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
  getFormVal(val:any){
    this.router.navigate(['swp/home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }

  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'redundancyServiceoptions') {
        if (obj.option.value == 'No') {
          control.readOnly = true;
          control.required = false;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValue(null);
          this.getFormControl.orderDetails.get('redundancyServiceoptions').clearValidators();
        } else {
          control.readOnly = false;
          control.required = true;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValidators([Validators.required]);
        }
        this.getFormControl.orderDetails.get('redundancyServiceoptions').updateValueAndValidity();
      }
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }
  
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import coTobuildingMdfConnectionFormData from 'src/app/modules/integration/form-data/order-management/create-order/co-to-building-mdf-connection-formData';
import { coTobuildingMdfConnectionModal } from 'src/app/modules/integration/modal/order-management/create-order/co-to-building-mdf-connection.modal';
import fc from 'src/app/modules/integration/form-data/feasibility-check/fesibility-check-s5';
import { Router } from '@angular/router';
import { LoginComponent } from 'src/app/components/dynamic-components/login/login.component';


@Component({
  selector: 'app-create-co-to-building-mdf-connection',
  templateUrl: './create-co-to-building-mdf-connection.component.html',
  styleUrls: ['./create-co-to-building-mdf-connection.component.scss']
})
export class CreateCoToBuildingMdfConnectionComponent implements OnInit {

  buildingMdfConnectionS5!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;

  //Feasibility check input 
  fcInput: any;

  //form builder input
  formData: any;
  getFormControl: any;
  shedule5Modal = coTobuildingMdfConnectionModal

  fcControl: any;

  constructor(private fb: FormBuilder, private router: Router, private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.formData = coTobuildingMdfConnectionFormData;
    this.fcInput = fc;
    this.buildingMdfConnectionS5 = this.fb.group({});
  }
  buildingMdfConnectionModal(buildingMdfConnectionModal: any) {
    throw new Error('Method not implemented.');
  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;

  }
  getFormVal(val: any) {
    this.router.navigate(['swp/home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }
  fcFormValue(fcForm: FormGroup) {
    this.isFesibilityCheckClicked = true;
  }

  fcFormControl(fcForm: any) {
     console.log("only formcontrols", fcForm);
    // console.log("formcontrols feasibilty check", fcForm.feasibilityCheck);
 
    this.fcControl = fcForm.controls; 
    
  }

  setReactiveFormValidator(control : any){
    this.fcControl.feasibilityCheck.get(control).setValidators([Validators.required]);
    this.fcControl.feasibilityCheck.get(control).updateValueAndValidity();
  }
  clearReactiveFormValidator(control : any){
    this.fcControl.feasibilityCheck.get(control).clearValidators();
    this.fcControl.feasibilityCheck.get(control).updateValueAndValidity();
    this.fcControl.feasibilityCheck.get(control).reset();

  }
  
  changeServingOptions(obj : any){
    console.log("serving options change",obj);
    console.log("value",obj.option.value);
    
    fc.controls[0].options.children.forEach((field:any)=>{
      console.log("fields",field);
      if (obj.option.value === "Postal Code"){
        
        if (field.key==="postalCode"){
          field.visible= true;
          field.required=true;
          console.log(this.fcControl);
          this.setReactiveFormValidator("postalCode");
         this.clearReactiveFormValidator("servingCabinet");
        }
        if (field.key==="servingCabinet"){
          field.visible= false;
          field.required=false;
        }
      }
      else{
        
        if (field.key==="postalCode"){
          field.visible= false;
          field.required=false;
          this.setReactiveFormValidator("servingCabinet");
        this.clearReactiveFormValidator("postalCode");
        }
        if (field.key==="servingCabinet"){
          field.visible= true;
          field.required=true;
        }
      }
      
    }
    )


    
  }
  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'redundancyServiceoptions') {
        if (obj.option.value == 'No') {
          control.readOnly = true;
          control.required = false;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValue(null);
          this.getFormControl.orderDetails.get('redundancyServiceoptions').clearValidators();
        } else {
          control.readOnly = false;
          control.required = true;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValidators([Validators.required]);
        }
        this.getFormControl.orderDetails.get('redundancyServiceoptions').updateValueAndValidity();
      }
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }

}

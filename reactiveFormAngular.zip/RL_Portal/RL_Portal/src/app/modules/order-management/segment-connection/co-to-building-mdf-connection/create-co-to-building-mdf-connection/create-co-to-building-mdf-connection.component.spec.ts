import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCoToBuildingMdfConnectionComponent } from './create-co-to-building-mdf-connection.component';

describe('CreateCoToBuildingMdfConnectionComponent', () => {
  let component: CreateCoToBuildingMdfConnectionComponent;
  let fixture: ComponentFixture<CreateCoToBuildingMdfConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateCoToBuildingMdfConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateCoToBuildingMdfConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

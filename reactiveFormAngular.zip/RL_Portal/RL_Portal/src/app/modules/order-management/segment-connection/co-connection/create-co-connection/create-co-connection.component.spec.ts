import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCoConnectionComponent } from './create-co-connection.component';

describe('CreateCoConnectionComponent', () => {
  let component: CreateCoConnectionComponent;
  let fixture: ComponentFixture<CreateCoConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateCoConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateCoConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

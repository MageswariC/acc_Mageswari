import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateResidentialPremiseConnectionComponent } from './create-residential-premise-connection.component';

describe('CreateResidentialPremiseConnectionComponent', () => {
  let component: CreateResidentialPremiseConnectionComponent;
  let fixture: ComponentFixture<CreateResidentialPremiseConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateResidentialPremiseConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateResidentialPremiseConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

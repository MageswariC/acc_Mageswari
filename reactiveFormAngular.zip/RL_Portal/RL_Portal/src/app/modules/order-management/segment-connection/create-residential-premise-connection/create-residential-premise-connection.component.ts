import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import residentialPremiseConnectionFormData from 'src/app/modules/integration/form-data/order-management/create-order/residential-connection-premises-formData';
import fc from '../../../integration/form-data/feasibility-check/residential-connection-premises-check';
export const residentialPremiseConnectionModal: any = {
  feasibilityCheck: {
    postalCode: '',
    unitNumber: '',
  },
  installationAddress: {
    buildingName: 'OLEANDER BREEZE',
    streetName: 'YISHUN STREET 51',
    unitNumber: '#01-01',
    postalCode: '560302',
    buildingType: 'HDB',
    coverageStatus: 'Home Reached',
    copifType: 'Pre-Copif',
  },
  orderDetails: {
    appRefIdentifier: '',
    technology: 'GPON',
    splitRatio: '1:24',
    redundancyService: 'No',
    rejectIfredundancyService: 'No',
    contractTerm: '12 Months',
    promoCode: '',
  },
  activationDetails: {
    timeSlotOption: 'Normal',
    // dateOfActivation: cDate.formatDate(new Date()),
    installationTime: '12PM',
  },
  endUserDetails: {
    salutation: 'Mr',
    userName: '',
    phoneNumber: '',
    emailAddress: '',
    userType: 'Normal',
  },
  priceDetails: {
    installationCharge: '$30',
    serviceActivationCharge: '$0',
    monthlyRecurringCharge: '$0',
  },
  addInformation: {
    addInformation: '',
  },
};

@Component({
  selector: 'app-create-residential-premise-connection',
  templateUrl: './create-residential-premise-connection.component.html',
  styleUrls: ['./create-residential-premise-connection.component.scss'],
})
export class CreateResidentialPremiseConnectionComponent implements OnInit {
  resiEndUserS8!: FormGroup;
  isFesibilityCheckDone: Boolean = false;
  shedule1Model = residentialPremiseConnectionModal;

  modalObj = {
    modalTitle: '',
    modalBody: '',
    cancelRequired: false,
    modalOkFunction: null,
  };
  //Feasibility check input
  fcInput: any;

  //form builder input
  formData: any;
  getFormControl: any;
  formSubmitted = false;
  modalVisibilty = false;
  constructor(
    private fb: FormBuilder,
    private toastrService: ToastrService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.formData = residentialPremiseConnectionFormData;
    this.fcInput = fc;
    this.resiEndUserS8 = this.fb.group({});
  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }

  checkFeasibility(fcForm: any) {
    this.isFesibilityCheckDone = true;
  }
  onEditFeasibilityCheck() {
    let successMsg: any = {
      title: 'Confirmation',
      body: 'Are you sure you want to do Feasibility Check Again?',
      okFunction: 'EditFC',
    };
    this.setModal(successMsg);
  }
  setModal(modalData: any) {
    this.modalObj.modalBody = modalData.body;
    this.modalObj.modalTitle = modalData.title;
    this.modalVisibilty = true;
    this.modalObj.modalOkFunction = modalData.okFunction;
  }
  modalCancel() {
    this.modalVisibilty = false;
  }
  getFormVal(val: any) {
    this.router.navigate(['swp/home']);
    this.toastrService.success(
      'Your request has been submitted successfully',
      ''
    );
  }
  changeTechnology(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'splitRatio') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'GPON' && opt.value == '2:24') {
            opt.disable = true;
            this.getFormControl.orderDetails.patchValue({ splitRatio: '1:24' });
          } else {
            opt.disable = false;
          }
          if (obj.option.value == 'OE') {
            if (opt.value == '1:1' || opt.value == '1:24') {
              opt.disable = true;
              this.getFormControl.orderDetails.patchValue({
                splitRatio: '2:24',
              });
            }
          }
        });
      }
    });
  }

  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .clearValidators();
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({
              rejectIfredundancyService: 'No',
            });
            opt.disable = false;
          }
          this.getFormControl.orderDetails
            .get('rejectIfredundancyService')
            .updateValueAndValidity();
        });
      }
    });
  }
  onSubmitClick(val: any) {}
  onCancelClick() {
    let successMsg: any = {
      title: 'Confirmation',
      body: 'Are you sure you want to cancel the Order?',
      okFunction: 'CancelEvent',
    };
    this.setModal(successMsg);
  }

  getConfirmationValue(value: any) {
    if (value == 'Save click') {
      this.router.navigate(['swp/home']);
    }
  }
}

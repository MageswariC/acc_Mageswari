import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNonResidentialPremisesConnectionComponent } from './create-non-residential-premises-connection.component';

describe('CreateNonResidentialPremisesConnectionComponent', () => {
  let component: CreateNonResidentialPremisesConnectionComponent;
  let fixture: ComponentFixture<CreateNonResidentialPremisesConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateNonResidentialPremisesConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateNonResidentialPremisesConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

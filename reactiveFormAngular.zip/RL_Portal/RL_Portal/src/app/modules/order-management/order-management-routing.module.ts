import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderManagementComponent } from './order-management.component';
import { CancelOrderComponent } from './residentrial-end-user/cancel-order/cancel-order.component';
import { CreateResidentialEndUserConnectionComponent } from './residentrial-end-user/create-residential-end-user-connection/create-residential-end-user-connection.component';
import { GponToOeComponent } from './residentrial-end-user/gpon-to-oe/gpon-to-oe.component';
import { ManageOrderResidentialEndUserComponent } from './residentrial-end-user/manage-order-residential-end-user-connection/manage-order-residential-end-user/manage-order-residential-end-user.component';
import { RelocateServiceComponent } from './residentrial-end-user/relocate-service/relocate-service.component';
import { ManageTpComponent } from './residentrial-end-user/manage-tp/manage-tp.component';
import { ModifyOrderComponent } from './residentrial-end-user/modify-order/modify-order.component';
import { TerminateOrderComponent } from './residentrial-end-user/terminate-order/terminate-order.component';
import { CreateNonResidentialEndUserComponent } from './non-residential-end-user/non-residential-end-user.component';
import { CreateNBAPConnectionComponent } from './nbap-connection/create-nbap-connection/create-nbap-connection/create-nbap-connection.component';
import { CreateCoToBuildingMdfConnectionComponent } from './segment-connection/co-to-building-mdf-connection/create-co-to-building-mdf-connection/create-co-to-building-mdf-connection.component';
import { CreateFttbNodeConnectionComponent } from './create-fttb-node-connection/create-fttb-node-connection.component';
import { CreateDpConnectionComponent } from './fttb-node-to-dp-connection/create-dp-connection/create-dp-connection.component';
import { CreateResidentialPremiseConnectionComponent } from './segment-connection/create-residential-premise-connection/create-residential-premise-connection.component';
import { CreateNonResidentialPremisesConnectionComponent } from './segment-connection/create-non-residential-premises-connection/create-non-residential-premises-connection.component';
import { CreateCoToNbapDpConnectionComponent } from './co-to-nbap-dp-connection/create-co-to-nbap-dp-connection/create-co-to-nbap-dp-connection.component';
import { CreateNbapTpConnectionComponent } from './nbap-dp-to-nbap-tp-connection/create-nbap-tp-connection/create-nbap-tp-connection.component';
import { FibreRoutingMapComponent } from './fibre-routing-map/fibre-routing-map.component';

import { TprrrComponent } from './tprrr/tprrr.component';
import { AdvanceCoverageCheckComponent } from './advance-coverage-check/advance-coverage-check.component';
import { SiteSurveyComponent } from './site-survey/site-survey.component';
import { CreateCoConnectionComponent } from './segment-connection/co-connection/create-co-connection/create-co-connection.component';

const routes: Routes = [
  {
    path: '',
    component: OrderManagementComponent,
    children: [
      {
        path: 'swp/ordermanagement/residential-connection/create-order',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Create Order',
          ],
          sheduleInfo: {
            scheduleCode: '01',
            scheduleId: 'schedule 1',
            scheduleName: 'Residential End-User Connection ',
            serviceType: 'Resco',
          },
          orderInfo: {
            code: 'SO',
            type: 'Service Order',
            orderSource: 'swp',
            orderType: 'A',
            revision: '1',
            reclasification: 'Resco',
          },
          creditCheck: true,
        },
      },
      {
        path: 'swp/ordermanagement/residential-connection/manage-order',
        component: ManageOrderResidentialEndUserComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
          ],
          sheduleInfo: {
            scheduleCode: '01',
            scheduleId: 'schedule 1',
            scheduleName: 'Residential End-User Connection',
            serviceType: 'Resco',
          },
          orderInfo: {
            code: 'SO',
            type: 'Service Order',
          },
        },
      },
      //       {
      //         path: 'swp/ordermanagement/manage-order-residential-connection/view',
      //         component: ViewOrderComponent,
      //         data: {
      //           breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order', 'View Order']
      //         }
      //       },
      //       {
      //         path: 'swp/ordermanagement/manage-order-residential-connection/modify',
      //         component: ModifyOrderComponent,
      //         data: {
      //           breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','Modify']
      //         }
      //       },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/cancel',
      //   component: CancelOrderComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','Cancel']
      //   }
      // },
      {
        path: 'swp/ordermanagement/manage-order-residential-connection/terminate',
        component: TerminateOrderComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
            'Terminate',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/manage-order-residential-connection/manageTP',
        component: ManageTpComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
            'manageTP',
          ],
        },
      },
      //       {
      //         path: 'swp/ordermanagement/manage-order-residential-connection/view',
      //         component: ViewOrderComponent,
      //         data: {
      //           breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order', 'View Order']
      //         }
      //       },
      {
        path: 'swp/ordermanagement/manage-order-residential-connection/modify',
        component: ModifyOrderComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
            'Modify',
          ],
        },
      },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/cancel',
      //   component: CancelOrderComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','Cancel']
      //   }
      // },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/terminate',
      //   component: TerminateOrderComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','Terminate']
      //   }
      // },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/manageTP',
      //   component: ManageTpComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','manageTP']
      //   }
      // },

      {
        path: 'swp/ordermanagement/manage-order-residential-connection/GPONtoOE',
        component: GponToOeComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
            'GPONtoOE',
          ],
        },
      },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/relocateService',
      //   component: RelocateServiceComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','Relocate Service']
      //   }
      // },
      // {
      //   path: 'swp/ordermanagement/manage-order-residential-connection/GPONtoOE',
      //   component: GponToOeComponent,
      //   data: {
      //     breadcrumb: ['Order Management', 'Residential Connection', 'Manage Order','GPONtoOE']
      //   }
      // },
      {
        path: 'swp/ordermanagement/manage-order-residential-connection/relocateService',
        component: RelocateServiceComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Manage Order',
            'Relocate Service',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/residential-connection/fiber-takeover',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Fiber Takeover',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/residential-connection/enhance-fiber-takeover',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Residential Connection',
            'Enchance Fiber Takeover',
          ],
        },
      },

      {
        path: 'swp/ordermanagement/segmentConnection/building-mdf-room-to-fttb-node/create-order',
        component: CreateFttbNodeConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'Build MDF Room to FTTB Node',
            'Create Order',
          ],
        },
      },

      {
        path: 'swp/ordermanagement/non-residential-end-user/create-order',
        component: CreateNonResidentialEndUserComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Non Residential Connection',
            'Create order',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/non-residential-end-user/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Non Residential Connection',
            'Manage order',
          ],
        },
      },
      // {
      //   path: 'swp/ordermanagement/nbap-connection',
      //   component: CreateResidentialEndUserConnectionComponent,
      //   // canDeactivate:[CanDeactivateGuard],
      //   data: {
      //     breadcrumb: ['Order Management', 'NBAP Connection', 'Create order'],
      //   },
      // },
      {
        path: 'swp/ordermanagement/co-location-for-physical-access-manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: ['Order Management', 'NBAP Connection', 'Manage order'],
        },
      },
      {
        path: 'swp/ordermanagement/co-location-master-list',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          title: 'coLocMaster',
          breadcrumb: ['Order Management', 'Co-Lo', 'Master List Management'],
        },
      },
      {
        path: 'swp/ordermanagement/co-location-for-physical-access-create-order',
        component: CreateResidentialEndUserConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          title: 'coLocPhyAcc',
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Physical Access Procedure',
            'Create',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-location-service/create-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Co-Location Services',
            'Create',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-location-service/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Co-Location Services',
            'Manage',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/rl-to-rl-interconnection-services/create-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: ['Order Management', 'Co-Lo', 'rl-to-rl', 'Create'],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/rl-to-rl-interconnection-services/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: ['Order Management', 'Co-Lo', 'rl-to-rl', 'Manage'],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/co-location-cooling-services/create-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Cooling Services',
            'Create',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/co-location-cooling-services/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Cooling Services',
            'Manage',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/co-location-cooling-services/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Cooling Services',
            'Manage',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/co-location-equipment-installation-and-maintenance/create-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Co-Location Equipment Installation And Maintenance',
            'Create',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/co-lo/co-location-equipment-installation-and-maintenance/manage-order',
        component: CreateResidentialEndUserConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Co-Lo',
            'Co-Location Equipment Installation And Maintenance',
            'Manage',
          ],
        },
      },

      {
        path: 'swp/ordermanagement/non-residential-end-user',
        component: CreateNonResidentialEndUserComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: { breadcrumb: ['Order Management', 'Non Residential Connection', 'Create order'] }
      },
      {
        path: 'swp/ordermanagement/nbap-connection',
        component: CreateNBAPConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: { breadcrumb: ['Order Management', 'NBAP Connection', 'Create order'] }
      },
      //       {
      //         path: 'swp/ordermanagement/co-location-master-list',
      //         component: CoLoMasterListComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: {title:'coLocMaster', breadcrumb:['Order Management', 'Co-Lo', 'Master List Management']}

      //       },
      //       {
      //         path: 'swp/ordermanagement/co-location-for-physical-access',
      //         component: RequestForPhysicalAccessComponent ,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: {title:'coLocPhyAcc', breadcrumb:['Order Management','Co-Lo', 'Physical Access Procedure','Create']}

      //       },
      //       {
      //         path: 'swp/ordermanagement/create-patching-service',
      //         component: CreatePatchingServiceComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Patching Service', 'Create order'] }
      //       },.
      //       {
      //         path: 'swp/ordermanagement/manage-patching-service',
      //         component: ManagePatchingServiceComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Patching Service', 'Manage order'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/create-rao19',
      //         component: CreateRao19Component,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'RAO 19', 'Create order'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/manage-rao19',
      //         component: ManageOrderRao19Component,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'RAO 19', 'Manage order'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/create-rao20',
      //         component: CreateRao20Component,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'RAO 20', 'Create order'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/create-datacenter-to-datacenter',
      //         component: CreateDatacenterToDatacenterComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Datacenter to datacenter connection', 'Create order'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/manage-datacenter-to-datacenter',
      //         component: ManageDatacenterToDatacenterComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Datacenter to datacenter connection', 'Manage order'] }
      //       },

      {
        path: 'swp/ordermanagement/segmentConnection/fttb-node-to-dp-connection/create-order',
        component: CreateDpConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'FTTB Node to DP Connection',
            'Create Order'
          ]
        }
      },
      {
        path: 'swp/ordermanagement/segmentConnection/residential-premise-connection/create-order',
        component: CreateResidentialPremiseConnectionComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'Building MDF Room to Residential Premise Connection',
            'Create Order',
          ],
        },
      },

      {
        path: 
        'swp/ordermanagement/segmentConnection/co-co-connection/create-order',
        
        component: CreateCoConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: { breadcrumb: ['Order Management',
         'Segment Connection', 
         'Co-Co-Connection',
        'Create Order',
      ]
     }
      },
      {
        path: 'swp/ordermanagement/segmentConnection/co-building-mdf-connection/create-order',
        component: CreateCoToBuildingMdfConnectionComponent,
        // canDeactivate:[CanDeactivateGuard],
        data: {
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'Create-Co-Building-MDF-Connection',
            'Create Order'
          ]
        }
      },
      //       {
      //         path: 'swp/ordermanagement/Segment-Connection/point-to-point-connection/create-point-to-point-connection',
      //         component: CreatePointToPointConnectionComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Create-Point-to-Point-Connection'] }
      //       },
      //       {
      //         path: 'swp/ordermanagement/Segment-Connection/co-diversity-connection/create-co-diversity-connection',
      //         component: CreateCoDiversityConnectionComponent,
      //         // canDeactivate:[CanDeactivateGuard],
      //         data: { breadcrumb: ['Order Management', 'Segment Connection', 'Create-Co-Diversity-Connection'] }
      //       },

      {
        path: 'swp/ordermanagement/segmentConnection/building-mdf-room-to-nrpc/create-order',
        component: CreateNonResidentialPremisesConnectionComponent,
        data: {
          title: 's9',
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'Building MDF Room to Non-Residential Premise Connection',
            'Create Order',
          ],
        },
      },
      {
        path: 'swp/ordermanagement/segmentConnection/nbap-dp-connection/create-order',
        component: CreateCoToNbapDpConnectionComponent,
        data: {
          title: 's10',
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'CO to NBAP DP Connection',
            'Create Order'
          ]
        },
      },

      {
        path: 'swp/ordermanagement/segmentConnection/nbap-dp-to-tp-connection/create-order',
        component: CreateNbapTpConnectionComponent,
        data: {
          title: 's11',
          breadcrumb: [
            'Order Management',
            'Segment Connection',
            'NBAP DP to TP Connection',
            'Create Order'
          ]
        },
      },
      {
        path: 'swp/ordermanagement/fibreroutingmap',
        component: FibreRoutingMapComponent,
        data: {
          breadcrumb: [
            'Order Management',
            'Fibre Routing Map'
          ]
        },
      },

      {
        path: 'swp/ordermanagement/tprrr',
        component: TprrrComponent,
        data: { title: 'tprrr', breadcrumb: ['Order Management', 'TPRRR',] }
      },
      {
        path: 'swp/coverageCheck',
        component: AdvanceCoverageCheckComponent,
        data: { breadcrumb: [ 'Advance Coverage Check',"Check by Postal Code"] }
      },
      {
        path: 'swp/ordermanagement/sitesurvey/createorder',
        component: SiteSurveyComponent,
        data: { breadcrumb: [ 'Site Survey','Create Order'] }
      },

    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderManagementRoutingModule { }

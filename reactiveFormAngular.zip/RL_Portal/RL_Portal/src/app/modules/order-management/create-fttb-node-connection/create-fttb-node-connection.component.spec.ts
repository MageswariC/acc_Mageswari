import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateFttbNodeConnectionComponent } from './create-fttb-node-connection.component';

describe('CreateFttbNodeConnectionComponent', () => {
  let component: CreateFttbNodeConnectionComponent;
  let fixture: ComponentFixture<CreateFttbNodeConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateFttbNodeConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateFttbNodeConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
// import { AllShedule } from '../../integration/interface/forms/order-management/all-shedule';
import { buildMDFRoomToFTTBNodeModal } from '../../../modules/integration/modal/order-management/create-order/build-mdf-room-to-fttb-node.modal';
import fc from '../../../modules/integration/form-data/feasibility-check/fesibility-check-s6';
import fttbNodeConnectionForm from '../../../modules/integration/form-data/order-management/create-order/fttp-node-connection-formData';


@Component({
  selector: 'app-create-fttb-node-connection',
  templateUrl: './create-fttb-node-connection.component.html',
  styleUrls: ['./create-fttb-node-connection.component.scss']
})
export class CreateFttbNodeConnectionComponent implements OnInit {

  resiEndUserS6!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;
  buildMDFRoomToFTTBNode = {...buildMDFRoomToFTTBNodeModal};
  //Feasibility check input 
 fcInput: any;

 //form builder input
 formData: any;
 getFormControl: any;
 shedule1Model = buildMDFRoomToFTTBNodeModal;
  getFCFormControl: any;
  
  // async openModal() {
  //   return await this.modalComponent.open();
  // }

  // dpConnectionModal: DpConnectionS7 = { ...dpConnectionModal };
  constructor(private fb: FormBuilder, private toastrService: ToastrService, private router: Router) { }

  ngOnInit(): void {
    this.formData = fttbNodeConnectionForm;
    this.fcInput = fc;
    this.resiEndUserS6 = this.fb.group({})
    
  }
 
  getConfirmationValue(value: any) {
    if (value == 'Save click') {
      this.router.navigate(['swp/home']);
    }
  }
  getFCForm(form: any) {
    this.getFCFormControl = form.controls;
    console.log("get fc form control", form);
    console.log(this.getFCFormControl);
    
    
    
    // this.getFCFormControl?.orderOption.setValue('Postal Code')
    
  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
  fcFormValue(fcForm: any) {
    this.isFesibilityCheckClicked = true;
    // console.log("fc form", fcForm)
  }
  getFormVal(val: any) {
    this.router.navigate(['swp/home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }

  setReactiveFormValidator(control : any){
    this.getFCFormControl.feasibilityCheck.get(control).setValidators([Validators.required]);
    this.getFCFormControl.feasibilityCheck.get(control).updateValueAndValidity();
  }
  clearReactiveFormValidator(control : any){
    this.getFCFormControl.feasibilityCheck.get(control).clearValidators();
    this.getFCFormControl.feasibilityCheck.get(control).updateValueAndValidity();
    this.getFCFormControl.feasibilityCheck.get(control).reset();

  }
 
  changeOrderOption(obj:any) {
   
    
    // obj.fgroup.options.children.forEach((control:any)=>{
    //   if (control.key == 'orderOption'){
    //     console.log(obj.option.value); 
    //      console.log(this.getFCFormControl.get('postalCode'));
         
    //     if (obj.option.value === 'Postal Code'){
    //       this.getFCFormControl.get('postalCode').enable();
    //       this.getFCFormControl.get('fttbid').disable();
    //     }
    //     else{
    //       this.getFCFormControl.get('fttbid').enable();
    //       this.getFCFormControl.get('postalCode').disable();
    //     }
    //   }
      
    // })

    console.log("value",obj.option.value);
    
    fc.controls[0].options.children.forEach((field:any)=>{
      console.log("fields",field);
      
      if(obj.option.value==="Postal Code"){
        if(field.key==="postalCode"){
          field.visible=true;
          field.required=true;
          this.setReactiveFormValidator("postalCode");
         this.clearReactiveFormValidator("fttbid");
        }
        if(field.key==="fttbid"){
          field.visible=false;
          field.required=false;
        }
        
      }
      else{
        if(field.key==="postalCode"){
          field.visible=false;
          field.required=false;
          this.setReactiveFormValidator("fttbid");
         this.clearReactiveFormValidator("postalCode");
        }
        if(field.key==="fttbid"){
          field.visible=true;
          field.required=true;
        }

      }
    })
   
  }
  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'redundancyServiceoptions') {

        if (obj.option.value == 'No') {
          debugger;
          control.readOnly = true;
          control.required = false;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValue(null);
          this.getFormControl.orderDetails.get('redundancyServiceoptions').clearValidators();
        } else {
          debugger;
          control.readOnly = false;
          control.required = true;
          this.getFormControl.orderDetails.get('redundancyServiceoptions').setValidators([Validators.required]);
        }
        this.getFormControl.orderDetails.get('redundancyServiceoptions').updateValueAndValidity();
      }
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }
}

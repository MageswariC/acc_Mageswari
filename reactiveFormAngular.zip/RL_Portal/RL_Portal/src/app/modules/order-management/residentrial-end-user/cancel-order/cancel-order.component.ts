import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import cancelOrderForm from 'src/app/modules/integration/form-data/order-management/manage-order/cancel-order/cancel-order-formData';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import { Store } from '@ngrx/store';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
import { orderSubmission } from 'src/app/modules/integration/store/actions/residential-connection-create-order';
@Component({
  selector: 'app-cancel-order',
  templateUrl: './cancel-order.component.html',
  styleUrls: ['./cancel-order.component.scss']
})
export class CancelOrderComponent implements OnInit {

  formData: any;
  formValue:any;
  formModal:any;
  serviceOrderDetails:any;
  constructor(private router: Router, private toastrService: ToastrService, private formService:FormService, private fb: FormBuilder, private store:Store) { }

  ngOnInit() {
   
   this.formData = cancelOrderForm;
   this.store.select(manageOrderDetails).subscribe((data)=>{
    console.log("Mamam",data);
    if(data){
      this.serviceOrderDetails=data.serviceOrderDetails;
      this.formModal={
        cancelOrderDetails:data.serviceOrderDetails
      };
    }

   })
  }

  getFormVal(val:any){

    let cancelOrderPayload={
      rlInfo:{},
      orderType:"C",
      serviceOrderDetails:this.serviceOrderDetails
    }
    console.log("Cancel Payload",cancelOrderPayload);

    
 this.store.dispatch(orderSubmission({ payload:cancelOrderPayload }));


  }

}

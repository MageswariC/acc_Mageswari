import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import terminateOrder from 'src/app/modules/integration/form-data/order-management/manage-order/terminate-order/terminate-order-formData';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import { Store } from '@ngrx/store';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
import { orderSubmission } from 'src/app/modules/integration/store/actions/residential-connection-create-order';
@Component({
  selector: 'app-terminate-order',
  templateUrl: './terminate-order.component.html',
  styleUrls: ['./terminate-order.component.scss']
})
export class TerminateOrderComponent implements OnInit {

  formData: any;
  formValue:any;
  formModal:any;
  serviceOrderDetails:any;
  constructor(private router: Router, private toastrService: ToastrService, private formService:FormService, private fb: FormBuilder, private store:Store) { }

  ngOnInit() {
   
   this.formData = terminateOrder;
   this.store.select(manageOrderDetails).subscribe((data)=>{
    console.log("Mamam",data);
    if(data){
      this.serviceOrderDetails=data.serviceOrderDetails;
      this.formModal={
        terminateAppDetails:data.serviceOrderDetails
      };
    }

   })
  }

  getFormVal(val:any){

    let terminateOrderPayload={
      rlInfo:{},
      orderType:"T",
      serviceOrderDetails:this.serviceOrderDetails,
      formData:val
    }
    console.log("Terminate Payload",terminateOrderPayload);

    
 this.store.dispatch(orderSubmission({ payload:terminateOrderPayload }));


  }
}

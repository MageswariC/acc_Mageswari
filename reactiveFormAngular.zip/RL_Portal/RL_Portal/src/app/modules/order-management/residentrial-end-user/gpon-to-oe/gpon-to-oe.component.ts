import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { orderSubmission } from 'src/app/modules/integration/store/actions/residential-connection-create-order';

import { Store } from '@ngrx/store';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
import {

  getchargeInfo,
  getSelectedDateWithSlot,
} from 'src/app/modules/integration/store/selectors/order-management';

import gponToOe from 'src/app/modules/integration/form-data/order-management/manage-order/gpon-to-oe/gpon-to-oe-formData.ts';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { Subscription } from 'rxjs';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
//import { getSlots } from 'src/app/modules/integration/store/selectors/residential-connection-create-order';

@Component({
  selector: 'app-gpon-to-oe',
  templateUrl: './gpon-to-oe.component.html',
  styleUrls: ['./gpon-to-oe.component.scss'],
})
export class GponToOeComponent implements OnInit {
  formData: any;
  formValue!: any;
  selectedDate: any;
  getFormControl: any;
  selectedSlot: any;

  gponToOe: any;
  //getBundleName: any;
  getBundleName$!: Subscription;
  getPromoCode$!: Subscription;
  getchargeInfo$!: Subscription;
  getbookAppointmentStatus$!: Subscription;
  getSlots$!: Subscription;
  getCreateOrder$!: Subscription;
  getSelectedDateWithSlot$!: Subscription;
  slotRetrived: any;
  subscriptions: Subscription[] = [];
  brmBundleName: any;
  createOrder: any;
  serviceOrderDetails: any;
  orderFormValue: any;
  //businessOrderStatus: boolean;
  constructor(
    private router: Router,
    private formService: FormService,
    private store: Store,
    private toastrService: ToastrService,
    private orderManagementService: OrderManagementService
  ) {}

  ngOnInit(): void {
    this.formData = gponToOe;
    this.formValue = this.formService.getManageOrderData();
    this.storeSubscribeHandler();
    this.store.select(manageOrderDetails).subscribe((data) => {
      if (data.serviceOrderDetails) {
        let userDetails = {
          endUserDetails: {
            ...data.installationAddress,
            name: data.serviceOrderDetails.firstName,
            contactNumber: data.serviceOrderDetails.contactNumber,
            email: data.serviceOrderDetails.emailAddress,
          },
          appDetails: {
            orderReqIdentifier: data.activationDetails.ori,
            applicationRefNo: data.activationDetails.arnNo,
            dateOfApplication: data.installationAddress.dateOfActivation,
            tentativeProvisioningDate:
              data.installationAddress.dateOfActivation,
          },
          connectionDetails: {
            changeTechnology: data.orderDetails.technology,
            splitRatio: data.orderDetails.splitRatio,
            applicationRefNo: data.activationDetails.arnNo,
            preferredInstallSession: data.activationDetails.timeSlotOption,
            timeSlotOption: data.activationDetails.installationTime,
            reqDateOfActivation: data.installationAddress.dateOfActivation,
          },
        };

        this.formValue = userDetails;
      }
    });
  }
  storeSubscribeHandler() {
    this.getSelectedDateWithSlot$ = this.store
      .select(getSelectedDateWithSlot)
      .subscribe((dateWithSlot) => {
        if (dateWithSlot) {
          this.selectedDate = dateWithSlot;
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'activationDetails') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'installationTime') {
                  control.option = dateWithSlot.map((val: any) => {
                    return val.hours;
                  });
                }
              });
            }
          });
        }
      });
    // this.getBundleName$ = this.store
    //   .select(getBundleName)
    //   .subscribe((bundleName) => {
    //     if (bundleName) {
    //       this.GetChargeDetails(bundleName);
    //     }
    //   });
   

    this.getchargeInfo$ = this.store
      .select(getchargeInfo)
      .subscribe((chargeInfo) => {
        if (
          chargeInfo &&
          this.getFormControl &&
          chargeInfo.mrcAmt &&
          chargeInfo.otcAmt
        ) {
          this.getFormControl.summary

            .get('installationCharges')

            .setValue(chargeInfo.mrcAmt);
        }
      });

    //

    // this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
    //   // let slots = this.orderManagementService.availableSlots;
    //   this.slotRetrived = data.actualAPIResponse;
    //   let slots = data.formattedResponse;
    //   if (data.formattedResponse) {
    //     this.formData?.controls?.forEach((section: any) => {
    //       if (section.id == 'activationDetails') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'dateOfActivation') {
    //             let date = Object.keys(slots);
    //             control.dateFrom = [date[0]];
    //             control.dateTo = [date[date.length - 1]];
    //           }
    //         });
    //       }
    //     });
    //   }
    // });
    // this.getCreateOrder$ = this.store
    //   .select(getCreateOrder)
    //   .subscribe((order) => {
    //     this.createOrder = order;
    //   });
    this.subscriptions.push(
      this.getBundleName$,
      this.getPromoCode$,
      this.getchargeInfo$,
      this.getbookAppointmentStatus$,
      this.getSlots$,
      this.getCreateOrder$,
      this.getSelectedDateWithSlot$
    );
  }

  changeTechnology(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'splitRatio') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'GPON' && opt.value == '2:24') {
            opt.disable = true;
            this.getFormControl.connectionDetails.patchValue({
              splitRatio: '1:24',
            });
          } else {
            opt.disable = false;
          }
          if (obj.option.value == 'OE') {
            if (opt.value == '1:1' || opt.value == '1:24') {
              opt.disable = true;
              this.getFormControl.connectionDetails.patchValue({
                splitRatio: '2:24',
              });
            }
          }
        });
      }
    });

    let orderDetal = {
      technology: '',
      splitRatio: '',
      redundancyService: '',
    };
    this.getBundleDetail(orderDetal);
  }
  getForm(form: any) {
    this.getFormControl = form.controls;
  }
  spiltRatioChange(obj: any) {
    let technology = this.getFormControl.orderDetails.get('technology').value;
    let splitRatio = this.getFormControl.orderDetails.get('splitRatio').value;
    //let redundancyService = this.getFormControl.orderDetails.get('redundancyService').value;
    let orderInfo = {
      technology: technology,
      splitRatio: splitRatio,
      //redundancyService: redundancyService
    };
    this.getBundleDetail(orderInfo);
  }
  getBundleDetail(orderdetail: any) {
    // this.store.dispatch(
    //   bundleDetail({
    //     payload: {
    //       technology: orderdetail.technology,

    //       splitRatio: orderdetail.splitRatio,

    //       //redundancyService: orderdetail.redundancyService,
    //     },
    //   })
    // );
  }
  GetChargeDetails(bundleName: any) {
    this.brmBundleName = bundleName;

    // this.store.dispatch(
    //   chargeInfo({
    //     payload: {
    //       brmBundleName: bundleName,
    //     },
    //   })
    // );
  }

  onSubmitClick(val: any) {
    this.orderFormValue = val;
    let gponToOePayload = { ...this.orderFormValue };
    this.store.dispatch(orderSubmission({ payload: gponToOePayload }));
  }
}

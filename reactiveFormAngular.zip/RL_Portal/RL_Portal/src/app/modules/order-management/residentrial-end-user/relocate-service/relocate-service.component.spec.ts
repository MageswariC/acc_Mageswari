import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelocateServiceComponent } from './relocate-service.component';

describe('RelocateServiceComponent', () => {
  let component: RelocateServiceComponent;
  let fixture: ComponentFixture<RelocateServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelocateServiceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RelocateServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { FormService } from 'src/app/form.service';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import {
  bookAppointment,
  retiveSlots,
  selectedSlotSuccess,
} from 'src/app/modules/integration/store/actions/residential-connection-create-order';
import {
  getbookAppointmentStatus,
  getchargeInfo,
  getSelectedDateWithSlot,
} from 'src/app/modules/integration/store/selectors/order-management';
import relocateServiceForm from 'src/app/modules/integration/form-data/order-management/manage-order/relocate-service/relocate-service-formData'
import fc from '../../../integration/form-data/feasibility-check/fesibility-check';
import { clone } from 'src/app/components/utilities/util';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { feasibilityCheck } from 'src/app/modules/integration/store/actions/feasibility-check.action';
import { getCurrentRoute } from 'src/app/components/integration/store/selectors/router.selector';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
@Component({
  selector: 'app-relocate-service',
  templateUrl: './relocate-service.component.html',
  styleUrls: ['./relocate-service.component.scss']
})
export class RelocateServiceComponent implements OnInit {
  checkFeasibility: any;
  formData: any;
  formValue : any;
  initialManageTB: Boolean = true;
  public getFormControl: any;
  getSelectedDateWithSlot$: any;
  selectedDate: any;
  getBundleName$: any;
  brmBundleName: any;
  getbookAppointmentStatus$: any;
  getSlots$: any;
  slotRetrived: any;
  selectedSlot: any;
  rescheduleAppointment = false;
  manageTPValue: any;
  getchargeInfo$: any;
  fcInput: any;
  tieCableCheckStatus: any;
  showForm=true;
  unitNumber: any;
  postalCode: any;
  routerData: any;
  feasibilityCheckValue: any;
  fcFormControl: any;
  relocateServiceModal:any
  //relocateServiceValue!:AllShedule;

  constructor(private router: Router, private toastrService: ToastrService,
    private formService: FormService,
    private store: Store<DynamicComponentState>,
    private orderManagementService: OrderManagementService) { }

  ngOnInit(): void {
    this.store.select(getCurrentRoute).subscribe((state) => {
      this.routerData = state.data;
    });
     this.formData = relocateServiceForm;
     this.storeSubscribeHandler();
     this.checkFeasibility = relocateServiceForm;
    this.getFormControl = relocateServiceForm.controls;
    this.store.select(manageOrderDetails).subscribe((data)=>{
      console.log("Mamam",data);
      if(data){
        this.relocateServiceModal={
          toReqDetails:data.applicationDetails,
          existEndUserAddrDetails:data.endUserDetails,
          existingConnectionDetails:data.orderDetails
        }
      }
  
     })
   
    //this.relocateServiceValue = residentialConnectionModal;
  }
  

  relocateService(e:any) {
    // this.router.navigate(['swp/home']);
    // this.toastrService.success('Your request has been Terminated successfully', '');
  }

  getBundleDetail(orderdetail: any) {
    // this.store.dispatch(
    //   bundleDetail({
    //     payload: {
    //       technology: orderdetail.technology,
    //       splitRatio: orderdetail.splitRatio,
    //       redundancyService: orderdetail.redundancyService,
    //     },
    //   })
    // );
  }
  storeSubscribeHandler() {
    
    this.getSelectedDateWithSlot$ = this.store
      .select(getSelectedDateWithSlot)
      .subscribe((dateWithSlot) => {
        if (dateWithSlot) {
          
          this.selectedDate = dateWithSlot;
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'appointment') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'timeSlotOption') {
                  control.type = 'select';
                  control.option = dateWithSlot.map((val: any) => {
                    
                    return val.hours;
                  });
                }
              });
            }
          });
        }
      });
    // this.getBundleName$ = this.store
    //   .select(getBundleName)
    //   .subscribe((bundleName) => {
    //     if (bundleName) {
          
    //       this.GetChargeDetails(bundleName);
    //     }
    //   });
    this.getchargeInfo$ = this.store
      .select(getchargeInfo)
      .subscribe((chargeInfo) => {
        if (
          chargeInfo &&
          this.getFormControl &&
          chargeInfo.mrcAmt &&
          chargeInfo.otcAmt
        ) {
          console.log(chargeInfo);
          this.getFormControl.summary
            .get('installationCharges')
            .setValue(chargeInfo.mrcAmt);
          // this.getFormControl.priceDetails
          //   .get('otcAmt')
          //   .setValue(chargeInfo.otcAmt);
          // this.getFormControl.priceDetails.get('otcAmt').disable();
          // this.getFormControl.priceDetails
          //   .get('mrcAmt')
          //   .setValue(chargeInfo.mrcAmt);
          // this.getFormControl.priceDetails.get('mrcAmt').disable();
        }
        let tieCableCheck = {
          sheduleinfo: '',
          technology: '',
          splitRatio: '',
          postalCode: '',
          buildingHouseNo: '',
          unitNo: '',
          qpId: '123'
        }
        this.orderManagementService.getTieCableCheck(tieCableCheck).subscribe((data: any) => {
          this.store.dispatch(setLoadingSpinner({ status: false }));
          if (data.tieCableCheckStatus == 'Pass') {
            this.tieCableCheckStatus = data.tieCableCheckStatus
            this.generateORI();
            //Submit order
          }
        })
      });

    this.getbookAppointmentStatus$ = this.store
      .select(getbookAppointmentStatus)
      .subscribe((status) => {
        if (status == '0') {
          this.toastrService.success('Appointment Booked Successfully');
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'appointment') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'preferredInstallSession') {
                  control.option.forEach((option: any) => {
                    option.disable = true;
                  });
                }
                control.readOnly = true;
              });
            }
          });
          // this.getFormControl.activationDetails.get('timeSlotOption').disable();
          this.getFormControl.appointment
            .get('reqDateOfActivation')
            .disable();
        } else {
          //this.handleWFMStatus()
        }
      });

    // this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
    //   // let slots = this.orderManagementService.availableSlots;
    //   this.slotRetrived = data.actualAPIResponse;
    //   let slots = data.formattedResponse;
    //   if (data.formattedResponse) {
    //     this.formData?.controls?.forEach((section: any) => {
    //       // console.log(section);
    //       if (section.id == 'appointment') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'reqDateOfActivation') {
    //             let date = Object.keys(slots);
    //             control.dateFrom = [date[0]];
    //             control.dateTo = [date[date.length - 1]];
    //           }
    //         });
    //       }
    //     });
    //   }
    // });
  }
  GetChargeDetails(bundleName: any) {
    console.log(bundleName);

    this.brmBundleName = bundleName;

    // this.store.dispatch(
    //   chargeInfo({
    //     payload: {
    //       brmBundleName: bundleName,
    //     },
    //   })
    // );
  }
  storeselectedSlot() {
    console.log(this.getFormControl);
    let timeSlotOption =
      this.getFormControl.appointment.get('timeSlotOption').value;
    console.log(timeSlotOption);
    if (this.selectedDate) {
      this.selectedSlot = this.selectedDate.find((val: any) => {
        return val.hours == timeSlotOption;
      })?.slot;
    }
    this.store.dispatch(
      selectedSlotSuccess({
        data: {
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          timeZone: this.selectedSlot.timeZone,
          employee: this.selectedSlot.employee,
          slotList: this.slotRetrived,
        },
      })
    );
  }
  
  reverseAppointment(obj: any) {

    let orderDetal = {
      technology: '', //update values'
      splitRatio: '',
      redundancyService: '',
    };
    this.getBundleDetail(orderDetal);
    console.log(obj);
    
    console.log('Revese Appointment');
    if (this.rescheduleAppointment) {
      obj.fgroup.options.children.forEach((option: any) => {
        if (option.key == 'reverseAppointment') {
          // this.installationTimeChange(obj);
                    
          this.reverseAppointment1(obj);
        }
      });
    } else {
      this.formData?.controls?.forEach((section: any) => {
        if (section.id == 'appointment') {
          section?.options?.children.forEach((control: any) => {
            console.log(control.key);
            
            if (control.key == 'timeSlotOption') {
              control.readOnly = false;
              control.option = [];
            }
            if (control.key == 'preferredInstallSession') {
              control.option.forEach((option: any) => {
                option.disable = false;
              });
            }
            if (control.key == 'reverseAppointment') {
              control.value = 'Reverse Appointment';
              this.rescheduleAppointment = true;
               control.readOnly = true;
              // control.hidden = true;
            }
            if (control.key == 'reqDateOfActivation') {
              control.disableCalender = false;
            }
            // if (control.value == 'Reverse Appointment') {
            //   this.reverseAppointment1();
            // }
          });
        }
      });
      this.timeSlotOptionChange(obj);
    }

    // this.store.dispatch(
    //   bookAppointment({
    //     data: {
    //       externalSystemCode:
    //         this.orderManagementService.externalSystemCode('SO'),
    //       dateFrom: this.selectedSlot.dateFrom,
    //       dateTo: this.selectedSlot.dateTo,
    //       timeZone: this.selectedSlot.timeZone,
    //     },
    //   })
    // );
  }
  timeSlotOptionChange(obj: any) {
    console.log('Time Slot Option');

    this.getFormControl.appointment
      .get('timeSlotOption')
      .setValue(null);
    this.getFormControl.appointment
      .get('reqDateOfActivation')
      .setValue(null);
    let timeSlotOption =
      this.getFormControl.appointment.get('preferredInstallSession').value;
    this.getSlotList(timeSlotOption);
    // this.reverseAptBtnEnablementCheck();
  }
  getForm(form: any) {
   
    this.getFormControl = form.controls;
    
  }
  getSlotList(timeSlotOption: any) {
    let payload = {
      timeSlotOption: timeSlotOption,
      street: '',
      zip: '',
      profileName: this.orderManagementService.profileName('1', timeSlotOption),
    };
    this.store.dispatch(retiveSlots({ payload }));
  }
  // storeHandller() {
  //   this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
  //     // let slots = this.orderManagementService.availableSlots;
  //     this.slotRetrived = data.actualAPIResponse;
  //     let slots = data.formattedResponse;
  //     if (data.formattedResponse) {
  //       this.formData?.controls?.forEach((section: any) => {
  //         if (section.id == 'activationDetails') {
  //           section?.options?.children.forEach((control: any) => {
  //             if (control.key == 'dateOfActivation') {
  //               let date = Object.keys(slots);
  //               control.dateFrom = [date[0]];
  //               control.dateTo = [date[date.length - 1]];
  //             }
  //           });
  //         }
  //       });
  //     }
  //   });
  // }
  installationTimeChange(obj: any) {
    this.reverseAptBtnEnablementCheck();
  }
  reverseAptBtnEnablementCheck() {
    let installationTime =
      this.getFormControl?.appointment?.get('timeSlotOption').value;
    let dateOfActivation =
      this.getFormControl?.appointment?.get('reqDateOfActivation').value;
    this.formData?.controls?.forEach((section: any) => {
      if (section.id == 'appointment') {
        section?.options?.children.forEach((control: any) => {
          if (control.key == 'reverseAppointment') {
            installationTime && dateOfActivation
              ? (control.readOnly = false)
              : (control.readOnly = true);
          }
        });
      }
    });
    // this.reverseAppointment1();
  }
  reverseAppointment1(obj: any) {
    console.log('Revese Appointment1');
    this.storeselectedSlot();
    this.store.dispatch(
      bookAppointment({
        payload: {
          externalSystemCode:
            this.orderManagementService.externalSystemCode('SO'),
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          timeZone: this.selectedSlot.timeZone,
        },
      })
    );
  }
  
  generateORI() {
    let payload: any = {
      //address:this.installationAddress.buildingHouseNo+','+ this.installationAddress.buildingName+','+ this.installationAddress.streetName +','+ this.postalCode
      address: ''
    };
    //this.store.dispatch(generateORI({ payload }))
    console.log('generateORI');
    
  }
  feasabilityCheck(){

   this.postalCode= this.getFormControl.feasiblityCheck.get("postalCode").value;
   this.unitNumber= this.getFormControl.feasiblityCheck.get("unitNumber").value;
   // this.fcFormControl = formVal;
    //this.feasibilityCheckValue = formVal.value.feasibilityCheck;
    let payload:any = {
      postalCode:this.postalCode,
      unitNumber:this.unitNumber
    };

    // if (this.feasibilityCheckValue) {
    //   Object.keys(this.feasibilityCheckValue).forEach((key) => {
    //     if (this.feasibilityCheckValue[key]) {
    //       payload[key] = this.feasibilityCheckValue[key];
    //     }
    //     if (key == 'postalCode') {
    //       this.postalCode = this.feasibilityCheckValue[key];
    //     }
    //     if (key == 'unitNumber') {
    //       this.unitNumber = this.feasibilityCheckValue[key];
    //     }
    //   });
    // }
    payload['schedule'] = 'schedule 1';
    let sheduleinfo = this.routerData.sheduleInfo;
    payload['sheduleinfo'] = sheduleinfo;
    this.store.dispatch(feasibilityCheck({ payload }));
    if (this.postalCode && this.unitNumber) {
      // this.store.dispatch(
      //   postalCodeUnitNo({
      //     data: {
      //       postalCode: this.postalCode,
      //       unitNumber: this.unitNumber,
      //     },
      //   })
      // );
    }
    

    this.formData.controls.forEach((data:any)=>{

      if(data.key==="relocationAddrDetails" || data.key==="appointment" || data.key==="summary" ) {
        data.visible=true;
      }
     
    })
  }
  

}

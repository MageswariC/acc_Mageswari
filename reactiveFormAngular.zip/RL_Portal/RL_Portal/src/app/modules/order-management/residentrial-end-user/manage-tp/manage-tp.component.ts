import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { clone } from 'src/app/components/utilities/util';
import { FormService } from 'src/app/form.service';
import manageTP from 'src/app/modules/integration/form-data/order-management/manage-order/manage-tp/manage-tp-formData-menu';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import {
  bookAppointment,

  initialState,
  orderSubmission,
  retiveSlots,
  selectedSlotSuccess,
} from 'src/app/modules/integration/store/actions/residential-connection-create-order';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
import {
  getbookAppointmentStatus,
  
  getchargeInfo,

  getSelectedDateWithSlot,
} from 'src/app/modules/integration/store/selectors/order-management';
@Component({
  selector: 'app-manage-tp',
  templateUrl: './manage-tp.component.html',
  styleUrls: ['./manage-tp.component.scss'],
})
export class ManageTpComponent implements OnInit {
  checkFeasibility: any;
  formData: any;
  initialManageTB: Boolean = true;
  public getFormControl: any;
  getSelectedDateWithSlot$: any;
  selectedDate: any;
  getBundleName$: any;
  brmBundleName: any;
  getbookAppointmentStatus$: any;
  getSlots$: any;
  slotRetrived: any;
  selectedSlot: any;
  rescheduleAppointment = false;
  manageTPValue: any;
  getchargeInfo$: any;
  orderFormValue: any;
  getCreateOrder$: any;
  createOrder: any;
  subscriptions: any = [];
  splitRatio: any;
  redundancyService: any;
  street: any;
  zip: any;
  constructor(
    private router: Router,
    private formService: FormService,
    private toastrService: ToastrService,
    private store: Store<DynamicComponentState>,
    private orderManagementService: OrderManagementService
  ) {}
  ngOnInit(): void {
    this.formData = clone(manageTP);
    this.checkFeasibility = manageTP;
    this.getFormControl = manageTP.controls;
    this.store.select(manageOrderDetails).subscribe((data) => {
      if (data.orderDetails) {
        this.manageTPValue = data;
        this.splitRatio = data.orderDetails.splitRatio;
        this.redundancyService = data.orderDetails.redundancyService;
        this.street = data.installationAddress.streetName;
        this.zip = data.installationAddress.postalCode;
      }
    });
    this.storeSubscribeHandler();
  }
  orderManageTP(e: any) {
    this.initialManageTB = false;
  }
  getBundleDetail(orderdetail: any) {
    // this.store.dispatch(
    //   bundleDetail({
    //     payload: {
    //       technology: orderdetail.technology,
    //       splitRatio: orderdetail.splitRatio,
    //       redundancyService: orderdetail.redundancyService,
    //     },
    //   })
    // );
  }
  storeSubscribeHandler() {
    console.log('Store Handler');
    this.getSelectedDateWithSlot$ = this.store
      .select(getSelectedDateWithSlot)
      .subscribe((dateWithSlot) => {
        if (dateWithSlot) {
          console.log('Date Slot');
          this.selectedDate = dateWithSlot;
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'activationDetails') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'installationTime') {
                  control.type = 'select';
                  control.option = dateWithSlot.map((val: any) => {
                    return val.hours;
                  });
                }
              });
            }
          });
        }
      });
    // this.getBundleName$ = this.store
    //   .select(getBundleName)
    //   .subscribe((bundleName) => {
    //     if (bundleName) {
    //       console.log('bundleName', bundleName);
    //       this.GetChargeDetails(bundleName);
    //     }
    //   });
    this.getchargeInfo$ = this.store
      .select(getchargeInfo)
      .subscribe((chargeInfo) => {
        if (
          chargeInfo &&
          this.getFormControl &&
          chargeInfo.mrcAmt &&
          chargeInfo.otcAmt
        ) {
          console.log(chargeInfo);
          this.getFormControl.summary
            .get('installationCharges')
            .setValue(chargeInfo.mrcAmt);
        }
      });

    this.getbookAppointmentStatus$ = this.store
      .select(getbookAppointmentStatus)
      .subscribe((status) => {
        if (status == '0') {
          this.toastrService.success('Appointment Booked Successfully');
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'activationDetails') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'timeSlotOption') {
                  control.option.forEach((option: any) => {
                    option.disable = true;
                  });
                }
                control.readOnly = true;
              });
            }
          });
          this.getFormControl.activationDetails
            .get('dateOfActivation')
            .disable();
        } else {
        }
      });

    // this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
    //   this.slotRetrived = data.actualAPIResponse;
    //   let slots = data.formattedResponse;
    //   if (data.formattedResponse) {
    //     this.formData?.controls?.forEach((section: any) => {
    //       if (section.id == 'activationDetails') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'dateOfActivation') {
    //             let date = Object.keys(slots);
    //             control.dateFrom = [date[0]];
    //             control.dateTo = [date[date.length - 1]];
    //           }
    //         });
    //       }
    //     });
    //   }
    // });
    this.subscriptions.push(
      this.getBundleName$,
      this.getchargeInfo$,
      this.getbookAppointmentStatus$,
      this.getSlots$,
      this.getSelectedDateWithSlot$
    );
  }
  GetChargeDetails(bundleName: any) {
    this.brmBundleName = bundleName;
    // this.store.dispatch(
    //   chargeInfo({
    //     payload: {
    //       brmBundleName: bundleName,
    //     },
    //   })
    // );
  }
  storeselectedSlot() {
    let installationTime =
      this.getFormControl.activationDetails.get('installationTime').value;
    if (this.selectedDate) {
      this.selectedSlot = this.selectedDate.find((val: any) => {
        return val.hours == installationTime;
      })?.slot;
    }
    this.store.dispatch(
      selectedSlotSuccess({
        data: {
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          timeZone: this.selectedSlot.timeZone,
          employee: this.selectedSlot.employee,
          slotList: this.slotRetrived,
        },
      })
    );
  }
  reverseAppointment(obj: any) {
    if (this.rescheduleAppointment) {
      obj.fgroup.options.children.forEach((option: any) => {
        if (option.key == 'reverseAppointment') {
          this.reverseAppointment1(obj);
        }
      });
    } else {
      let orderDetal = {
        technology:
          this.getFormControl.activationDetails.get('timeSlotOption').value, //update values'
        splitRatio: this.splitRatio,
        redundancyService: this.redundancyService,
      };
      console.log(orderDetal);
      this.getBundleDetail(orderDetal);
      this.formData?.controls?.forEach((section: any) => {
        if (section.id == 'activationDetails') {
          section?.options?.children.forEach((control: any) => {
            if (control.key == 'installationTime') {
              control.readOnly = false;
              control.option = [];
            }
            if (control.key == 'timeSlotOption') {
              control.option.forEach((option: any) => {
                option.disable = false;
              });
            }
            if (control.key == 'reverseAppointment') {
              control.value = 'Reverse Appointment';
              this.rescheduleAppointment = true;
              control.readOnly = true;
            }
            if (control.key == 'dateOfActivation') {
              control.disableCalender = false;
            }
          });
        }
      });
      this.timeSlotOptionChange(obj);
    }
  }
  timeSlotOptionChange(obj: any) {
    this.getFormControl.activationDetails
      .get('installationTime')
      .setValue(null);
    this.getFormControl.activationDetails
      .get('dateOfActivation')
      .setValue(null);
    let timeSlotOption =
      this.getFormControl.activationDetails.get('timeSlotOption').value;
    this.getSlotList(timeSlotOption);
  }
  getForm(form: any) {
    console.log('Emit Form');
    this.getFormControl = form.controls;
    console.log(this.getFormControl);
  }
  getSlotList(timeSlotOption: any) {
    let payload = {
      timeSlotOption: timeSlotOption,
      street: this.street,
      zip: this.zip,
      profileName: this.orderManagementService.profileName('1', timeSlotOption),
    };
    this.store.dispatch(retiveSlots({ payload }));
  }
  installationTimeChange(obj: any) {
    this.reverseAptBtnEnablementCheck();
  }
  reverseAptBtnEnablementCheck() {
    let installationTime =
      this.getFormControl?.activationDetails?.get('installationTime').value;
    let dateOfActivation =
      this.getFormControl?.activationDetails?.get('dateOfActivation').value;
    this.formData?.controls?.forEach((section: any) => {
      if (section.id == 'activationDetails') {
        section?.options?.children.forEach((control: any) => {
          if (control.key == 'reverseAppointment') {
            installationTime && dateOfActivation
              ? (control.readOnly = false)
              : (control.readOnly = true);
          }
        });
      }
    });
  }
  onSubmitClick(val: any) {
    this.orderFormValue = val;
    let manageTPPayload = { ...this.orderFormValue };
    this.store.dispatch(orderSubmission({ payload: manageTPPayload }));
  }
  reverseAppointment1(obj: any) {
    this.storeselectedSlot();
    // this.store.dispatch(
    //   bookAppointment({
    //     data: {
    //       externalSystemCode:
    //         this.orderManagementService.externalSystemCode('SO'),
    //       dateFrom: this.selectedSlot.dateFrom,
    //       dateTo: this.selectedSlot.dateTo,
    //       timeZone: this.selectedSlot.timeZone,
    //     },
    //   })
    // );
  }
  ngOnDestroy() {
    this.subscriptions.forEach((subscription: any) =>
      subscription.unsubscribe()
    );
    // this.subscription.unsubscribe();
    this.store.dispatch(initialState());
  }
}

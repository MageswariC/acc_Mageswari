import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormService } from 'src/app/modules/integration/service/order-management/form.service';
// import { FormService } from 'src/app/components/integration/service/component/form.service';
import  residentialEndUserConnectionForm   from 'src/app/modules/integration/form-data/order-management/manage-order/modify-order/residential-end-user-connection-formData';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { getCurrentRoute } from 'src/app/components/integration/store/selectors/router.selector';
import { Subscription } from 'rxjs';
// import { getbookAppointmentStatus, getBundleName, getchargeInfo, getPromoCode, getSelectedDateWithSlot, getSlots } from 'src/app/modules/integration/store/selectors/residential-connection-create-order';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { bookAppointment, initialState, orderSubmission, retiveSlots, selectedSlotSuccess } from 'src/app/modules/integration/store/actions/residential-connection-create-order';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { getbookAppointmentStatus, getchargeInfo, getSelectedDateWithSlot } from 'src/app/modules/integration/store/selectors/order-management';
import { manageOrderDetails } from 'src/app/modules/integration/store/selectors/manage-order.selectors';
// import {residentialconnection}

@Component({
  selector: 'app-modify-order',
  templateUrl: './modify-order.component.html',
  styleUrls: ['./modify-order.component.scss']
})
export class ModifyOrderComponent implements OnInit {

  resiEndUserS1!: FormGroup;

  formData: any;
  formValue:any;
  modifyValue: any;
  routerData: any;
  selectedDate: any;
 public getFormControl: any;
  fcFormControl: any;
  slotRetrived: any;
  selectedSlot: any;
  brmBundleName: any;
  rescheduleAppointment:any;
  // installationAddress:any
  //subscription
  getSelectedDateWithSlot$!: any;
  getbookAppointmentStatus$!: any;
  getSlots$!: any;
  getBundleName$!: any;
  installationAddress: any;
  getPromoCode$: any;
  getchargeInfo$: any;
  orderFormValue: any;
  createOrder: any;
  //modal
  //Modal
  modalTitle: any;
  modalBody: any;
  modalVisibilty = false;
  modalOkFunction: any = null;
  getCreateOrder$: any;
  formValuePayload: any;
  exisORI:any;
  subscriptions: any=[];
  constructor(
    private router: Router,
    private formService:FormService,
    private fb: FormBuilder,
    private store: Store<DynamicComponentState>,
    private toastrService: ToastrService,
    private orderManagementService: OrderManagementService) 
    { }

  ngOnInit(): void {
    // this.store.select(getCurrentRoute).subscribe(state => {
    //   this.routerData = state.data;
    // })
   this.formData = residentialEndUserConnectionForm;
  //  this.formValue =  this.formService.getManageOrderData();
   this.getFormControl = residentialEndUserConnectionForm.controls;
   console.log("form data taking control for display",this.getFormControl)
   this.resiEndUserS1 = this.fb.group({});
   console.log("form group display check", this.resiEndUserS1);
    //  this.modifyValue = this.formValue;
    // this.storeInstallationAddress;
    this.store.select(manageOrderDetails).subscribe((data:any) => {
      console.log('Mamam', data);
      if (data) {
        this.exisORI=data.existingORI;
        console.log("Data values",data);
        let insta = {
          installationAddress : {...data.serviceOrderDetails},
          orderDetails : {...data.orderDetails},
          endUserDetails: {...data.endUserDetails},
          priceDetails: {...data.priceDetails}
          // exisORI: {...}
        }
        
        this.modifyValue = insta;
      }
    });
   this.storeSubscribeHandler();
  //  const residentialConnectionModal = {

  //     installationAddress: {
  //       buildingName: 'OLEANDER BREEZE',
  //       streetName: 'YISHUN STREET 51',
  //       unitNumber: '#01-01',
  //       postalCode: '504302',
  //       buildingType: 'HDB',
  //       coverageStatus: 'Home Reached',
  //       copifType: 'Pre-Copif',
  //       dataCenter: 'data',
  //       networkStatus: '1223',
  //       tpName: '123',
  //     },
  //     orderDetails : {
  //       appRefIdentifier:'ST/ON/12A/1312/001',
  //       technology : 'GPON',
  //       splitRatio : '1:1',  
  //     },


  //   };
    // this.modifyValue=residentialConnectionModal;
  }
  storeSubscribeHandler() {
    this.getSelectedDateWithSlot$ = this.store
      .select(getSelectedDateWithSlot)
      .subscribe((dateWithSlot) => {
        if (dateWithSlot) {
          this.selectedDate = dateWithSlot;
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'activationDetails') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'installationTime') {
                  control.type = 'select';
                  control.option = dateWithSlot.map((val: any) => {
                    console.log(val.hours);

                    return val.hours;
                  });
                }
              });
            }
          });
        }
      });
    // this.getBundleName$ = this.store
    //   .select(getBundleName)
    //   .subscribe((bundleName) => {
    //     if (bundleName) {
    //       console.log('bundleName', bundleName);
    //       this.GetChargeDetails(bundleName);
    //     }
    //   });
  

    // this.getchargeInfo$ = this.store
    //   .select(getchargeInfo)
    //   .subscribe((chargeInfo) => {
    //     if (
    //       chargeInfo &&
    //       this.getFormControl &&
    //       chargeInfo.mrcAmt &&
    //       chargeInfo.otcAmt
    //     ) {
    //       this.getFormControl.priceDetails
    //         .get('otcAmt')
    //         .setValue(chargeInfo.otcAmt);
    //       this.getFormControl.priceDetails.get('otcAmt').disable();
    //       this.getFormControl.priceDetails
    //         .get('mrcAmt')
    //         .setValue(chargeInfo.mrcAmt);
    //       this.getFormControl.priceDetails.get('mrcAmt').disable();
    //     }
    //   });
    this.getchargeInfo$ = this.store.select(getchargeInfo).subscribe((chargeInfo) => {
        if (
          chargeInfo &&this.getFormControl &&chargeInfo.mrcAmt &&chargeInfo.otcAmt
          ) {

          console.log(chargeInfo);

          this.getFormControl.priceDetails.get('installationCharge').setValue(chargeInfo.mrcAmt);
          this.getFormControl.priceDetails.get('serviceActivationCharge').setValue(chargeInfo.otcAmt);

          // this.getFormControl.priceDetails

          //   .get('otcAmt')

          //   .setValue(chargeInfo.otcAmt);

          // this.getFormControl.priceDetails.get('otcAmt').disable();

          // this.getFormControl.priceDetails

          //   .get('mrcAmt')

          //   .setValue(chargeInfo.mrcAmt);

          // this.getFormControl.priceDetails.get('mrcAmt').disable();

        }

      });

    this.getbookAppointmentStatus$ = this.store
      .select(getbookAppointmentStatus)
      .subscribe((status) => {
        if (status == '0') {
          this.toastrService.success('Appointment Booked Successfully');
          this.formData?.controls?.forEach((section: any) => {
            if (section.id == 'activationDetails') {
              section?.options?.children.forEach((control: any) => {
                if (control.key == 'timeSlotOption') {
                  control.option.forEach((option: any) => {
                    option.disable = true;
                  });
                }
                control.readOnly = true;
              });
            }
          });
          // this.getFormControl.activationDetails.get('timeSlotOption').disable();
          this.getFormControl.activationDetails
            .get('dateOfActivation')
            .disable();
        } else {
          //this.handleWFMStatus()
        }
      });

    // this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
    //   // let slots = this.orderManagementService.availableSlots;
    //   this.slotRetrived = data.actualAPIResponse;
    //   let slots = data.formattedResponse;
    //   if (data.formattedResponse) {
    //     this.formData?.controls?.forEach((section: any) => {
    //       // console.log(section);
    //       if (section.id == 'activationDetails') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'dateOfActivation') {
    //             let date = Object.keys(slots);
    //             control.dateFrom = [date[0]];
    //             control.dateTo = [date[date.length - 1]];
    //           }
    //         });
    //       }
    //     });
    //   }
    // });

    // this.getCreateOrder$ = this.store
    //   .select(getCreateOrder)
    //   .subscribe((order) => {
    //     this.createOrder = order;
    //     console.log(' this.createOrder', this.createOrder);
    //   });
      this.subscriptions.push(
        this.getBundleName$,
        this.getchargeInfo$,
        this.getbookAppointmentStatus$,
        this.getSlots$,
        this.getSelectedDateWithSlot$
      );
    // this.subscriptions.push;
    //   this.getBundleName$,
    //   this.getPromoCode$,
    //   this.getchargeInfo$,
    //   this.getbookAppointmentStatus$,
    //   this.getSlots$,
    //   this.getCreateOrder$,
    //   this.getSelectedDateWithSlot$();
  }
  // storeInstallationAddress(installationDetails: any) {
  //   if (installationDetails) this.installationAddress = installationDetails;

  //   this.store.dispatch(installationDetail({
  //     data: {
  //       buildingType: installationDetails.buildingType,
  //       feasibilityNote: installationDetails.feasibilityNote,
  //       streetName: 'YISHUN STREET 6',
  //       buildingName: installationDetails.buildingName,
  //       buildingHouseNo: installationDetails.buildingHouseNo,
  //       feasibilityStatus: installationDetails.feasibilityStatus,
  //       copifType: installationDetails.copifType
  //     }
  //   }))
  //   this.modifyValue = { installationDetails };
  //    this.store.dispatch(promoCode());

  // }

  GetChargeDetails(bundleName: any) {
    this.brmBundleName = bundleName;

    // this.store.dispatch(
    //   chargeInfo({
    //     payload: {
    //       brmBundleName: bundleName,
    //     },
    //   })
    // );
  }
  storeselectedSlot() {
    console.log(this.getFormControl);
    let installationTime =
      this.getFormControl.activationDetails.get('installationTime').value;
    console.log(installationTime);
    if (this.selectedDate) {
      this.selectedSlot = this.selectedDate.find((val: any) => {
        return val.hours == installationTime;
      })?.slot;
    }
    this.store.dispatch(
      selectedSlotSuccess({
        data: {
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          timeZone: this.selectedSlot.timeZone,
          employee: this.selectedSlot.employee,
          slotList: this.slotRetrived,
        },
      })
    );
  }
  getBundleDetail(orderdetail: any) {
    console.log("second, in getBundleDetail");
    
    // this.store.dispatch(
    //   bundleDetail({
    //     payload: {
    //       technology: orderdetail.technology,
    //       splitRatio: orderdetail.splitRatio,
    //       redundancyService: orderdetail.redundancyService,
    //     },
    //   })
    // );
  }
  reverseAppointment(obj: any) {
    console.log('first, Reschedule Appointment, then call dispacth BundleDetail');
    let orderDetal = {
      technology: '', //update values'
      splitRatio: '',
      redundancyService: '',
    };
    this.getBundleDetail(orderDetal);

    if (this.rescheduleAppointment) {
      obj.fgroup.options.children.forEach((option: any) => {
        if (option.key == 'reverseAppointment') {
          // this.installationTimeChange(obj);
          this.reverseAppointment1(obj);
        }
      });
    } else {
      this.formData?.controls?.forEach((section: any) => {
        if (section.id == 'activationDetails') {
          section?.options?.children.forEach((control: any) => {
            if (control.key == 'installationTime') {
              control.readOnly = false;
              control.option = [];
            }
            if (control.key == 'timeSlotOption') {
              control.option.forEach((option: any) => {
                option.disable = false;
              });
            }
            if (control.key == 'reverseAppointment') {
              control.value = 'Reverse Appointment';
              this.rescheduleAppointment = true;
              // control.readOnly = true;
              // control.hidden = true;
            }
            if (control.key == 'dateOfActivation') {
              control.disableIcon = false;
            }
            // if (control.value == 'Reverse Appointment') {
            //   this.reverseAppointment1();
            // }
          });
        }
      });
      this.timeSlotOptionChange(obj);
    }

    // this.store.dispatch(
    //   bookAppointment({
    //     data: {
    //       externalSystemCode:
    //         this.orderManagementService.externalSystemCode('SO'),
    //       dateFrom: this.selectedSlot.dateFrom,
    //       dateTo: this.selectedSlot.dateTo,
    //       timeZone: this.selectedSlot.timeZone,
    //     },
    //   })
    // );
  }
  timeSlotOptionChange(obj: any) {
    console.log('Third,Time Slot Option, then call getSlotList');

    this.getFormControl.activationDetails
      .get('installationTime')
      .setValue(null);
    this.getFormControl.activationDetails
      .get('dateOfActivation')
      .setValue(null);
    let timeSlotOption =
      this.getFormControl.activationDetails.get('timeSlotOption').value;
    this.getSlotList(timeSlotOption);
    // this.reverseAptBtnEnablementCheck();
  }
  getForm(form: any) {
    // console.log('Emit Form');
    this.getFormControl = form.controls;
    // console.log(this.getFormControl);
  }
  getSlotList(timeSlotOption: any) {
    console.log("Fourth,In getSlotList");
    
    let payload = {
      timeSlotOption: timeSlotOption,
      street: '',
      zip: '',
      profileName: this.orderManagementService.profileName('1', timeSlotOption),
    };
    this.store.dispatch(retiveSlots({ payload }));
  }
  storeHandller() {
    // this.getSlots$ = this.store.select(getSlots).subscribe((data) => {
    //   // let slots = this.orderManagementService.availableSlots;
    //   this.slotRetrived = data.actualAPIResponse;
    //   let slots = data.formattedResponse;
    //   if (data.formattedResponse) {
    //     this.formData?.controls?.forEach((section: any) => {
    //       if (section.id == 'activationDetails') {
    //         section?.options?.children.forEach((control: any) => {
    //           if (control.key == 'dateOfActivation') {
    //             let date = Object.keys(slots);
    //             control.dateFrom = [date[0]];
    //             control.dateTo = [date[date.length - 1]];
    //           }
    //         });
    //       }
    //     });
    //   }
    // });
  }
  installationTimeChange(obj: any) {
    this.reverseAptBtnEnablementCheck();
  }
  reverseAptBtnEnablementCheck() {
    let installationTime =
      this.getFormControl?.activationDetails?.get('installationTime').value;
    let dateOfActivation =
      this.getFormControl?.activationDetails?.get('dateOfActivation').value;
    this.formData?.controls?.forEach((section: any) => {
      if (section.id == 'activationDetails') {
        section?.options?.children.forEach((control: any) => {
          if (control.key == 'reverseAppointment') {
            installationTime && dateOfActivation
              ? (control.readOnly = false)
              : (control.readOnly = true);
          }
        });
      }
    });
    // this.reverseAppointment1();
  }
  reverseAppointment1(obj: any) {
    console.log('Reserve Appointment1');
    this.storeselectedSlot();
    this.store.dispatch(
      bookAppointment({
        payload: {
          externalSystemCode:
            this.orderManagementService.externalSystemCode('SO'),
          dateFrom: this.selectedSlot.dateFrom,
          dateTo: this.selectedSlot.dateTo,
          timeZone: this.selectedSlot.timeZone,
        },
      })
    );
  }
  onSubmitClick(val: any) {
    this.orderFormValue = val;
    console.log("formvalue",val);
    let amendPayload= {
      existingORI : this.exisORI,
      reason : 'Modifying Data',
      revision : '1000',
      terminationDate : '1/20/2023',
      rfsDate : 'anything',
      rfa : 'anything',
    }
    // this.formValuePayload= this.orderFormValue;
    this.formValuePayload={...this.orderFormValue,...amendPayload};
    console.log("last payload",this.formValuePayload);
    
    
    // const {
    //   installationDetails, endUserDetails, orderDetails, activationDetails, additionalInfo } = this.createOrder;
    //   console.log("Here in submit",this.createOrder);
    //   //
    // const payload = {
    //   ... this.createOrder,
    //   // installationDetails: { ...installationDetails, ... this.orderFormValue.installationDetails },
    //   endUserDetails: { ...endUserDetails, ... this.orderFormValue.endUserDetails },
    //   orderDetails: { ...orderDetails, ... this.orderFormValue.orderDetails.appRefIdentifier },
    //   activationDetails: { ...activationDetails, ... this.orderFormValue.activationDetails, reverseAppointment: undefined },
    //   additionalInfo: { ...additionalInfo, ... this.orderFormValue.additionalInfo }
    // }
    // console.log(payload);
    
    this.store.dispatch(orderSubmission({ payload: this.formValuePayload }));
  }
  onCancelClick() {
    let successMsg: any = {
      title: 'Confirmation',
      body: "Are you sure you want to cancel the changes?",
      okFunction: "CancelEvent"
    };
    this.setModal(successMsg);
  }
  setModal(modalData: any) {
    this.modalBody = modalData.body;
    this.modalTitle = modalData.title;
    this.modalVisibilty = true;
    this.modalOkFunction = modalData.okFunction;
  }
  ngOnDestroy() {
    this.subscriptions.forEach((subscription: any) =>
      subscription.unsubscribe()
    );
    // this.subscription.unsubscribe();
    this.store.dispatch(initialState());
  }
 
}
function setValue(otcAmt: String) {
  throw new Error('Function not implemented.');
}
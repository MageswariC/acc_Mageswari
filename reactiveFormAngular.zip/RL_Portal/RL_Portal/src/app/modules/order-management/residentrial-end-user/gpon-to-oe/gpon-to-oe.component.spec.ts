import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GponToOeComponent } from './gpon-to-oe.component';

describe('GponToOeComponent', () => {
  let component: GponToOeComponent;
  let fixture: ComponentFixture<GponToOeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GponToOeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GponToOeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

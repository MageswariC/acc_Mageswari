import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminateOrderComponent } from './terminate-order.component';

describe('TerminateOrderComponent', () => {
  let component: TerminateOrderComponent;
  let fixture: ComponentFixture<TerminateOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminateOrderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TerminateOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

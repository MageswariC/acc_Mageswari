import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonResidentialEndUserComponent } from './non-residential-end-user.component';

describe('NonResidentialEndUserComponent', () => {
  let component: NonResidentialEndUserComponent;
  let fixture: ComponentFixture<NonResidentialEndUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NonResidentialEndUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NonResidentialEndUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


import { Component, OnDestroy, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import fesibilityForm from '../../integration/form-data/feasibility-check/fesibility-check';
import nonResidentialEndUserFormData from '../../integration/form-data/order-management/create-order/non-residential-end-user-connection-formData';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { setLoadingSpinner } from 'src/app/components/integration/store/actions/loading-spinner.action';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import {
  feasibilityCheck,
  feasibilityReset,
} from 'src/app/modules/integration/store/actions/feasibility-check.action';

import { getFeasibilityRes } from 'src/app/modules/integration/store/selectors/feasibility-check.selectors';
import { FeasibilityCheckService } from 'src/app/modules/integration/service/order-management/feasibility-check.service';
import { clone } from 'src/app/components/utilities/util';
import validation from 'src/app/modules/integration/utilities/validation';
import { getCurrentRoute } from 'src/app/components/integration/store/selectors/router.selector';
import AddressNotFoundFormData from 'src/app/modules/integration/form-data/order-management/create-order/Address-Not-Found';

import {
  bookAppointment,
  loadBundleName,
  initialState,
  orderSubmission,
  retiveSlots,
} from 'src/app/modules/integration/store/actions/residential-connection-create-order';
import {
  getbookAppointmentStatus,
  getBundleNameWithCharge,
  getAvailableDates,
  getSelectedDateWithSlot,
} from 'src/app/modules/integration/store/selectors/order-management';
import { FeasibilityRequest } from 'src/app/modules/integration/store/state/feasibility-check.state';
import { ServiceOrder } from 'src/app/modules/integration/interface/forms/common/service-order-detail-interface';
@Component({
  selector: 'app-non-residential-end-user',
  templateUrl: './non-residential-end-user.component.html',
  styleUrls: ['./non-residential-end-user.component.scss']
})
export class CreateNonResidentialEndUserComponent
implements OnDestroy,OnInit{
  resiEndUserS1!: FormGroup;
  routerData: any;
  isFesibilityCheckDone: Boolean = false;

  //Modal
  // modalTitle: any;
  // modalBody: any;
  modalVisibilty = false;
  // modalOkFunction: any = null;
  //modalObj
  modalObj = {
    modalTitle: '',
    modalBody: '',
    cancelRequired: false,
    modalOkFunction: null
  }
  //Feasibility check input
  fcInput: any;

  //form builder input
  formData: any;
  getFormControl: any;
  fcFormControl: any;
  shedule2Modal: any;
  postalCode: any;
  unitNumber: any;
  installationAddress: any;
  orderFormValue: any = null;
  subscription: any;
  // brmBundleName: any;
  feasibilityCheckValue: any;
  createOrder: any;
  getBundleNameCharge$!: Subscription;


  getbookAppointmentStatus$!: Subscription;
  getAvailableDates$!: Subscription;

  getSelectedDateWithSlot$!: Subscription;
  slotRetrived: any;
  subscriptions: Subscription[] = [];

  constructor(
    private store: Store<DynamicComponentState>,
    private orderManagementService: OrderManagementService,
    private feasibilityCheckService: FeasibilityCheckService,
    private fb: FormBuilder,
    private router: Router,
    private toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    this.store.select(getCurrentRoute).subscribe((state) => {
      this.routerData = state.data;
    });
    this.fcInput = clone(fesibilityForm);
    this.resiEndUserS1 = this.fb.group({});
    this.store.dispatch(feasibilityReset());
    this.storeSubscribeHandler();
    this.subscription = this.store
      .select(getFeasibilityRes)
      .subscribe((data) => {
        if (data.isFeasibilityDataFetched) {
          this.feasibilityCheckService.responseSenarioCheck(
            data.feasibilityResponse,
            (mode: string) => {
              switch (mode) {
                case 'ListOfBlocksAndUnits':
                  this.updateBlocksAndUnits(
                    data.feasibilityResponse.listOfUnits,
                    data.feasibilityResponse.listOfBlocks
                  );
                  break;
                case 'BuildingDemolishing':
                  this.buildingDemotionFlow();
                  break;
                case 'Diversion':
                  this.installationAddress = data.feasibilityResponse;
                  this.diversionFlow();
                  break;
                case 'USO':
                  if (data.feasibilityResponse)
                    this.installationAddress = data.feasibilityResponse;
                  this.addressNotFoundFlow();
                  break;
                default:
                  console.log('default code');
                  if (data.feasibilityResponse)
                    this.installationAddress = data.feasibilityResponse;
                  this.nextStepOfFeasibilityCheck( this.installationAddress);
              }
            }
          );
        }
      });
  }
  storeSubscribeHandler() {
   
    this.getBundleNameCharge$ = this.store
      .select(getBundleNameWithCharge)
      .subscribe((bundleName) => {
        if (bundleName) {
          this.loadPriceDetails(bundleName);
        }
      });




    this.subscriptions.push(
      this.getBundleNameCharge$,
    );
  }
  updateBlocksAndUnits(units: any, blocks: any) {
    this.fcInput = clone(fesibilityForm);
    this.fcInput.controls[0].isFcBtnrequired = true;
    this.fcInput.controls[0].options.children.forEach((ele: any) => {
      if (ele.key == 'unitNumber') {
        ele.required = true;
        ele.visible = true;
        ele.option = units;
        this.fcFormControl.controls.feasibilityCheck
          .get('unitNumber')
          .setValidators([Validators.required, validation.unitNumber()]);
        this.fcFormControl.controls.feasibilityCheck
          .get('unitNumber')
          .updateValueAndValidity();
      }
      if (ele.key == 'buildingNumber') {
        ele.required = true;
        ele.visible = true;
        ele.option = blocks;
        this.fcFormControl.controls.feasibilityCheck
          .get('buildingNumber')
          .setValidators([Validators.required]);
        this.fcFormControl.controls.feasibilityCheck
          .get('buildingNumber')
          .updateValueAndValidity();
      }
      if (ele.key == 'postalCode') {
        ele.required = true;
        ele.visible = true;
        ele.defaultValue = this.postalCode;
        this.fcFormControl.controls.feasibilityCheck
          .get('postalCode')
          .setValidators([Validators.required]);
        this.fcFormControl.controls.feasibilityCheck
          .get('postalCode')
          .updateValueAndValidity();
      }
    });
  }


  nextStepOfFeasibilityCheck(installationDetails: any) {
    this.fcFormControl.disable();
    this.formData = clone(nonResidentialEndUserFormData);
    this.isFesibilityCheckDone = true;
    this.fcInput.controls[0].hide = true;
    this.storeInstallationAddress(installationDetails);
  }
  noFRCReadiness() {
    let successMsg: any = {
      title: 'No FRC Readiness',
      body: 'SWP-021 - error code description',
      okFunction: 'noFRCReadiness',
    };
    this.setModal(successMsg);
  }
  addressNotFoundFlow() {
    console.log('feasibilityNoteUSO');
    let successMsg: any = {
      title: 'USO',
      body: 'SWP-021 - error code description',
      okFunction: 'USO',
    };
    this.setModal(successMsg);
  }
  checkFeasibility(formVal: any, type: any) {
    // this.fcFormControl = formVal;
    this.feasibilityCheckValue = formVal;
    let feasibilityRequest: FeasibilityRequest = {};
    let obj: any = {};
    if (this.feasibilityCheckValue) {

      if (type == 'btnCheck') {
        Object.keys(this.feasibilityCheckValue).forEach((key) => {
          if (this.feasibilityCheckValue[key]) {
            obj[key] = this.feasibilityCheckValue[key];
          }
          if (key == 'postalCode') {
            this.postalCode = this.feasibilityCheckValue[key];
          }
          if (key == 'unitNumber') {
            this.unitNumber = this.feasibilityCheckValue[key];
          }
        });
      } else if (type == 'postalCodeCheck') {
        obj['postalCode'] = this.feasibilityCheckValue;

      }
    }
    feasibilityRequest.feasibilityRequestDTO = obj;
    feasibilityRequest.scheduleInfo = this.routerData.sheduleInfo;
    this.store.dispatch(feasibilityCheck({ payload: feasibilityRequest }));

  }
  checkFeasibilityBtnClick(formVal: any) {
    this.checkFeasibility(formVal.feasibilityCheck, 'btnCheck')
  }
  postalCodeChange(obj: any) {
    this.fcInput.controls[0].isFcBtnrequired = false;
    this.fcInput.controls[0].options.children.forEach((ele: any) => {
      if (ele.key == 'unitNumber') ele.visible = false;
      if (ele.key == 'buildingNumber') ele.visible = false;

    });
    if (this.fcFormControl.controls.feasibilityCheck.get('postalCode').valid) {
      this.postalCode = this.fcFormControl.controls.feasibilityCheck.get('postalCode').value;
      this.checkFeasibility(this.fcFormControl.controls.feasibilityCheck.get('postalCode').value, 'postalCodeCheck')

    }
  }
  getForm(form: FormGroup) {
    console.log('Get FOrm');
    this.getFormControl = form.controls;
    let orderInfo = {
      technology: this.getFormControl.orderDetails.get('technology').value,
      splitRatio: this.getFormControl.orderDetails.get('splitRatio').value,
      redundancyService:
        this.getFormControl.orderDetails.get('redundancyService').value,
    };
    this.chargeDetails(orderInfo);
  }
  getFC(form: FormGroup) {
    this.fcFormControl = form;
  }

  storeInstallationAddress(installationDetails: any) {
    if (installationDetails) this.installationAddress = installationDetails;
    this.shedule2Modal = { installationDetails };
    let payload: any = {
      scheduleInfo: {
        scheduleCode: "02"
      },
      loadCreateOrder: {
        billingAccountNumber: "34",
        serviceType: "P2PCO"
      }
    }
    this.orderManagementService.getPromoCode(payload).subscribe(response => {
      this.formData?.controls?.forEach((section: any) => {
        if (section.id == 'orderDetails') {
          section?.options?.children.forEach((control: any) => {
            if (control.key == 'promoCode') {
              let promoCodes: any[] = []
              response.promoCode.caeligiblityList.map((ele: any) => {
                promoCodes.push(ele.promoCode)
              })
              control.option = promoCodes;
            }
          });
        }
      });
    })
  }

  chargeDetails(orderdetail: any) {
    this.store.dispatch(
      loadBundleName({
        payload: {
          serviceType: "RESCO",
          scheduleCode: "01",
          technology: orderdetail.technology,
          splitRatio: orderdetail.splitRatio,
          redundancyService: orderdetail.redundancyService,
        },
      })
    );
  }
  diversionFlow() {
    let errorMsg: any = {
      title: 'ERR-021',
      body: 'ERR-021 - New development, roll-out in progress ',
      okFunction: 'diversion',
    };
    this.setModal(errorMsg);
  }
  loadPriceDetails(bundleNameWithCharge: any) {
    // this.brmBundleName = bundleName;
    // this.store.dispatch(
    //   chargeInfo({
    //     payload: {
    //       brmBundleName: bundleNameWithCharge,
    //     },
    //   })
    // );
    //   this.getFormControl.priceDetails
    //   .get('otcAmt')
    //   .setValue(chargeInfo.otcAmt);
    // this.getFormControl.priceDetails.get('otcAmt').disable();
    // this.getFormControl.priceDetails
    //   .get('mrcAmt')
    //   .setValue(chargeInfo.mrcAmt);
    // this.getFormControl.priceDetails.get('mrcAmt').disable();
  }

  changeTechnology(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'splitRatio') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'GPON' && opt.value == '2:32') {
            opt.disable = true;
            this.getFormControl.orderDetails.patchValue({ splitRatio: '1:16' });
          } else {
            opt.disable = false;
          }
          if (obj.option.value == 'OE') {
            if (opt.value == '1:1' || opt.value == '1:24') {
              opt.disable = true;
              this.getFormControl.orderDetails.patchValue({
                splitRatio: '2:32',
              });
            }
          }
        });
      }
    });
    let technology = this.getFormControl.orderDetails.get('technology').value;
    let splitRatio = this.getFormControl.orderDetails.get('splitRatio').value;
    let redundancyService =
      this.getFormControl.orderDetails.get('redundancyService').value;
    let orderDetal = {
      technology: technology,
      splitRatio: splitRatio,
      redundancyService: redundancyService,
    };
    this.chargeDetails(orderDetal);
  }
  spiltRatioChange(obj: any) {
    let technology = this.getFormControl.orderDetails.get('technology').value;
    let splitRatio = this.getFormControl.orderDetails.get('splitRatio').value;
    let redundancyService =
      this.getFormControl.orderDetails.get('redundancyService').value;
    let orderInfo = {
      technology: technology,
      splitRatio: splitRatio,
      redundancyService: redundancyService,
    };
    this.chargeDetails(orderInfo);
  }
  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .clearValidators();
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails
              .get('rejectIfredundancyService')
              .setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({
              rejectIfredundancyService: 'No',
            });
            opt.disable = false;
          }
          this.getFormControl.orderDetails
            .get('rejectIfredundancyService')
            .updateValueAndValidity();
        });
      }
    });
    let technology = this.getFormControl.orderDetails.get('technology').value;
    let splitRatio = this.getFormControl.orderDetails.get('splitRatio').value;
    let redundancyService =
      this.getFormControl.orderDetails.get('redundancyService').value;
    let orderDetal = {
      technology: technology,
      splitRatio: splitRatio,
      redundancyService: redundancyService,
    };
    this.chargeDetails(orderDetal);
  }



  buildingDemotionFlow() {
    let errorMsg: any = {
      title: 'ERR-021',
      body: 'ERR-021 - New development, roll-out in progress ',
      okFunction: 'buildingDemolition',
    };
    this.setModal(errorMsg);
  }

  onSubmitClick(serviceOrder: any) {
    console.log("this.orderFormValue", this.orderFormValue)
    let otherInfo =   {
      ori: "",
      submissionDate: new Date(),
      orderSource: "SWP",
      orderType: "A",
      revision: "1",
      reclassification: "",
      scheduleCode: "01",
      serviceType: "RESCO",
      tieCableCheckStatus: ""
  }
    const payload = {
      installationDetails: {postalCode: this.postalCode, unitNumber: this.unitNumber, ... this.installationAddress},
      orderDetails: serviceOrder.orderDetails,
      activationDetails: { taskId: "", ...serviceOrder.activationDetails, reverseAppointment: undefined, },
      endUserDetails:serviceOrder.endUserDetails ,
      pricingInfo:serviceOrder.pricingInfo,
      additionalInfo:serviceOrder.additionalInfo,
      otherInfo:otherInfo
    }
    this.store.dispatch(orderSubmission({ payload }));
  }
  onCancelClick() {
    let successMsg: any = {
      title: 'Confirmation',
      body: 'Are you sure you want to cancel the Order?',
      okFunction: 'CancelEvent',
    };
    this.setModal(successMsg);
  }
  triggerOrderCancel() {
    this.store.dispatch(setLoadingSpinner({ status: true }));
    let payload = {
      scheduleInfo: {
        scheduleCode: "01",
        scheduleId: "",
        scheduleName: "",
        serviceType: ""
      },
      createGeneralEventRequestDTO: {
        taskId: "",
        employee: "",
        allocator: "",
        dateFrom: "",
        dateTo: "",
        userId: "",
        remark: "",
        reasonCode: "",
        workOrderId: "",
        eventUdfInput: ""
      }
    }
    this.orderManagementService
      .createGeneralEvent(payload)
      .subscribe((data) => {
        this.store.dispatch(setLoadingSpinner({ status: false }));
        if (data.status == 0) {
          this.toastrService.success('Order Cancelled Successfully');
          this.router.navigate(['home']);
        }
      });
  }
  onEditFeasibilityCheck() {
    let successMsg: any = {
      title: 'Confirmation',
      body: 'Are you sure you want to do Feasibility Check Again?',
      okFunction: 'EditFC'
    };
    this.setModal(successMsg);
  }
  editFeasibilityCheck() {
    this.fcFormControl.enable();
    this.isFesibilityCheckDone = false;
    this.fcInput.controls[0].hide = false;
    this.store.dispatch(initialState());
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    this.storeSubscribeHandler();
  }
  setModal(modalData: any) {
    this.modalObj.modalBody = modalData.body;
    this.modalObj.modalTitle = modalData.title;
    this.modalVisibilty = true;
    this.modalObj.modalOkFunction = modalData.okFunction;
  }
  modalConfirm(callback: any) {
    if (callback) {
      if (callback === 'buildingDemolition') {
        this.router.navigate(['home']);
      } else if (callback === 'USO') {
        this.fcFormControl.disable();
        this.shedule2Modal = '';
      
        this.formData = AddressNotFoundFormData;
        this.isFesibilityCheckDone = true;
        this.fcInput.controls[0].hide = true;
      } else if (callback == 'CancelEvent') {

      } else if (callback == 'EditFC') {
        this.editFeasibilityCheck();
      }
      else if (callback == 'diversion') {
        this.nextStepOfFeasibilityCheck(this.installationAddress)
      }

    }
    this.modalVisibilty = false;
    this.modalObj.modalOkFunction = null;
  }
  modalCancel() {
    this.modalVisibilty = false;
  }
  canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
    if (!this.orderFormValue) {
      return confirm('Do you want to discard the changes?');
    } else {
      return true;
    }
  }
  ngOnDestroy() {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    this.store.dispatch(initialState());
  }
}




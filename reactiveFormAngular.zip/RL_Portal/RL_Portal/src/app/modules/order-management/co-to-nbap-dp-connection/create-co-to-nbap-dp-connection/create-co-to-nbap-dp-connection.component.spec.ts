import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCoToNbapDpConnectionComponent } from './create-co-to-nbap-dp-connection.component';

describe('CreateCoToNbapDpConnectionComponent', () => {
  let component: CreateCoToNbapDpConnectionComponent;
  let fixture: ComponentFixture<CreateCoToNbapDpConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateCoToNbapDpConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateCoToNbapDpConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

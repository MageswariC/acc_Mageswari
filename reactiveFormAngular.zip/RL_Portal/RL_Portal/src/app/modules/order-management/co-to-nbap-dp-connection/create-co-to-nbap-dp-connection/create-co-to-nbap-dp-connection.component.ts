import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { FormService } from 'src/app/form.service';
import nbapS10ConnectionFormData from 'src/app/modules/integration/form-data/order-management/create-order/co-nbap-dp-formData-s10';
import fc from 'src/app/modules/integration/form-data/feasibility-check/co-nbap-dp-s10';
import { clone } from 'src/app/components/utilities/util';


@Component({
  selector: 'app-create-co-to-nbap-dp-connection',
  templateUrl: './create-co-to-nbap-dp-connection.component.html',
  styleUrls: ['./create-co-to-nbap-dp-connection.component.scss']
})
export class CreateCoToNbapDpConnectionComponent implements OnInit {

  nbapDpConnectionS10!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;

  //Feasibility check input 
  fcInput: any;
  getFCFormControl: any

  //form builder input
  formData: any;
  getFormControl: any;
  shedule10Modal: any;
  formValue: any;
  addressOptions: any;

  constructor(
    private fb: FormBuilder,
    private store: Store<DynamicComponentState>,
    private router: Router, 
    private formService: FormService,
    private toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.formData = nbapS10ConnectionFormData.postalCodeForm;
    this.fcInput = fc.postalCode;
    this.nbapDpConnectionS10 = this.fb.group({});
  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
  getFormVal(val: any) {
    this.formValue = val;
    console.log("end",val);
    this.router.navigate(['home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }
  changePostalToGps(obj: any)
  {
    // this.addressOptions = obj.event.currentTarget.value;
    this.addressOptions = obj.option.value;
    console.log(obj);
    console.log(obj.option.value);
    if(this.addressOptions == 'Postal Code')
     {
      this.fcInput = clone(fc.postalCode);
      this.formData = nbapS10ConnectionFormData.postalCodeForm;
    }
    if(this.addressOptions == 'Coordinate System')
    {
      this.fcInput = clone(fc.coOrdinateSystem);
      this.formData = nbapS10ConnectionFormData.coOrdinateSystemForm;
    }
    // else this.fcInput = clone(fc.defaultDisplay);
  }
  getFCForm(form: FormGroup) {
    this.getFCFormControl = form.controls;
    // this.isFesibilityCheckClicked =true;
    // this.getFCFormControl?.coordinateSystem.setValue('SVY21');
  }
  fcFormValue(fcForm: FormGroup) {
    this.isFesibilityCheckClicked = true;
  }
  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }
  changeCoordinateSystem(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (obj.event.target.value == 'SVY21') {
        if (control.key == 'gpsXcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 3 fraction digits only allowed"
        }
        if (control.key == 'gpsYcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 3 fraction digits only allowed"
        }
        this.getFCFormControl?.gpsXcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,3})?'), Validators.required]);
        this.getFCFormControl?.gpsYcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,3})?'), Validators.required]);
      } else if (obj.event.target.value == 'WGS84') {
        if (control.key == 'gpsXcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 7 fraction digits only allowed"
        }
        if (control.key == 'gpsYcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 7 fraction digits only allowed"
        }
        this.getFCFormControl.gpsXcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,7})?'), Validators.required]);
        this.getFCFormControl.gpsYcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,7})?'), Validators.required],);
      }

    })

    this.getFCFormControl?.gpsXcoordinates.updateValueAndValidity();
    this.getFCFormControl?.gpsYcoordinates.updateValueAndValidity();
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import advancedCoverageCheckFormData from 'src/app/modules/integration/form-data/order-management/create-order/advanced-coverage-check';
import rspFormData from 'src/app/modules/integration/form-data/order-management/create-order/rsp-formData';
import fc from 'src/app/modules/integration/form-data/feasibility-check/feasibility-check-coverage-check';
@Component({
  selector: 'app-advance-coverage-check',
  templateUrl: './advance-coverage-check.component.html',
  styleUrls: ['./advance-coverage-check.component.scss']
})
export class AdvanceCoverageCheckComponent implements OnInit {

  formGroup!: FormGroup;
  initalMangerOrder: Boolean = true;
  isFesibilityCheckClicked: Boolean = false;

  //Feasibility check input 
  fcInput: any;

  //form builder input
  formData: any;
  formData1 : any;
  getFormControl: any;
  isFeasiblityChecked:any;

  tableColumn= [
    {
      header: "Serving Cabinet",
      value:"servingCabinet"
    },
    {
      header: "Serving Cabinet Type",
      value:"servingCabinetType"
    },
    {
      header: "Serving CO",
      value:"servingCO"
    }
  ]

  tableRow=[{
    servingCabinet:"C1",
    servingCabinetType:"T1",
    servingCO:"CO"
   }]
  constructor(private fb: FormBuilder, private router: Router,  private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.formData = advancedCoverageCheckFormData;
    this.formData1 =rspFormData;
    this.fcInput = fc;
    this.formGroup = this.fb.group({})
  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
  fcFormValue(fcForm: any) {
    this.isFesibilityCheckClicked = true;
  }
  fcFormControl(fcForm: any){
    
  }
  getFormVal(val: any) {
    //console.log("---in get value--",val.value)
    this.router.navigate(['swp/home']);
    this.toastrService.success('The request for the connection has been submitted successfully ORI Details: 02-01-07012022-45671-A', '');
  }

}

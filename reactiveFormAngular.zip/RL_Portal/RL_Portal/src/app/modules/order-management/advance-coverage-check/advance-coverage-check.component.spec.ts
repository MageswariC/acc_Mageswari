import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvanceCoverageCheckComponent } from './advance-coverage-check.component';

describe('AdvanceCoverageCheckComponent', () => {
  let component: AdvanceCoverageCheckComponent;
  let fixture: ComponentFixture<AdvanceCoverageCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvanceCoverageCheckComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvanceCoverageCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import dpConnectionFormData from 'src/app/modules/integration/form-data/order-management/fttb-node-to-dp-connection/dp-connection-formData';
// import { AllShedule } from 'src/app/modules/integration/interface/forms/order-management/all-shedule';
import { dpConnectionModal } from 'src/app/modules/integration/modal/order-management/fttb-node-to-dp-connection/dp-connection.modal';
import fc from 'src/app/modules/integration/form-data/feasibility-check/fesibility-check';

@Component({
  selector: 'app-create-dp-connection',
  templateUrl: './create-dp-connection.component.html',
  styleUrls: ['./create-dp-connection.component.scss']
})
export class CreateDpConnectionComponent implements OnInit {
  modalSize: string = 'md';
  modalTitle: string = '';
  modalBody: string = '';
  modalButtonColor: string = 'button-primary';
  resiEndUserS7!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;
  dpConnectionModal= {...dpConnectionModal};
 //Feasibility check input 
 fcInput: any;

 //form builder input
 formData: any;
 getFormControl: any;
 shedule1Model = dpConnectionModal;
 getFCFormControl: any;
  
  
 constructor(private fb: FormBuilder, private toastrService: ToastrService, private router: Router) { }

 ngOnInit(): void {
 
   this.formData = dpConnectionFormData;
   this.fcInput = fc;
   this.resiEndUserS7 = this.fb.group({})
 }
  // async openModal() {
  //   return await this.modalComponent.open();
  // }

  getConfirmationValue(value: any) {
    if (value == 'Save click') {
      this.router.navigate(['swp/home']);
    }
  }
  getForm(form: any) {
    this.getFormControl = form.controls;
  }
  getFCForm(form: FormGroup) {
    this.getFCFormControl = form;
    console.log("getfcform",this.getFCFormControl);
  
    //this.isFesibilityCheckClicked = true;
    // this.getFCFormControl?.orderOption.setValue('Postal Code')
    
  }
  fcFormValue(fcForm: any) {
    this.isFesibilityCheckClicked = true;
    console.log("fc form", fcForm)
  }
  getFormVal(val: any) {
    this.router.navigate(['swp/home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }
 

  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }

}

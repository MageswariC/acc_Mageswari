import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDpConnectionComponent } from './create-dp-connection.component';

describe('CreateDpConnectionComponent', () => {
  let component: CreateDpConnectionComponent;
  let fixture: ComponentFixture<CreateDpConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateDpConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateDpConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

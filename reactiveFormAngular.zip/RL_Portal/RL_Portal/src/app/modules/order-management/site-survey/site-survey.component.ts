import { Component, OnInit } from '@angular/core';
import siteRequestSelection from '../../integration/form-data/order-management/create-order/site-survey/site-survey-radio-formData';
import preOrderFcForm from '../../integration/form-data/order-management/create-order/site-survey/pre-order-fc-formdata';
import preOrderSiteSurveyForm from '../../integration/form-data/order-management/create-order/site-survey/pre-order-fromData';
import { clone } from '../../integration/utilities/util';
import onSiteSurveyFcForm from '../../integration/form-data/order-management/create-order/site-survey/onSiteVist-fc-form';
import onSiteSurveyFormData from '../../integration/form-data/order-management/create-order/site-survey/onsite-survey-formData';
import { siteAdressDetails,installationAddress } from '../../integration/modal/site-survey/onsite-survey-modal';
@Component({
  selector: 'app-site-survey',
  templateUrl: './site-survey.component.html',
  styleUrls: ['./site-survey.component.scss']
})
export class SiteSurveyComponent implements OnInit {

  constructor() { }
  requestTypeformData: any;
  requestTypeFormControl: any;
  onSitefcInput: any = onSiteSurveyFcForm;
  preSitefcInput: any = preOrderFcForm;
  showFeasiblitySection = false;
  mainFormData: any;
  isFesibilityChecked: any;
  scheduleModal: any;
  showPreSiteSurveyFeasiblitySection = false;
  showOnsiteVisitFeasiblitySection = false
  ngOnInit(): void {
    this.requestTypeformData = siteRequestSelection;
  }
  getRequestTypeForm(control: any) {
    this.requestTypeFormControl = control;
  }
  getForm(control: any) {

  }
  onChangeRequestType(control: any) {

    console.log(control.option.value);
    this.isFesibilityChecked = false;

    if (control.option.value === "Pre-Order Site Survey") {
      this.showOnsiteVisitFeasiblitySection = false;
      this.showPreSiteSurveyFeasiblitySection = true;

      this.showFeasiblitySection = true;
    }
    else {
      this.showPreSiteSurveyFeasiblitySection = false;
      this.showOnsiteVisitFeasiblitySection = true;
      this.showFeasiblitySection = true;
    }

  }
  onpreSiteFcFormSubmit(val: any) {

    
    const value = val.feasibilityCheck

    console.log(value);
    this.mainFormData = clone(preOrderSiteSurveyForm);




    //  console.log(formData.controls);


    this.mainFormData.controls.forEach((section: any) => {

      if (section.key === "residentialInstallationAddress" && value.premiseType === "Residential") {
        section.visible = true;
        this.scheduleModal = {
          residentialInstallationAddress: installationAddress
        }

      }
      else if (section.key === "nonResidentialInstallationAddress" && value.premiseType === "Non Residential") {
        section.visible = true;
        this.scheduleModal = {
          nonResidentialInstallationAddress: installationAddress
        }
      }
    })
  
    this.isFesibilityChecked = true;
  }
  onOnsiteVisitFormSubmit(form:any){
  this.scheduleModal={
    onSiteVisitAddress: siteAdressDetails
  }
  this.mainFormData=onSiteSurveyFormData;
  this.isFesibilityChecked = true;

  }
  fcFormValue(val: any) {

  }
  getMainForm(val: any) {

  }
  getMainFormVal(val: any) {

  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNBAPConnectionComponent } from './create-nbap-connection.component';

describe('CreateNbapConnectionComponent', () => {
  let component: CreateNBAPConnectionComponent;
  let fixture: ComponentFixture<CreateNBAPConnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateNBAPConnectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateNBAPConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

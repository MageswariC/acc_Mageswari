import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators, ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS, Validator, AbstractControl, ValidationErrors, FormGroupDirective } from '@angular/forms';
import { nbapConnectionModel } from 'src/app/modules/integration/modal/order-management/create-order/nbap-connection.modal';
import { FormService } from '../../../../integration/service/order-management/form.service';
import nbapConnectionFormData from '../../../../integration/form-data/order-management/create-order/nbap-connection-formData';
import fc from '../../../../integration/form-data/feasibility-check/fesibility-check-s10';
import { clone } from 'src/app/components/utilities/util';

//import { AllShedule } from '../../../shared/interface/forms/order-management/all-shedule';


@Component({
  selector: 'app-create-nbap-connection',
  templateUrl: './create-nbap-connection.component.html',
  styleUrls: ['./create-nbap-connection.component.scss']
})
export class CreateNBAPConnectionComponent implements OnInit {
  nbapConnectionS3!: FormGroup;
  isFesibilityCheckClicked: Boolean = false;
//Feasibility check input 
  fcInput: any;
  getFCFormControl: any
 //form builder input
  formData: any;
  getFormControl: any;
  shedule3Model = nbapConnectionModel;
 
  formValue: any;
  fcControl : any;
  addressOptions: any;
  //isFesibilityCheckDone: boolean = false;;

  constructor(private fb: FormBuilder, private router: Router, private formService: FormService, private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.formData = nbapConnectionFormData.postalCodeForm;
    this.fcInput = fc.postalCode;
    this.nbapConnectionS3 = this.fb.group({});

  }
  getForm(form: FormGroup) {
    this.getFormControl = form.controls;
  }
 
  getFormVal(val: any) {
    this.formValue = val;
    console.log("end",val);
    this.router.navigate(['home']);
    this.toastrService.success('Your request has been submitted successfully', '');
  }
  changePostalToGps(obj: any)
  {
    // this.addressOptions = obj.event.currentTarget.value;
    this.addressOptions = obj.option.value;
    console.log(obj);
    console.log(obj.option.value);
    if(this.addressOptions == 'Postal Code')
     {
      this.fcInput = clone(fc.postalCode);
      this.formData = nbapConnectionFormData.postalCodeForm;
    }
    if(this.addressOptions == 'Coordinate System')
    {
      this.fcInput = clone(fc.coOrdinateSystem);
      this.formData = nbapConnectionFormData.coOrdinateSystemForm;
    }
    // else this.fcInput = clone(fc.defaultDisplay);
  }
  getFCForm(form: FormGroup) {
    this.getFCFormControl = form.controls;
    // this.isFesibilityCheckClicked =true;
    // this.getFCFormControl?.coordinateSystem.setValue('SVY21');
  }
  
  fcFormValue(fcForm: FormGroup) {
    this.isFesibilityCheckClicked = true;
   }
  
  changeRedundancyService(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'rejectIfredundancyService') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'No') {
            control.required = false;
            opt.disable = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').clearValidators();
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValue(null);
          } else {
            control.required = true;
            this.getFormControl.orderDetails.get('rejectIfredundancyService').setValidators([Validators.required]);
            this.getFormControl.orderDetails.patchValue({ 'rejectIfredundancyService': 'No' });
            opt.disable = false;
          }
          this.getFormControl.orderDetails.get('rejectIfredundancyService').updateValueAndValidity();
        })
      }
    })
  }
  changeTechnology(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (control.key == 'splitRatio') {
        control.option.forEach((opt: any) => {
          if (obj.option.value == 'GPON' && opt.value == '2:32') {
            opt.disable = true;
            this.getFormControl.orderDetails.patchValue({ 'splitRatio': '1:16' });
          } else {
            opt.disable = false;
          }
          if (obj.option.value == 'OE') {
            if (opt.value == '1:1' || opt.value == '1:16') {
              opt.disable = true;
              this.getFormControl.orderDetails.patchValue({ 'splitRatio': '2:32' });
            }
          }
        })
      }
    })
  }
  changeCoordinateSystem(obj: any) {
    obj.fgroup.options.children.forEach((control: any) => {
      if (obj.event.target.value == 'SVY21') {
        if (control.key == 'gpsXcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 3 fraction digits only allowed"
        }
        if (control.key == 'gpsYcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 3 fraction digits only allowed"
        }
        this.getFCFormControl?.gpsXcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,3})?'), Validators.required]);
        this.getFCFormControl?.gpsYcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,3})?'), Validators.required]);
      } else if (obj.event.target.value == 'WGS84') {
        if (control.key == 'gpsXcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 7 fraction digits only allowed"
        }
        if (control.key == 'gpsYcoordinates') {
          control.errorMsg.pattern = "Enter valid input. Decimal with 7 fraction digits only allowed"
        }
        this.getFCFormControl.gpsXcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,7})?'), Validators.required]);
        this.getFCFormControl.gpsYcoordinates.setValidators([Validators.pattern('[0-9]*(\.[0-9]{0,7})?'), Validators.required]);
      }
    })

    this.getFCFormControl?.gpsXcoordinates.updateValueAndValidity();
    this.getFCFormControl?.gpsYcoordinates.updateValueAndValidity();
  }
}

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from 'src/app/components/integration/store/dynamic-component.reducer';
import { getCurrentRoute } from 'src/app/components/integration/store/selectors/router.selector';
import { getCreditCheck } from '../integration/store/selectors/creditCheck.selectors';

@Component({
  selector: 'app-order-management',
  templateUrl: './order-management.component.html',
  styleUrls: ['./order-management.component.scss'],
})
export class OrderManagementComponent implements OnInit {
  public creditCheck = false;
  constructor(private store: Store<DynamicComponentState>) {}

  ngOnInit(): void {
    this.store.select(getCurrentRoute).subscribe((state) => {
      // console.log('%c current url', 'background-color:red', state.url);

      if (state.data.creditCheck) {
        this.store.select(getCreditCheck).subscribe((data: any) => {
          if (data.creditCheck == 1) {
            this.creditCheck = true;
          } else {
            this.creditCheck = false;
          }
        });
      } else {
        this.creditCheck = true;
      }
    });
   
  }
  
}

import { dynamicComponentReducer } from '../components/integration/store/dynamic-component.reducer';
import { RLReducer } from '../modules/integration/store/app.reducer';
import { creditCheckEffects } from '../modules/integration/store/effects/creditCheck.effects';
import { customerEligibilityEffects } from '../modules/integration/store/effects/customerEligibility.effect';
import { coDetailsEffects } from '../modules/integration/store/effects/getCODetails.effects';
import { roomDetailsEffects } from '../modules/integration/store/effects/getRoomDetails.effects';
import { ManageOrderEffects } from '../modules/integration/store/effects/manage-order.effects';

import { TroubleTicketEffects } from '../modules/integration/store/effects/trouble-ticket.effect';

/**
 * All reducers go here so that we can configure them together in root module.
 */

export const Rootreducers = {
  ...dynamicComponentReducer,
  ...RLReducer,
};

export const RootEffects = [
  TroubleTicketEffects,
  ManageOrderEffects,
  creditCheckEffects,
  customerEligibilityEffects,
  roomDetailsEffects,
  coDetailsEffects
];

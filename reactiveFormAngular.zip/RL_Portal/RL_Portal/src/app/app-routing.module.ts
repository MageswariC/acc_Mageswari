import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContainerComponent } from '../app/components/common-templates/container/container.component';
import { HomeComponent } from './components/dynamic-components/home/home.component';
import { LoginComponent } from './components/dynamic-components/login/login.component';
const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: '',
    component: ContainerComponent,
    children: [
      { path: 'home', component: HomeComponent },
      // {
      //   path: '',
      //   loadChildren: () =>
      //     import(
      //       './components/dynamic-components/dynamic-component.module'
      //     ).then((m) => m.DynamicComponentModule),
      // },
      {
        path: '',
        loadChildren: () =>
          import('./modules/order-management/order-management.module').then(
            (m) => m.OrderManagementModule
          ),
      },
      {
        path: '',
        loadChildren: () =>
          import('./modules/trouble-ticket/trouble-ticket.module').then(
            (m) => m.TroubleTicketModule
          ),
      },
      {
        path: '',
        loadChildren: () =>
          import('./modules/user-management/user-management.module').then(
            (m) => m.UserManagementModule
          ),
      },
      
      // {
      //   path: "",
      //   loadChildren: () => import('./modules/co-location/co-location.module').then(m => m.ColocationServiceModule)
      // },
      {
        path: '',
        loadChildren: () =>
          import(
            './modules/application-management/application-management.module'
          ).then((m) => m.ApplicationManagementModule),
      },
      // {
      //   path: '',
      //   loadChildren: () =>
      //     import(
      //       './modules/advance-coverage-check/advance-coverage-check.module'
      //     ).then((m) => m.AdvanceCoverageCheckModule),
      // },
      // {
      //   path: '',
      //   loadChildren: () =>
      //     import('./modules/billing/billing.module').then(
      //       (m) => m.BillingModule
      //     ),
      // }
    ],
  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

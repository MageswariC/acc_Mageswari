import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';

import { ModalComponent } from './components/dynamic-components/modal/modal.component';
import { clearErrorMessage, setErrorMessage } from './components/integration/store/actions/error-message.action';
import { DynamicComponentState } from './components/integration/store/dynamic-component.reducer';
import { getErrorMessage } from './components/integration/store/selectors/error.message.selector';
import { getLoading } from './components/integration/store/selectors/loading-spinner.selector';
import { OrderManagementService } from './modules/integration/service/order-management/order-management.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  showLoading$!: Observable<boolean>;
  modalObj: any;
  subscription$:any;

  @ViewChild('modal')
  private modalComponent!: ModalComponent;
  async openModal(obj?: any) {
    return await this.modalComponent.open(obj);
  }
  constructor(private router: Router, private orderManagementService:OrderManagementService, private store: Store<DynamicComponentState>) { }
  ngOnInit(): void {
    this.showLoading$ = this.store.select(getLoading);

    this.subscription$= this.store.select(getErrorMessage).subscribe((error) => {
      
      if (error.message!='') {
        this.modalObj = {
          modalData:error
        }
        this.openModal({ modalSize: 'md' });
        
      }
    })
  }
  ConfirmationEvent(data: any) {
    // this.orderManagementService.feasibilityNote.next(data);
    this.store.dispatch(clearErrorMessage());
  
  }
  public onDestroy(): void {
    this.subscription$.unsubscribe();
}
 

}

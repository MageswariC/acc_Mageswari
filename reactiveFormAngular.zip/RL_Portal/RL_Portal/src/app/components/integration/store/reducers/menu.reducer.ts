
import { initialState } from "../state/menu.state"


export function MenuReducer(state = initialState){
    return state;
}
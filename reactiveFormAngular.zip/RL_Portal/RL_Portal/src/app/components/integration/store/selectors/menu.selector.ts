import { createFeatureSelector, createSelector } from "@ngrx/store";
import { MenuState } from "../state/menu.state";

export const MENU_STATE_NAME = 'menu';
const getMenuState = createFeatureSelector<MenuState>(MENU_STATE_NAME);
export const getmenuList = createSelector(getMenuState, (state)=>{
    return state.menuList;
})
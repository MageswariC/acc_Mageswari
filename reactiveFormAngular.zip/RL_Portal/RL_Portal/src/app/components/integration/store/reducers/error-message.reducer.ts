import { createReducer, on } from "@ngrx/store"
import { clearErrorMessage, setErrorMessage } from "../actions/error-message.action"
import { initialState } from "../state/error-message"

const _errorMsgReducer = createReducer(initialState, on(setErrorMessage, (state, action) => {
    return {
        ...state,
        
        title: action.message.title,
        message: action.message.message,
        status: action.message.status,
        type:action.message.type
    }
}),
    on(clearErrorMessage, (state, action) => {
        return {
            ...state,
            title: '',
        message: '',
        status: '',
        type:''
   
        }
    })
)

export function ErrorMessageReducer(state: any, action: any) {
    return _errorMsgReducer(state, action)
}
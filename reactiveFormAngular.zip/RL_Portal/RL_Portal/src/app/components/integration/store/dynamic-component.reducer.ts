import { MenuReducer } from "./reducers/menu.reducer";
import { MENU_STATE_NAME } from "./selectors/menu.selector";

import { routerReducer } from "@ngrx/router-store";
import { LoadingSpinnerReducer } from "./reducers/loading-spinner.reducer";
import { LOADING_SPINNER_STATE_NAME } from "./selectors/loading-spinner.selector";
import { ErrorMessageReducer } from "./reducers/error-message.reducer";
import { ERROR_MESSAGE_STATE_NAME } from "./selectors/error.message.selector";
import { RouterReducerState } from "@ngrx/router-store";
import { ErrorMesaage } from "./state/error-message";
import { LoadingSpinnerState } from "./state/loading-spinner.state";
import { MenuState } from "./state/menu.state";
export interface DynamicComponentState{
    [MENU_STATE_NAME]:MenuState;
    [LOADING_SPINNER_STATE_NAME]:LoadingSpinnerState,
    [ERROR_MESSAGE_STATE_NAME]:ErrorMesaage,
    router:RouterReducerState;
}
export const dynamicComponentReducer = {
    
    [MENU_STATE_NAME]:MenuReducer,
    [LOADING_SPINNER_STATE_NAME]:LoadingSpinnerReducer,
    [ERROR_MESSAGE_STATE_NAME]:ErrorMessageReducer,
    router:routerReducer
}
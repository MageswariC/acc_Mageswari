export interface LoadingSpinnerState{
    showLoading:boolean;
}

export const initialState:LoadingSpinnerState = {
    showLoading:false,
}
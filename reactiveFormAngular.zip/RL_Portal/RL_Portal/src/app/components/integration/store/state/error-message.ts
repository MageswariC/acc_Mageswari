

export const initialState:ErrorMesaage = {
    title:'',
    message:'',
    status:'',
    type:''
}
export  interface ErrorMesaage{
    title:string,
    message:string,
    status:string,
    type:string,

}
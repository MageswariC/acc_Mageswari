import { MenusList } from "../../interface/menuList";
import { menusList } from "../../modal/component/menu.modal";

export interface MenuState{
    menuList: MenusList[]
}

export const initialState:MenuState={
    menuList:menusList,
}
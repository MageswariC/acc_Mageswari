import { createAction, props } from "@ngrx/store";
import { ErrorMesaage } from "../state/error-message";
export const SET_ERROR_MESSAGE = "[shared state] set error message";
export const CLEAR_ERROR_MESSAGE = "[shared state] clear error message";
export const setErrorMessage = createAction(SET_ERROR_MESSAGE, props<{message:ErrorMesaage}>())
export const clearErrorMessage = createAction(CLEAR_ERROR_MESSAGE)
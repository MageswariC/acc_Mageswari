import { createFeatureSelector, createSelector } from "@ngrx/store";
import { ErrorMesaage } from "../state/error-message";

export const ERROR_MESSAGE_STATE_NAME = 'errorMsg';
const getErrorMsgState = createFeatureSelector<ErrorMesaage>(ERROR_MESSAGE_STATE_NAME);

export const getErrorMessage = createSelector(getErrorMsgState, (state)=>{
        return state;
})


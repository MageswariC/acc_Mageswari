export interface MenusList {
  id?: any;
  title?: String;
  name?: String;
  route?: String;
  schedule?: String;
  hasChild?: MenusList[];
  roleAssignee?: any;
}

export interface ActiveMenu {
  title?: String;
  name?: String;
  route?: String;
  isActive?: Boolean;
}

export interface Dashboard {
    label?: string;
    route?: string;
    icon?:String;
    colSize?:String;
    img?:String;
    title?:String;
  }
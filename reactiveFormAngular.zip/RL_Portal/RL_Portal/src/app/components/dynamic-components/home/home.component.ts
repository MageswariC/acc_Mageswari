import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { tilesList } from '../../integration/modal/component/dashboard.modal';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {



  tilesLists : Array<any> = tilesList

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  navigateToComponent(route: any) {
        this.router.navigateByUrl(route)
  }
}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { menusList } from '../../integration/modal/component/menu.modal';

import { Store } from '@ngrx/store';
import { getmenuList } from '../../integration/store/selectors/menu.selector';
import { getCurrentRoute } from '../../integration/store/selectors/router.selector';
import { Observable } from 'rxjs';
import { MenusList } from '../../integration/interface/menuList';
import { DynamicComponentState } from '../../integration/store/dynamic-component.reducer';
@Component({
  selector: 'app-navbar-component',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  path: any;
  menusList$!: Observable<any>;

  constructor(
    private router: Router,
    private store: Store<DynamicComponentState>
  ) { }

  ngOnInit(): void {
    this.menusList$ = this.store.select(getmenuList);
    this.store.select(getCurrentRoute).subscribe((state) => {
      this.path = state.url;
    });

  }

  onClick(e: any) {
    e.preventDefault();

    const parent = e.currentTarget.parentElement;
    // let a = e.currentTarget.getAttribute("aria-expanded");
    const ul = parent.querySelector(":scope > ul");
    if (!ul) return;
    if (ul.classList.contains("show")) {
      ul.classList.remove("show")
      e.currentTarget.setAttribute("aria-expanded", false);
    } else {
      ul.classList.add("show");
      e.currentTarget.setAttribute("aria-expanded", true);
    }

  }
}

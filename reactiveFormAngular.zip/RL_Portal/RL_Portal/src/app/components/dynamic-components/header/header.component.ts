import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute,NavigationEnd} from '@angular/router';
import { Store } from '@ngrx/store';
import { DynamicComponentState } from '../../integration/store/dynamic-component.reducer';


@Component({
  selector: 'app-header-component',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  showNotification: boolean = false;  
  currentRoute:any = "";
  constructor(private store:Store<DynamicComponentState>) { }

  ngOnInit(): void {
}

  openNotification(state: boolean) {
    this.showNotification = state;
  }
  logout(event:Event){
    event.preventDefault();

  }

}

import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setCreditCheck } from 'src/app/modules/integration/store/actions/creditCheck.action';
import { setCustomerEligibility } from 'src/app/modules/integration/store/actions/customerEligibility.action';
import { getCreditCheck } from 'src/app/modules/integration/store/selectors/creditCheck.selectors';
import { getcustomerEligibility } from 'src/app/modules/integration/store/selectors/customerEligibility.selectors';
import { DynamicComponentState } from '../../integration/store/dynamic-component.reducer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  login!: FormGroup;
  submitted!: boolean;

  constructor(
    private router: Router,
    private store: Store<DynamicComponentState>
  ) {}

  ngOnInit(): void {
    this.login = new FormGroup({
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [
        Validators.required,
        Validators.minLength(8),
      ]),
    });
    let payload: any = {
      osbUID: 'Test1001',
      rl: '01',
    };
    this.store.dispatch(setCreditCheck({ value: payload }));
    this.store.dispatch(setCustomerEligibility({ value: payload }));
   
  }

  get f(): { [key: string]: AbstractControl } {
    return this.login.controls;
  }

  submit() {
    this.submitted = true;
    if (this.login.valid) {
      // this.authService.authLogin(this.login.value);
      const email = this.login.value.username;
      const password = this.login.value.password;
      this.router.navigateByUrl('/home');
    } else return;
  }
}

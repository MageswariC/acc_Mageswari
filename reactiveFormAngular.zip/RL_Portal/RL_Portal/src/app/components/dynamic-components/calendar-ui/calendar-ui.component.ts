import {
  Component,
  Input,
  OnInit,
  ChangeDetectorRef,
  Injectable,
  ɵgetDebugNodeR2,
  ChangeDetectionStrategy,
  SimpleChanges,
  OnChanges,
} from '@angular/core';
import {
  NgbCalendar,
  NgbDate,
  NgbDateAdapter,
  NgbDateParserFormatter,
  NgbDateStruct,
  NgbDatepickerConfig,
} from '@ng-bootstrap/ng-bootstrap';
import { FormGroupDirective, FormsModule } from '@angular/forms';
import { isNumber, toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';
import { JsonPipe } from '@angular/common';
import { config, Subscription } from 'rxjs';
// import { NgbDateCustomParserFormatter} from 'src/app/components/dynamic-components/calendar-ui/dateformat';
import { OrderManagementService } from 'src/app/modules/integration/service/order-management/order-management.service';
import { Store } from '@ngrx/store';
import { getAvailableDates } from 'src/app/modules/integration/store/selectors/order-management';
import { DynamicComponentState } from '../../integration/store/dynamic-component.reducer';
import { selectedSlot } from 'src/app/modules/integration/store/actions/residential-connection-create-order';
const dateFrom = '2012-11-04T06:35:45';
const dateTo = '2012-11-04T06:35:45';
@Injectable()
// export class CustomAdapter extends NgbDateAdapter<string> {
//   readonly DELIMITER = '-';

//   fromModel(value: string | null): NgbDateStruct | null {
//     if (value) {
//       const date = value.split(this.DELIMITER);
//       return {
//         day: parseInt(date[0], 10),
//         month: parseInt(date[1], 10),
//         year: parseInt(date[2], 10),
//       };
//     }
//     return null;
//   }

//   toModel(date: NgbDateStruct | null): string | null {
//     return date
//       ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year
//       : null;
//   }
// }

/**
 * This Service handles how the date is rendered and parsed from keyboard i.e. in the bound input field.
 */
@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {
  readonly DELIMITER = '/';
  parse(value: string): NgbDateStruct | null {
    if (value) {
      console.log(value);
      const date = value.split(this.DELIMITER);
      return {
        year: parseInt(date[2], 10),
        day: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
      };
    }
    return null;
  }
  format(date: NgbDateStruct | null): string {
    return date
      ? date.month + this.DELIMITER + date.day + this.DELIMITER + date.year
      : '';
  }
}

@Component({
  selector: 'app-calendar-ui',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './calendar-ui.component.html',
  styleUrls: ['./calendar-ui.component.scss'],
  styles: [],
  providers: [
    // { provide: NgbDateAdapter, useClass: CustomAdapter },
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
  ],
})
export class CalendarUiComponent implements OnInit, OnChanges {
  hoveredDate: NgbDate | null = null;
  fromDate: NgbDate | null;
  CalendarForm: any;
  checkdate: any;

  disabled = true;
  @Input() controlName: any;
  @Input() groupName: any;
  @Input() options!: any;
  @Input() dateFrom!: any;
  @Input() dateTo!: any;
  @Input() errorClass: any;
  public minDate: any;
  public maxDate: any;
  myform: any;
  formatter: any;
  getAvailableDates$!: Subscription;
  availableDateWithSlots: any;
  isDisabled!: any

  constructor(
    private ngbCalendar: NgbCalendar,
    private dateAdapter: NgbDateAdapter<string>,
    private rootFormGroup: FormGroupDirective,
    private store: Store<DynamicComponentState>
  ) {
    this.fromDate = ngbCalendar.getToday();
  }
  get today() {
    return this.dateAdapter.toModel(this.ngbCalendar.getToday())!;
  }
  ngOnInit(): void {
    this.myform = this.rootFormGroup.control;
    this.getAvailableDates$ = this.store.select(getAvailableDates).subscribe((dates) => {
      this.availableDateWithSlots = dates;
    });

  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.dateFrom && this.dateFrom.length && this.dateTo.length) {
      console.log(this.dateFrom);
      let minDate = new Date(this.dateFrom);
      let maxDate = new Date(this.dateTo);
      this.minDate = {
        year: minDate.getFullYear(),
        month: minDate.getMonth() + 1,
        day: minDate.getDate(),
      };
      this.maxDate = {
        year: maxDate.getFullYear(),
        month: maxDate.getMonth() + 1,
        day: maxDate.getDate(),
      };
    } else {
      let minDate = new Date();
      this.minDate = {
        year: minDate.getFullYear(),
        month: minDate.getMonth() + 1,
        day: minDate.getDate(),
      };
    }

  }
  apiCall(d1: any) {
    setTimeout(() => { d1.toggle(); }, 0)
    this.isDisabled = (
      date: NgbDateStruct
    ) => {
      let availableDates = this.availableDateWithSlots.timeSlotDetails;
      let holidayDates = [
     
        { date: "2022-05-02" }
      ]
      for (var i = 0; i < availableDates.length; i++) {
        var availableDate = new Date(availableDates[i].dateOfAppointment);
        var day: number = availableDate.getDate();
        var month: number = availableDate.getMonth() + 1;
        var year: number = availableDate.getFullYear();
        //availble slots
        if (day === date.day && month === date.month && year === date.year) return false;
        // weekend 
        const d = new Date(date.year, date.month - 1, date.day);
        if (d.getDay() === 0 || d.getDay() === 6) return true;
        // holiday
     
      }
      return true;
    };
  }

  onDateSelection(date: NgbDate) {
    let time = this.createDate(date.year, date.month, date.day);
    let slots;
    this.availableDateWithSlots.timeSlotDetails.map((date: any) => {
      if (date.dateOfAppointment == time) {
        slots = date.hours;
      }
    })
    this.store.dispatch(selectedSlot({ data: slots }));
  }
  createDate(y: any, m: any, d: any) {
    return `${y}-${m.toString().padStart(2, 0)}-${d.toString().padStart(2, 0)}`;
  }

  availableDate(date: NgbDateStruct) {
    return this.checkAvailableDate(date);
  }
  checkAvailableDate(date: NgbDateStruct): boolean {
    if(this.availableDateWithSlots){
      let availableDates = this.availableDateWithSlots.timeSlotDetails;
      for (var i = 0; i < availableDates.length; i++) {
        var taskDate = new Date(availableDates[i].dateOfAppointment);
        var day: number = taskDate.getDate();
        var month: number = taskDate.getMonth() + 1;
        var year: number = taskDate.getFullYear();
        if (day === date.day && month === date.month && year === date.year) {
          return true;
        }
      }
      return false;
    }
    return false;
  }
  holiday(date: NgbDateStruct): boolean {
    let holidayDates = [
      { date: "2022-05-02" },
    ]
    // let availableDates = this.availableDateWithSlots.timeSlotDetails;
    for (var i = 0; i < holidayDates.length; i++) {
      var holiday = new Date(holidayDates[i].date);
      var day: number = holiday.getDate();
      var month: number = holiday.getMonth() + 1;
      var year: number = holiday.getFullYear();
      if (day === date.day && month === date.month && year === date.year) {
        return true;
      }
    }
    return false;
  }
  isWeekend = (date: NgbDate) => this.ngbCalendar.getWeekday(date) >= 6;

  ngOnDestroy() {
    this.getAvailableDates$.unsubscribe();
  }
}

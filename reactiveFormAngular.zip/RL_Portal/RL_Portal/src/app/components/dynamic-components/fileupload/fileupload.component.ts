import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormGroupDirective } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const fileIcons = {
  "application/pdf": "fa-solid fa-file fa1",
  "application/doc": "fa-solid fa-file fa1",
  "image/png":"fa-solid fa-image fa1",
  "default":"fa-solid fa-file fa1"
}

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadComponent implements OnInit {

  shortLink:string[]=[];
  loading:boolean=false;
  dummy:any[]=[]
  myform:any;
  flag:boolean=true
  first=true
  second=false
  loaded=true
  @Input() fileIcons:any = {};
	@Input() controlName: any;
	@Input() groupName: any;
  public files!:File[]
  public filesy!:File[]
  public filees1:any[]=[]
  public a:any
  public waiting:boolean=false
  public baseApiUrl="https://file.io"

  constructor(private rootFormGroup: FormGroupDirective,private changeDetectorRef:ChangeDetectorRef, private http:HttpClient) { }

  ngOnInit(): void {
    this.myform = this.rootFormGroup.control;
    var temp = {...fileIcons};
    Object.assign(temp,this.fileIcons);
    this.fileIcons = temp;
  }
  onChange(event:any) {
    console.log(event)
    console.log(event.target.files)
    this.files = event.target.files
    this.files = Array.from(this.files)
    console.log(this.files);
    this.myform=this.rootFormGroup.control
    console.log(this.myform.controls)
    this.flag=true
    this.waiting=true
    this.first=true
    this.second=false
    this.loaded=false
    this.onUpload()
    console.log("Came to load")
  }
  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }
  onRemove(value:any){
    // Need Separeate Api for removing files
    this.files.splice(value,1)
    console.log(value)
    
    // if(this.files.length==0){

    // }
    console.log("Need a separate api for removing files")
  }

  __uploadFile (value:any,index:any) {
    return new Promise<any>((resolve,reject)=>{
      this.upload(value).subscribe(
        (event: any) => {
          resolve({event,index,value});
        }
        )
      })
    }

  upload(file:any):Observable<any>{
    const formData=new FormData();
    formData.append("file",file,file.name);
    return this.http.post(this.baseApiUrl,formData)
  }

  __onUploadComplete(){
    this.waiting=false
    this.loaded = true;
    this.flag=!this.flag
    this.first=!this.first
    this.second=!this.second

    console.log("all files are uploaded");
    this.loaded = true
    this.changeDetectorRef.detectChanges();
  }

   onUpload(){
    
    this.dummy= Array(this.files.length);
    var count = 1;
    for(var i in this.files){
      console.log(i);
      var value = this.files[i];
      this.loading=!this.loading
      console.log(value)
      this.__uploadFile(value,i).then(data => {
        console.log(data.index);
       
        if (typeof (data.event) === 'object') {
          console.log(data.event.link);
          this.dummy[data.index] = (data.event.link);
          this.loading = false;
        }
        if(count == this.files.length){
          this.__onUploadComplete();
        }else{
          count++;
        }
      })
    }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalModalComponent } from './local-modal.component';

describe('LocalModalComponent', () => {
  let component: LocalModalComponent;
  let fixture: ComponentFixture<LocalModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocalModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LocalModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

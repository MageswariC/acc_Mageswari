import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
declare var window: any;
@Component({
  selector: 'app-local-modal',
  templateUrl: './local-modal.component.html',
  styleUrls: ['./local-modal.component.scss']
})
export class LocalModalComponent implements OnInit {

  formModal: any;
  @Input() modalData!: any;
  @Input() cancelRequired!: any;
  @Input() okFunction!:any;
  @Input() body!:any;
  

  @Output() confirmClicked = new EventEmitter<any>();
  @Output() cancelClicked = new EventEmitter<any>();

constructor() { 

}
  ngOnInit(): void {
    this.formModal = new window.bootstrap.Modal(
      document.getElementById('myModal')
    );
    this.openFormModal();
  }

  openFormModal() {
    this.formModal.show();
  }
  confirm() {
    this.confirmClicked.emit(this.modalData.modalOkFunction !== null ? this.modalData.modalOkFunction : false);
    this.formModal.hide();
  }
  cancel() {
    this.cancelClicked.emit();
    this.formModal.hide();
  }
}

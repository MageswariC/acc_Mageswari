import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MultiSelectDropdownComponent } from './multi-select-dropdown/multi-select-dropdown.component';
import { TypeaheadComponent } from './typeahead/typeahead.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from './modal/modal.component';
import { FormBuilderComponent } from './form/form-builder/form-builder.component';
import { FeasibilityCheckFormBuilderComponent } from './form/feasibility-check-form-builder/feasibility-check-form-builder.component';
import { RequestingLicenseComponent } from './requesting-license/requesting-license.component';
import { LoginComponent } from './login/login.component';
import { DynamicTableComponent } from './form/dynamic-table/dynamic-table.component';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { ManageOrderTableComponent } from './form/tables/manage-order-table/manage-order-table.component';
import { CalendarUiComponent } from './calendar-ui/calendar-ui.component';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DatePipe } from '@angular/common';
import { SearchOrderComponent } from './form/search-order/search-order.component';
import { LocalModalComponent } from './local-modal/local-modal.component';
import { CheckOrderStatusComponent } from './form/check-order-status/check-order-status.component';
import { NewFeasiblityCheckerComponent } from './form/new-feasiblity-checker/new-feasiblity-checker.component';
import { NgxMaskModule } from 'ngx-mask';
@NgModule({
  declarations: [
    FooterComponent,
    NavbarComponent,
    HomeComponent,
    MultiSelectDropdownComponent,
    TypeaheadComponent,
    BreadcrumbComponent,
    FormBuilderComponent,
    ModalComponent,
    FeasibilityCheckFormBuilderComponent,
    DynamicTableComponent,
    RequestingLicenseComponent,
    LoadingSpinnerComponent,
    LoginComponent,
    HeaderComponent,
    ManageOrderTableComponent,
    CalendarUiComponent,
    FileuploadComponent,
    SearchOrderComponent,
    LocalModalComponent,
    CheckOrderStatusComponent,
    NewFeasiblityCheckerComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    RouterModule,
    NgMultiSelectDropDownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgxMaskModule.forChild()
  ],
  exports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    HomeComponent,
    BreadcrumbComponent,
    FormBuilderComponent,
    FeasibilityCheckFormBuilderComponent,
    ModalComponent,
    DynamicTableComponent,
    LoadingSpinnerComponent,
    LoginComponent,
    RequestingLicenseComponent,
    ManageOrderTableComponent,
    SearchOrderComponent,
    LocalModalComponent,
    CheckOrderStatusComponent,
    NewFeasiblityCheckerComponent
    
  ],
  providers: [DatePipe],
})
export class DynamicComponentModule {}

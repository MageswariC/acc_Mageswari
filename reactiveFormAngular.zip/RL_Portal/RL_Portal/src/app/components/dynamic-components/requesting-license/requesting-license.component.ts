import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { userInfo } from '../../../modules/integration/modal/user-info/user-info.modal';

@Component({
  selector: 'requesting-license',
  templateUrl: './requesting-license.component.html',
  styleUrls: ['./requesting-license.component.scss']
})
export class RequestingLicenseComponent implements OnInit {
  rlForm!: FormGroup;
  rlData: any
  isFromDisabled: Boolean = true;
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.rlData = userInfo;
    this.rlForm = this.fb.group({
      rlName: [],
      companyName: [],
      designation: [],
      contactInfo: [],
      faxNo: [],
      emailId: []

    })
    this.rlForm.patchValue(this.rlData.requestingLicensee);
  }
}

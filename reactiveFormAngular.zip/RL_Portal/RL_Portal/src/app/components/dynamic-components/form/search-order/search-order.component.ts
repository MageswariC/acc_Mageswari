
import { Component, Input, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import {FormData} from 'src/app/modules/integration/interface/components/form-builder';
@Component({
  selector: 'app-search-order',
  templateUrl: './search-order.component.html',
  styleUrls: ['./search-order.component.scss']
})
export class SearchOrderComponent implements OnInit {


  @Input() formData!: FormData;
  @Input() parent: any
  @Input() formValue:any

  @Output() emitOrderStatusform = new EventEmitter();
  @Output() cancelOrderStatus = new EventEmitter();
  isDisabled:Boolean = false;
  public orderStatus: FormGroup = this.fb.group({});
  
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    // console.log('nside check cancel terminate order')
    // console.log(this.formValue)
    // console.log(this.parent)
    // console.log(this.formData)
    // console.log(this.formData.controls[0].id);
    this.createForm(this.formData.controls);
    if(this.formValue)this.orderStatus.patchValue(this.formValue);
  }
  createForm(controls: FormData['controls']){
    for (const control of controls){
      const newGroup = new FormGroup({});
      control?.options.children.map((child:any) => {
        const newControl = new FormControl();
        const validatorsToAdd = child?.validators(Validators);
          newControl.setValidators(validatorsToAdd);
          newGroup.addControl(child.key, newControl);
          this.orderStatus.addControl(child.key, newControl);
      })
    }
  }
  onSubmit(){
      this.emitOrderStatusform.emit(this.orderStatus.value);
      this.isDisabled = true;
  }
  cancelSearch(){
    this.isDisabled = false;
    this.orderStatus.reset();
    this.cancelOrderStatus.emit();
  }
  checkErrors(f: FormGroup, fg: any, fc: any){
    if (f.controls && f.controls[fc]?.touched) {
      if(f.controls[fc].errors){
        const error = Object.keys(f.controls[fc].errors || {})[0];
        return error;
      }
    } 
    return null;
  }

}

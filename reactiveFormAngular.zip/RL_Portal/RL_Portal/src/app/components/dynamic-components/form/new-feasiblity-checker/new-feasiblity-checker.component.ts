import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FeasibilityCheckService } from 'src/app/modules/integration/service/order-management/feasibility-check.service';
import validation from 'src/app/modules/integration/utilities/validation';


@Component({
  selector: 'app-new-feasiblity-checker',
  templateUrl: './new-feasiblity-checker.component.html',
  styleUrls: ['./new-feasiblity-checker.component.scss'],

})
export class NewFeasiblityCheckerComponent implements OnInit {

  postalCodeVerified = false;
  fesiblityForm: any;
  postalCodeStatus: any;
  buildingNumberOptions = [];

  unitNumberOptions = [];
  isUnitNumberMandatory=false;
  feasiblityChecked = false;
  feasiblityResponse: any;
  @Output() getFeasiblityResponse = new EventEmitter<any>();
  modalVisibilty = false;

  modalObj = {
    modalTitle: '',
    modalBody: '',
    cancelRequired: false,
    modalOkFunction: null
  }
  constructor(private fb: FormBuilder, private feasibilityCheckService: FeasibilityCheckService,private ref: ChangeDetectorRef) { }
  ngAfterContentChecked() {
    this.ref.detectChanges();
  }
  ngOnInit(): void {
    this.fesiblityForm = this.fb.group({
      postalCode: ['', [Validators.required, validation.postalCode()]],
      buildingNumber: ['', [Validators.required]],
      unitNumber: ['', []]

    })


  }
  checkPostalCode(event: any) {
    if (this.fesiblityForm.get('postalCode').valid) {

      const payload = {
        postalCode: event.target.value
      }
      console.log("p", payload);
      this.isUnitNumberMandatory=false;
      this.postalCodeStatus = 'loading'

      this.feasibilityCheckService.feasibilityCheck(payload).subscribe(data => {

        
        // setTimeout( () => {  this.postalCodeStatus="xx" }, 4000 );


        if (data.postalCodeCheck) {
          this.postalCodeStatus = "xx"
          this.buildingNumberOptions = data.listOfBlocks;
          this.unitNumberOptions = data.listOfUnits;
        

          if (this.buildingNumberOptions.length === 1) {
            this.fesiblityForm.patchValue({
              buildingNumber :this.buildingNumberOptions[0]
            })
            this.fesiblityForm.controls['unitNumber'].setValidators([Validators.required])
            this.fesiblityForm.controls['unitNumber'].updateValueAndValidity()
            this.isUnitNumberMandatory=true;

          }

          this.postalCodeVerified = true;
        }

      })

    }
    else {
      this.postalCodeVerified = false;
    //  this.postalCodeStatus = 'loading';
    }
  }
  checkFieldValidity(controlName: any) {
    return this.fesiblityForm.get(controlName)?.errors && this.fesiblityForm.get(controlName)?.touched;
  }
  checkFeasiblity() {
    this.feasiblityChecked = true;
    this.fesiblityForm.disable()

    const payload = this.fesiblityForm.value;
    console.log(payload);

    this.feasibilityCheckService.feasibilityCheck(payload).subscribe(data => {

      if (data) {
        

        this.feasiblityResponse = {
          feasablityCheckDetails:this.fesiblityForm.value,
          feasablityCheckResponse:data
        };
        this.getFeasiblityResponse.emit(this.feasiblityResponse );
        console.log(this.feasiblityResponse);
      }

    })

  }
  onEditFeasibilityCheck() {
    let successMsg: any = {
      title: 'Confirmation',
      body: 'Are you sure you want to do Feasibility Check Again?',
      okFunction: 'EditFC'
    };
    this.setModal(successMsg);
  }

  editFeasibilityCheck() {
    //  document.querySelector("#collapseOne")?.classList.add('show')
    this.feasiblityChecked = false;
    this.fesiblityForm.enable()
  }
  modalConfirm(callback: any) {
    if (callback == 'EditFC') {
      this.editFeasibilityCheck();
      this.modalVisibilty = false;
    }

  }

  modalCancel() {
    this.modalVisibilty = false;
  }

  setModal(modalData: any) {
    this.modalObj.modalBody = modalData.body;
    this.modalObj.modalTitle = modalData.title;
    this.modalVisibilty = true;
    this.modalObj.modalOkFunction = modalData.okFunction;
  }


}

import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Observable, OperatorFunction } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { FormData } from '../../../integration/interface/form-builder';

import { ModalComponent } from '../../modal/modal.component';

@Component({
  selector: 'feasibility-check-form-builder',
  templateUrl: './feasibility-check-form-builder.component.html',
  styleUrls: ['./feasibility-check-form-builder.component.scss'],
})
export class FeasibilityCheckFormBuilderComponent implements OnInit {
  feasibilityCheckData!: any

  @Input()
  set feasibilityCheck(value: FormData) {
    this.feasibilityCheckData = value;
    this.addHandler(value);
  }
  @Input() parent: any;
  isFCbbtnEnable!: boolean;
  fcData: any;

  @Output() emitFCFromControl = new EventEmitter();
  @Output() emitFCFormValue = new EventEmitter();
  @Output() editFeasibility = new EventEmitter();
  @Output() emitFcform =new EventEmitter();
  public fcForm!: FormGroup;
  constructor(private fb: FormBuilder, private cdr: ChangeDetectorRef) { }

  
  ngOnInit(): void {
    // this.fcData = this.feasibilityCheck.controls;   
    this.addHandler(this.feasibilityCheckData);
    // this.createForm(this.fcData); 
  }
  addHandler(fc: any) {
    this.fcForm = this.fb.group({});
    if (fc && fc.controls) {
      this.isFCbbtnEnable = fc.controls[0].isFcBtnrequired
      fc.controls.forEach((ele: any) => {
        ele.options.children.forEach((e: any) => {
          if (!e.handler) e.handler = () => { };
        });
      }); this.createForm(fc.controls);
    }
  }

  createForm(controls: FormData['controls']) {
    for (const control of controls) {
      const newGroup = new FormGroup({});
      control.options?.children.map((child: any) => {
        const newControl = new FormControl();
          if (child.defaultValue) newControl.setValue(child.defaultValue);
        const validatorsToAdd = child?.validators(Validators);
        newControl.setValidators(validatorsToAdd);
        newGroup.addControl(child.key, newControl);
      });
      this.fcForm.addControl(control.key, newGroup);
    }
    this.emitFCFromControl.emit(this.fcForm);
  }
  onSubmit() {
    this.emitFCFormValue.emit(this.fcForm.value);
  }
  checkErrors(f: FormGroup, fg: any, fc: any) {
    let a = f.controls[fg] as FormGroup;
    if (f.controls && a.controls[fc]?.touched) {
      if (a.controls[fc].errors) {
        const error = Object.keys(a.controls[fc].errors || {})[0];
        return error;
      }
    }
    return null;
  }
  editFeasibilityCheck(event: any) {
    this.editFeasibility.emit();
  }

}

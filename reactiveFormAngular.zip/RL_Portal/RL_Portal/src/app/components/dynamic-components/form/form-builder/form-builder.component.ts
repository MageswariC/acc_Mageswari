import {
  Component,
  Input,
  OnInit,
  EventEmitter,
  Output,
  SimpleChanges,
} from '@angular/core';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormArray,
} from '@angular/forms';
import { FormData } from '../../../integration/interface/form-builder';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss'],
})
export class FormBuilderComponent implements OnInit {
  formBuilderData!: any;
  @Input()
  set formData(value: FormData) {
    this.formBuilderData = value;
    this.addHandler(value);
  }
  @Input() sheduleModal: any;
  @Input() parent: any;
  @Input() submitBtnRequired: any = true;
  @Output() emitForm = new EventEmitter();
  @Output() emitFormValue = new EventEmitter();
  @Output() emitCancel = new EventEmitter();
  @Input() tableColoumFormat: any;
  @Input() tableRowData: any;
  @Input() tableModalData: any;
  @Input() submitButtonRequired=true;
  public myForm!: FormGroup;
  constructor(private fb: FormBuilder, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // this.fcData = this.feasibilityCheck.controls;   
    // this.addHandler(this.formBuilderData);
    // this.createForm(this.fcData); 
    if (this.sheduleModal) this.myForm.patchValue(this.sheduleModal);
  }
  addHandler(data: any) {
    this.myForm = this.fb.group({});
    if (data && data.controls) {
      data.controls.forEach((ele: any) => {
        ele.options.children.forEach((e: any) => {
          if (!e.handler) e.handler = () => { };
        });
      }); 
      this.createForm(data.controls);
      // if (this.sheduleModal) this.myForm.patchValue(this.sheduleModal);
    }
  }
  createForm(controls: FormData['controls']) {
    for (const control of controls) {
      if (control.type == 'group') {
        //&& control.visible===true
        const newGroup = new FormGroup({});
        control.options?.children.map((child: any) => {
          if (child.subformControls) {
            const newArry = new FormArray<any>([]);
            const subGroup = new FormGroup<any>({});
            child.subformControls.map((child: any) => {
              const subnewcontrol = new FormControl();
              const validatorsToAdd = child?.validators(Validators);
              subnewcontrol.setValidators(validatorsToAdd);
              subGroup.addControl(child.key, subnewcontrol);
            });
            newArry.push(subGroup);
            newGroup.addControl(child.key, newArry);
          } else {
            const newControl = new FormControl();
            if (child.defaultValue) newControl.setValue(child.defaultValue);
            const validatorsToAdd = child?.validators(Validators);
            newControl.setValidators(validatorsToAdd);
            newGroup.addControl(child.key, newControl);
          }
        });
        this.myForm.addControl(control.key, newGroup);
      }
    }
    this.emitForm.emit(this.myForm);
  }
  getFormArray(key: any, fc: any) {
    //console.log(".....", key)
    let a = this.myForm.controls[fc] as FormGroup;
    let b = a.get(key) as FormArray;
    return a.get(key) as FormArray;
  }
  checkErrors(f: FormGroup, fg: any, fc: any) {
    const a = f.controls[fg] as FormGroup;
    if (a.controls && a.controls[fc]?.touched) {
      if (a.controls[fc].errors) {
        const error = Object.keys(a.controls[fc].errors || {})[0];
        return error;
      }
    }
    return null;
  }
  checksubcontrolErrors(f: FormGroup, fg: any, fc: any, index: any) {
    const a = f.controls[fg] as FormGroup;
    const b = a.controls[fc] as FormArray;
    const c = b.controls[0] as FormGroup;
    const d = c.get(index);
    if (a.controls && d?.touched) {
      if (c.controls[index].errors) {
        const error = Object.keys(c.controls[index].errors || {})[0];
        return error;
      }
    }
    return null;
  }
  onSubmit() {
    console.log('%c form Value', 'background-color:blue', this.myForm.value);
    this.emitFormValue.emit(this.myForm.value);
  }
  onCancel() {
    this.emitCancel.emit();
  }
}

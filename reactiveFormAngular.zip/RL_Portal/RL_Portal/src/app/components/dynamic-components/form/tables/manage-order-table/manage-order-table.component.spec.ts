import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageOrderTableComponent } from './manage-order-table.component';

describe('ManageOrderTableComponent', () => {
  let component: ManageOrderTableComponent;
  let fixture: ComponentFixture<ManageOrderTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageOrderTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageOrderTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewFeasiblityCheckerComponent } from './new-feasiblity-checker.component';

describe('NewFeasiblityCheckerComponent', () => {
  let component: NewFeasiblityCheckerComponent;
  let fixture: ComponentFixture<NewFeasiblityCheckerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewFeasiblityCheckerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewFeasiblityCheckerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

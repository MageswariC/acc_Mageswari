import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'apps-manage-order-table',
  templateUrl: './manage-order-table.component.html',
  styleUrls: ['./manage-order-table.component.scss']
})
export class ManageOrderTableComponent implements OnInit {

  @Input() tableColoumFormat: any
  @Input() tableRowData:any;
  @Input() coLists:any;
  @Output() modifyOrder = new EventEmitter();
  @Output() cancelOrder = new EventEmitter();
  @Output()  terminateOrder = new EventEmitter();
  @Output() manageTP = new EventEmitter();
  @Output()  gPONtoOE = new EventEmitter();
  @Output() relocateService = new EventEmitter();
  @Output() viewOrder = new EventEmitter();
  @Output() update = new EventEmitter();
  @Output() reopen = new EventEmitter();
  @Output() cancel = new EventEmitter();
  @Output() close=new EventEmitter();

 @Input() istroubleticket:boolean=false;
 @Input() incidentStatus:any;
  
  constructor() {

  }

  ngOnInit(): void {

    // console.log("ApiData", this.tableRowData)
    // console.log("tableFormat", this.tableColoumFormat)
    // console.log(this.cancelOrder);
    
    
  }
  ngOnChanges(changes: SimpleChanges) {
  console.log(changes);
  
  }

  onModifyOrder(){
   this.modifyOrder.emit();
  }
  onCancelOrder(){
    this.cancelOrder.emit();
  }
  onTerminateOrder(){
    this.terminateOrder.emit();
  }
  onManageTP(){
   this.manageTP.emit();

  }
  onGPONtoOE(){
   this.gPONtoOE.emit();
  }
  onRelocateService(){
   this.relocateService.emit();
  }
  onViewOrder(){
   this.viewOrder.emit();
  }
  onUpdate()
  {
    this.update.emit();
  }
  onReopen()
  {
    this.reopen.emit();
  }
  onCancel()
  {
    this.cancel.emit();
  }
  onClose(){
    this.close.emit();
  }
 

}

import { Component, OnInit, Input, ViewEncapsulation, ChangeDetectionStrategy, forwardRef } from '@angular/core';
import { ControlContainer, ControlValueAccessor, FormGroup, FormGroupDirective, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-multi-select-dropdown',
  templateUrl: './multi-select-dropdown.component.html',
  styleUrls: ['./multi-select-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MultiSelectDropdownComponent),
      multi: true,
    },
  ]
})
export class MultiSelectDropdownComponent implements OnInit,ControlValueAccessor {
  @Input() dropdownList: Array<any> = [];
  @Input() selectedItems: any;
  @Input() dropdownSettings: any;
  @Input() placehoder: string = "";

  @Input() isDisabled: any;
  public values: any;


  onChange: any = () => { }
  onTouch: any = () => { }

  writeValue(value: any): void {

    this.values = value;

  }
  registerOnChange(fn: any): void {
    this.onChange = fn;

  }
  registerOnTouched(fn: any): void {

    this.onTouch = fn;

  }


  ngOnInit() {
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true
    };
    this.values = this.selectedItems;
  }
  onDropDownClose() {

    this.onTouch();

  }
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onChanges(event: any) {
    this.values = event;
    this.onChange(event);
  }


}

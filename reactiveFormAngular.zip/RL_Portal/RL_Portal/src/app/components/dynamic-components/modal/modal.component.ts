
import { NgbModal, NgbModalConfig, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { Component, EventEmitter, Injectable, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { FormService } from '../../integration/service/component/form.service';

import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
  @ViewChild('modal') private modalContent!: TemplateRef<ModalComponent>
  @Output() newConfirmationEvent = new EventEmitter<string>();
  @Input() modalData: any;
  private modalRef!: NgbModalRef;
  constructor(config: NgbModalConfig ,private toastrService: ToastrService, private modalService: NgbModal, private formService:FormService) {
    config.backdrop = 'static';
    config.keyboard = false;
   }
  ngOnInit(): void {
  }

 open(obj?:any): Promise<boolean> {
    return new Promise<boolean>(resolve => {
      // this.modalRef.close();
     
      this.modalRef = this.modalService.open(this.modalContent, { size: this.modalData?.modalSize})
      this.modalRef.result.then((result) => {
      
        if(result=="Save click") {
        this.newConfirmationEvent.emit(result);
        }
      }, (reason) => {
        console.log(reason);
        this.newConfirmationEvent.emit(reason);
      });
    })
  }


}

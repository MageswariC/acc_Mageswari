import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreModule } from '@ngrx/store';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { environment } from '../environments/environment';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//components
import { AppComponent } from './app.component';
import { ContainerComponent } from './components/common-templates/container/container.component';
import { DynamicComponentModule } from './components/dynamic-components/dynamic-component.module';
import { CustomSerializer } from './components/integration/store/custom-serializer';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { InterceptorService } from './modules/integration/service/http/interceptor.service';

import { OrderManagementModule } from './modules/order-management/order-management.module';
import { TroubleTicketModule } from './modules/trouble-ticket/trouble-ticket.module';
import { ApplicationManagementModule } from './modules/application-management/application-management.module';
import { ApplicationManagementComponent } from './modules/application-management/application-management.component';
import { RootEffects, Rootreducers } from '../app/store/index';
import { EffectsModule } from '@ngrx/effects';
import { UserManagementModule } from './modules/user-management/user-management.module';
import { NgxMaskModule, IConfig } from 'ngx-mask'
export const options: Partial<null|IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    ApplicationManagementComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    RouterModule,
    DynamicComponentModule,
    OrderManagementModule,
    TroubleTicketModule,
    UserManagementModule,
    ApplicationManagementModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      closeButton: true,
      timeOut: 2000, // 2 seconds
      progressBar: true,
    }),
    // Set up ngrx store.
    StoreModule.forRoot(Rootreducers),
    EffectsModule.forRoot(RootEffects),
    StoreRouterConnectingModule.forRoot({
      serializer: CustomSerializer,
    }),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      logOnly: environment.production, // Restrict extension to log-only mode
      autoPause: true, // Pauses recording actions and state changes when the extension window is not open
    }),
    NgxMaskModule.forRoot(),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
